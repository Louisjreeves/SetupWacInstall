﻿function chkip {

# $global:RunTime = New-TimeSpan -Start $StartTime -End (get-date) 

cls
$global:myorig = $env:computername
Write-host "==================================" -ForegroundColor white
Write-host " $env:computername of cluster node connectivity for omimswac" -ForegroundColor white

invoke-command -ComputerName (get-clusternode).name -ScriptBlock {



function sendIP
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [string]$SourceIpa,

        [Parameter(Mandatory=$true, Position=1)]
        [string]$TargetDestination,

        [Parameter(Mandatory=$true, Position=2)]
        [string]$TargetResponseCount,

        [Parameter(Mandatory=$true, Position=3)]
        [string]$DestinationPort,

         [Parameter(Mandatory=$false, Position=4)]
        [string]$myfinalFCVA,

         [Parameter(Mandatory=$false, Position=5)]
        [string]$myorig

        
         
       
        
    )

    read-host "We are going to test the usb and regular nics for communication to the drac redfish IP. Hit enter to begin"

 $a= $env:COMPUTERNAME
 $b = Resolve-DnsName -Name $a | where-object {$_.type -eq "A"}
$c = $b | Where-Object {$_.ipaddress -inotmatch "169.254"} | Select-Object 
$myaddress1 =@()
$myaddress1 = $c.ipaddress
$countip = $myaddress1.count

 $desthoot= "3343"
 $mylocal1 = [string]$myaddress1
 $blae = $mylocal1.Split(" ")
 $myhostIP = $mylocal1
 

    try
{
    $DestinationIpa = (Test-Connection -Source $SourceIpa -ComputerName $TargetDestination -Count $TargetResponseCount).ipv4address.ipaddressToString
    $tcpObj = New-Object Net.Sockets.TcpClient($DestinationIpa, $DestinationPort)

    if($tcpObj -ne $null)
    {
 $tcpObj.close()
         ################################################################################
write-host "=========================================" -ForegroundColor white
write-host " USBNIC/REDFISH Report : $env:computername " -ForegroundColor white
write-host "=========================================" -ForegroundColor white

       
write-host "Using the USBNIC source $SourceIpa. The port $DestinationPort on destination Redfish Drac IP $TargetDestination is open." -ForegroundColor white
write-host "`USBNIC value: $SourceIpa"
  write-host "`REDFISH value: $TargetDestination"
    write-host "`Cluster Virtual nic value: $myfinalFCVA"
start-sleep(2) 
for ($i = 0; $i -lt ($blae.Length) ; $i++) 
#foreach ($nots in $blae[$i])
 {
 
 $desthoot= "3343"
 $myip =$blae[$i]
  #Test-Connection  -computername $USING:myorig -Source $myhostIP[$i]  -Protocol WSMan
 $Destinationbloop = (Test-Connection -Source $myip -ComputerName $env:COMPUTERNAME -Count $TargetResponseCount).ipv4address.ipaddressToString
    $ncpObj = New-Object Net.Sockets.TcpClient($Destinationbloop,$desthoot)
   if($ncpObj -ne $null) {write-host "$Destinationbloop<-----------This Cluster network checks out as connected to $env:COMPUTERNAME" -ForegroundColor white} else {write-host "$Destinationbloop <----------is failing the connections checkpoint" -ForegroundColor red}
$ncpObj.close()
  $myip="0"
    
 #Write-host "$myip <--------------Current" -ForegroundColor white
 

 
  }

  $ncpObj.close()
  start-sleep(2) 


  $ipmi1 = Get-service -name IPMIDRV


$ipmi2 = Get-PnpDevice -Class system -FriendlyName "microsoft Generic IPMI compliant device"
If ($ipmi1 -and $ipmi2) {$ipmi3= "True"} else {$ipmi3= "false"}

Write-host "-----------------------" -ForegroundColor Yellow
if ($ipmi3 = "true") { Write-host "IPMI Service is "$ipmi1.status" and device is present on $env;computername." -ForegroundColor white} else { Write-host " IPMI Service is $ipmi1.status or  device is not present on $env;computername." -ForegroundColor yellow}

 
  
    }
}
catch {Write-host -Message "Using the source $blae[$i]. The port $DestinationPort on destination $TargetDestination is not open." -ForegroundColor red
    $tcpObj.close()}







}


$global:myorig = $env:computername


 $myfinalclusIP =@()
 $myfinalclusIP= ""
  #hostname A records
    $myFQDN=(Get-WmiObject win32_computersystem).DNSHostName+"."+(Get-WmiObject win32_computersystem).Domain 
    #resolved Hostname 
$cresolve = Resolve-DnsName $myFQDN | Where-Object {$_.Type -ne "AAAA"}
   $finalClusIP = @()
  #USBNIC 
$myusbnic = @(Get-NetAdapter -InterfaceDescription "Remote NDIS Compatible Device" | Get-NetIPAddress -AddressFamily "ipv4") 
 $myusbip = $myusbnic.IPAddress
 $alsoUSBNI= get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=true and DHCPEnabled=true" -ComputerName .
#RedfishIP
 $mytempfih = (get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=true and DHCPEnabled=true" -ComputerName . | Where-Object -FilterScript {$_.Description -contains "Remote NDIS Compatible Device"} | Select-Object -Property DHCPSERVER)
 $myRedJustIP = ($mytempfih.dhcpserver)
 #microsoft failover virtual cluster virtual IP address 
 $myfinalClusIP =  @(Get-NetAdapter -IncludeHidden -InterfaceDescription "*Microsoft Failover Cluster Virtual Adapter*" | Get-NetIPAddress -AddressFamily "ipv4")
 
 $myfinalFCVA= $myfinalclusip.ipaddress

$bothnotUSB= ($temp1APIP.IPAddress| Where-Object -FilterScript {$_.Description -ne "Remote NDIS Compatible Device"}) 

 




$SourceIpa = $myusbip
$TargetDestination = $myRedJustIP
$TargetResponseCount = 1
$DestinationPort = 443

#sending the USBNICS to the SENDIP function, where the local Host will pull the cluster IP and test them

try{ sendIP $SourceIpa $TargetDestination 1 80 $myfinalFCVA $myorig} catch {Write-host "not every test succeeds.. ignore this one"}






  }



 



}chkip
