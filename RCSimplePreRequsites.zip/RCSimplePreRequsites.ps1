﻿
  if (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")){
        throw 'Admin permission missing! Restart and run as administrator!' #or anything else you like
    }
  $myspanser = read-host "what is the cluster name we are working on? "
 $global:where2 
$where2 = $PSScriptRoot
set-location -Path $where2
cd $where2
Push-Location -Path $where2 
set-location $PSScriptRoot
$mylocation = set-location $PSScriptRoot
$myloc= $PWD.Path 
#CLs 
 $pwd
$Path = $myloc + "\"+ "racadmininstall.exe" #Include the FileName and Extension
$Destination = "C$\Users\$Env:Username\" #Be Sure to use a : instead of a $ for the username variable
$global:mymachine= $env:COMPUTERNAME
$my=@()
$mycluster= Get-Cluster -Name $myspanser
$mynodes = Get-ClusterNode -Cluster $mycluster | Select-Object name
$counter = (@($mynodes).name).Count
$my= (@($mynodes).name) 
$computername = $my -split " "
$selection = "a"

function Show-Menu
{
    param (
        [string]$Title = 'My Menu'
    )

    Clear-Host
    Write-Host "================ $Title ===================================================================" -ForegroundColor Magenta
     
    Write-host " Offline Setup and test menu" -ForegroundColor Magenta
    Write-host " ===========================================================================================" -ForegroundColor Magenta

    Write-Host "1: Press '1' IDracTools install and pre-requisites" -ForegroundColor Red
    Write-Host "2: Press '2' Install ISM" -ForegroundColor Red
    Write-Host "3: Press '3' Check the work just performed " -ForegroundColor Red
    Write-Host "4: Press '4' Check for APipa issues " -ForegroundColor Red
    Write-Host "5: Press '5' Fix port 445 " -ForegroundColor Red
    Write-Host "Q: Press 'Q' to quit."
}


Function Copy-File
{
  [Cmdletbinding()]
  Param(
   [Parameter(ValueFromPipeline=$true,Mandatory=$true)]
    [String[]]$ComputerName,
   [Parameter(ValueFromPipeline=$true,Mandatory=$true)]
    [String]$Path,
   [Parameter(ValueFromPipeline=$true,Mandatory=$true)]
    [String]$Destination
   
)
  Process {
   #Extract FileName from Path
   $File = $Path.Split('\')
   $File = $File[$File.Length-1]



  ForEach ($Computer in $ComputerName)
  {
   
  
    Write-Verbose "Starting copy to $Computer"
    IF(Test-Path "\\$Computer\$Destination")
    {
     Write-Verbose "Folder $Destination exists on $Computer"
    }
    ELSE
    {
     Write-Verbose "Creating folder $Destination on $Computer"
    IF (New-Item "\\$Computer\$Destination" -Type Directory) {$global:shareyes++}
    }
 
   Write-Verbose "Copying $File to $Computer"
   TRY
   {
    If (Copy-Item -Path $Path -Destination "\\$Computer\$Destination" -Force) {$global:shareyes++}
    Write-Host "Copied to \\$Computer\$Destination\$File`n" -ForegroundColor GREEN

   }
   CATCH
   {
    Write-Warning "Copy failed to $Computer`n"
    
   } 
     

  }#EndForEach
 }#EndProcess
}#EndFunction

#check permissions 



# DOwnload Drac Tools to all nodes

copy-file $computername $Path $Destination

$Path = $myloc + "\"+ "isminstall.exe"

 #download ism module 

copy-file $computername $Path $Destination
 
 function do-idrac
 {
 
#install IDrac tools

Invoke-Command -computername (Get-ClusterNode).name -ScriptBlock {
$ans1 = $env:USERDNSDOMAIN
Start-Process -FilePath “c:\users\$env:username\racadmininstall.exe" -ArgumentList "/auto" -Wait -ErrorAction SilentlyContinue -ErrorVariable RACAdminExtractFail
Start-Process -FilePath "C:\OpenManage\iDRACTools_x64.msi" -ArgumentList '/quiet /norestart' -Wait -ErrorAction SilentlyContinue -ErrorVariable RACAdminInstallFail
Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any 
Set-Executionpolicy -executionpolicy remotesigned 
Set-Item WSMan:\localhost\Client\TrustedHosts *
Enable-WSManCredSSP -Role Client -Delegate $ans1
Enable-WSManCredSSP -Role Server
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192
New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowFreshCredentialsWhenNTLMOnly -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name 1 -Value * -PropertyType String }

}

function do-ism
{

 #install ISM
Invoke-Command -computername (Get-ClusterNode).name -ScriptBlock {
$ans1 = $env:USERDNSDOMAIN
 Start-Process -FilePath "c:\users\$Env:username\isminstall.exe" -ArgumentList "-auto" -Wait -ErrorAction SilentlyContinue -ErrorVariable ISMExtractFail
 Start-Process -FilePath "C:\OpenManage\iSM\windows\iDRACSvcMod.msi" -ArgumentList '/quiet /norestart' -Wait -ErrorAction SilentlyContinue -ErrorVariable ISMInstallFail

 Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any 
# for NVME failed disks – reset-physicaldisk -serialnumber xxxxx
Set-Executionpolicy -executionpolicy remotesigned 
Set-Item WSMan:\localhost\Client\TrustedHosts *
Enable-WSManCredSSP -Role Client -Delegate $ans1
Enable-WSManCredSSP -Role Server
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192
New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowFreshCredentialsWhenNTLMOnly -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name 1 -Value * -PropertyType String

set-location "c:\program files\dell\sysmgt\idractools\racadm\" -PassThru
.\racadm set idrac.os-bmc.adminstate 1
.\racadm set iDRAC.WebServer.HostHeaderCheck Disabled
.\racadm set LifeCycleController.LCAttributes.LifecycleControllerState 1
# n45d5 if your using drac8 – check the sessions tab to make sure racadm closessn –u n45d5
.\Racadm set idrac.OS-BMC.PTMode 1
.\racadm set idrac.lockdown.SystemLockdown 0


 }

 }

#test results of all nodes

function check-work
{

Invoke-command -ComputerName (Get-Clusternode).Name -ScriptBlock {

$mycurhost = $env:COMPUTERNAME
$mycurdom =$env:userdnsdomain
$myfqdn= $mycurhost + "."+$mycurdom
Write-host -NoNewline " REPORT FOR HOSTNAME:" -ForegroundColor magenta ; $myfqdn
Write-host -NoNewline "get-executionpolicy for $myfqdn is " -ForegroundColor Green ; Get-executionpolicy 

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host -NoNewline "WINRM RULE STATUS for " -ForegroundColor Green ; write-host $myfqdn -ForegroundColor Green
Get-NetFirewallRule -PolicyStore ActiveStore -Name "WINRM-HTTP-In-TCP-PUBLIC"  
#get-NetFirewallRule -Name "WINRM-HTTP-In-TCP-PUBLIC" | Select-Object PrimaryStatus ,action, enabled
write-host "-----------------------------------" -ForegroundColor Yellow
write-host " WSMAN Trusted Host Setting for $myfqdn" -ForegroundColor Green ; get-Item WSMan:\localhost\Client\TrustedHosts
write-host "-----------------------------------" -ForegroundColor Yellow
Write-host "should say alow delegate fresh and a domain name for host $myfqdn" -ForegroundColor Green
Get-WSManCredSSP -Verbose
write-host "-----------------------------------" -ForegroundColor Yellow

set-location "C:\Program Files\Dell\SysMgt\iDRACTools\racadm"

Write-host " THIS IS THE DRAC PORTION SETTINGS for $myfqdn" -ForegroundColor Cyan
write-host "-----------------------------------" -ForegroundColor Cyan
write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " OSINFO should be enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get idrac.servicemodule.osinfo 

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " ServiceModuleEnable  should be Enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get idrac.servicemodule.ServiceModuleEnable

write-host "-----------------------------------"-ForegroundColor Yellow
Write-host " AdminState  should be Enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get idrac.os-bmc.adminstate

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " hostheader   should be Disabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get iDRAC.WebServer.HostHeaderCheck

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " LCAttributes.LifecycleControllerState  should be enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get LifeCycleController.LCAttributes.LifecycleControllerState 

Write-host "-----------------------------------" -ForegroundColor Magenta

Write-host " This concludes " ; $myfqdn
Write-host "-----------------------------------" -ForegroundColor Magenta



}
}

# Test all node Node APIPA

function do-apipa
{

 Invoke-Command -computername (Get-ClusterNode).name -ScriptBlock {


$myFQDN=(Get-WmiObject win32_computersystem).DNSHostName+"."+(Get-WmiObject win32_computersystem).Domain 
$cresolve = Resolve-DnsName $myFQDN | Where-Object {$_.Type -ne "AAAA"}
$temp1APIP= ($cresolve | Where-Object IPAddress -imatch "169.254")
if ($temp1APIP.Count -gt 1) {$apips = "false"} # counter says there it soo many APipa address - please check
if ($temp1apip.Count -le 1) {$apips = "true" } # counter checking for no apipa
if ($temp1APIP.count -eq 1) {$apips = "exact"}
 
  $finalClusIP = @()

If ($apips -in "true,exact")  {
 #if apipa address is not there or one value- search wmi and see if there is an IP and find its ip address 

# pulling the usbnic apipa address to compare to the others. 
#$myusbnic = Get-NetAdapter Where {$_InterfaceDescription -eq  "Remote NDIS Compatible Device"}
$myusbnic = @(Get-NetAdapter -InterfaceDescription "Remote NDIS Compatible Device" | Get-NetIPAddress -AddressFamily "ipv4")

$myusbip = $myusbnic.IPAddress
$mytempfih = (get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=true and DHCPEnabled=true" -ComputerName . | Where-Object -FilterScript {$_.Description -contains "Remote NDIS Compatible Device"} | Select-Object -Property DHCPSERVER)
get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=true and DHCPEnabled=true" -ComputerName .
# if there is another apipa - it will be here 
  
 # the $myredishIP is the Drac Redfish IP in the drac we will compare this to the Host Apipa- do they ping? 
 $myRedishIP= ($mytempfih.DHCPSERVER)
 
}
 

 $a= $env:computername
if ($apips -eq "false"){

# IPV4 APipa Nic that is remote usb nic NDIS 169.254.1.96"}
$myusbnic = @(Get-NetAdapter -InterfaceDescription "Remote NDIS Compatible Device" | Get-NetIPAddress -AddressFamily "ipv4")

# 169.254.1.96
$myusbip = $myusbnic.IPAddress

# This is the Drac Apipa redfish address 169.254.1.95
$mytempfih = (get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=true and DHCPEnabled=true" -ComputerName . | Where-Object -FilterScript {$_.Description -contains "Remote NDIS Compatible Device"} | Select-Object -Property DHCPSERVER)


# $finalclusIP= ($temp1APIP.ipaddress | Where-Object -FilterScript {$_.Description -contains "Microsoft Failover Cluster Virtual Adapter"} )
# myfinal is supposed to be only cluster apipa (not Drac apipa) but not allways working 
  $myfinalClusIP =  @(Get-NetAdapter -InterfaceDescription "*Microsoft Failover Cluster Virtual Adapter*" | Get-NetIPAddress -AddressFamily "ipv4")
 $myRedishIP= ($mytempfih.DHCPSERVER )
 #$finalClusIP= Compare-Object -ReferenceObject $alpipper -DifferenceObject $myusbip 
$myfineinput = $myfinalClusIP

$finalclusIP= ($temp1APIP.IPAddress| Where-Object -FilterScript {$_.Description -ne "Remote NDIS Compatible Device"}) 
 # the $myredishIP is the Drac Redfish IP in the drac we will compare this to the Host Apipa- do they ping? 
 $myRedishIP= ($mytempfih.DHCPSERVER)
 # now I have the ip for Drac. I need to ping the IPMI IP in the pass-through myusbip and myredfiship

 #defining pings and execution
$Task1 = (New-Object System.Net.NetworkInformation.Ping).Send($myFQDN)
#SendPingAsync($myredfiship)
# Task1.status is the term success or fail of ping 
if ($task1.status -eq "success") {$Pingdns= "True"} else {$Pingdns= "false"}
########################
$Task = (New-Object System.Net.NetworkInformation.Ping).Send($myrediship)
#SendPingAsync($myredfiship)
$Task
if ($task.status -eq "success") {$fishstat= "True"} else {$fishstat= "false"}
####################################

 #now checking IP from DNS and non APipa addresses- IE the cluster IPs
 #verify DNS entry host and FQDN

$b = Resolve-DnsName -Name $a | where {$_.type -eq "A"}
$c = $b | where {$_.ipaddress -inotmatch "169.254"} 
$countip = $c.count
 
# C cycles over the found addresses and test connectivity
 $trask = new-object system.collections.arraylist
################################################################################
Write-host "=========================================" -ForegroundColor Magenta
write-host " Begining of Report : $env:computername " -ForegroundColor Cyan
Write-host "=========================================" -ForegroundColor Magenta
for ($i = 0; $i -lt ($countip-1) ; $i++)
 {
 $myip =  $c[$i].IPAddress
  # write-host " the Cluster IP is $c[$i].IPAddress"
 $Trask = (New-Object System.Net.NetworkInformation.Ping).Send($c[$i].ipaddress)
 #SendPingAsync($myredfiship)
 
if ($trask.status -eq "success") { write-host -NoNewline  $myip; Write-host "  $myip  <--------- IP Non Apipa -----------Ping Status Success" -ForegroundColor Green} 
else { write-host -NoNewline  $myip ; Write-host "  $myip <--------- IP Non Apipa -----------> Ping Status Fail " -ForegroundColor Yellow}
 
#this variable array has the results as true for success but i turned out not to need it. i may use anyway.
 
  }
 
 $ipmi1 = Get-service -name IPMIDRV

$ipmi2 = Get-PnpDevice -Class system -FriendlyName "microsoft Generic IPMI compliant device"
If ($ipmi1 -and $ipmi2) {$ipmi3= "True"} else {$ipmi3= "false"}


# alternate
#REG DELETE "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v LocalAccountTokenFilterPolicy
#net stop browser && net stop server && net start server && net start browser
#Cls

Write-host "-----------------------" -ForegroundColor Yellow
if ($ipmi3 = "true") { Write-host " $ipmi3 IPMI device present for $a? $ipmi3" -ForegroundColor Green} else { Write-host " $ipmi3 IPMI device present for $a? $ipmi3" -ForegroundColor yellow}
Write-host "-----------------------" -ForegroundColor Yellow   
if ($dnscorr = "true") { Write-host " $dnscorr Ping by name worked for $a?  $dnscorr" -ForegroundColor Green} else { Write-host " $dnscorr Ping by name worked for $a??  $dnscorr" -ForegroundColor yellow}
 
Write-host "-----------------------" -ForegroundColor Yellow
if ($Pingdns = "true") { Write-host " $Pingdns Dns Test to $env:computername results for $a $Pingdns" -ForegroundColor Green} else { Write-host " $Pingdns Dns Test to $env:computername for $a results" $Pingdns -ForegroundColor yellow}
 
Write-host "-----------------------" -ForegroundColor Yellow
if ($wmidns = "true") {Write-host " $wmidns Resolve by WMI to DNS success $wmidns for $env:computername" -ForegroundColor Green} else  {Write-host " $wmidns Resolve by WMI to DNS success for $env:computername $wmidns" -ForegroundColor yellow}
Write-host "-----------------------" -ForegroundColor Yellow

if ($apips -eq "true") {Write-host "Didnt find Apipa address. Falling back to check WINRM. If target test succeeds, ignore this error for $a " -ForegroundColor red}
if ($apips -eq "false") {Write-host "Found Multiple APipa address. one could be the CLuster Internal IP.for $a " -ForegroundColor Yellow}  
if ($apips -eq "exact") {Write-host "We found only the one Apipa address for $a " -ForegroundColor blue} 
Write-host " $myusbip <--- This is your Host  USB nic" -ForegroundColor Cyan
write-host " $myRedishIP <--- This is your Redfish Drac IP" -ForegroundColor Cyan

for ($bye=1 ; $bye -le  $temp1APIP.Count ; $bye++)
{
$newtruth = "true"
if ( !($myusbip -contains $temp1APIP.IPAddress[$bye])) {$newApipa = $temp1APIP.IPAddress[$bye] 

Write-host "---> $newapipa discovered <----  $newapipa We thing is the CLuster APipa Address but it may not be!!!! If this is not, then its a failure cause! check it! " -ForegroundColor Yellow
write-host "--------------------------" -ForegroundColor Yellow


} else {$newtruth = "false"}

Write-host " This is both values ->>>> $finalClusIP <----- If one of them is VMfleet OMIMSWAC wont run for $a! " -ForegroundColor Yellow
$myfineinput
Write-host "-----------------------" -ForegroundColor Yellow

# $myredfishIP and $mytempfih are the same value - the Drac IP redfish
# $myusbnic is the Usb host nic
#$myRedishIP is the redfish
 #$alpipper = $temp1APIP.ipaddress # Both IP of hostnic and cluster apipa - no hostnames
 #$finalclusIP cluster IP if there is one (apipa)
 Write-host " If i missed anything, this is all apipa addresses. You cant have multiples for $a"
 $alpipper = $temp1APIP.ipaddress # Both IP of hostnic and cluster apipa - no hostnames

 
 # this is the cluster IP or other? 
 Write-host "-----------------------" -ForegroundColor Yellow
 Write-host " This is both apipa ----> $alpipper <------------ for $a" -ForegroundColor Green
# $alpipper = $temp1APIP.ipaddress # Both IP of hostnic and cluster apipa
 
Write-host "-----------------------" -ForegroundColor Yellow
 
if ($ipmi3 = "true") {Write-host "The Ipmi Driver and Class are running true for $a " -ForegroundColor Green} else  {Write-host " IPMIdriver Class Issues found $a" -ForegroundColor yellow}
Write-host "-----------------------" -ForegroundColor Yellow
 
Write-host "-----------------------"
Write-host " $countip is the number of IP checked (non redfish)for $a " -ForegroundColor green
 
Write-host "-----------------------" -ForegroundColor Yellow
 
 
Write-host "-----------------------" -ForegroundColor Yellow
 
if ($dnscorr -eq "true") {Write-host "Checked local DNS compared to DC dns and result is  $dnscorr for $a" -ForegroundColor Green} else  {Write-host "Checked local DNS compared to DC dns and result is  $dnscorr for $a" -ForegroundColor yellow}
Write-host "-----------------------" -ForegroundColor Yellow
  

Write-host "-----------------------" -ForegroundColor Yellow
 
Write-host "===========END of Report for $env:computername =====================================================" -ForegroundColor Magenta
 write-host "$fishstat is the indication that the Drac IP pings the USBNIC IP so $myrediship connectivity test is passing" -ForegroundColor Green
 Write-host " SCROLL UP TO SEE ALL THE RESULTS!. Dont hit enter or you loose the report!" -ForegroundColor Magenta
 write-host "that means dont hit enter until you read it!" -ForegroundColor Magenta
 Write-host "================================================================" -ForegroundColor Magenta

 #enable UAC
 

} 

}
}
}

function do-additionaltest
{

param($mymachine)


Invoke-Command -ComputerName (get-clusternode).Name -ScriptBlock {

Enable-NetFirewallRule -name WMI-WinMgmt-In-TCP, WMI-RPCSS-In-TCP

Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any 
 #port on port 445

  New-NetFirewallRule -DisplayName "Allow smb 445 in" -Direction inbound -Profile Any -Action all -LocalPort 445 -Protocol TCP
  New-NetFirewallRule -DisplayName "Allow smb 445 out" -Direction outbound -Profile Any -Action all -LocalPort 445 -Protocol TCP
   

#port on port 5685
  
 
  New-NetFirewallRule -DisplayName "WINRM-HTTP-In-TCP-PUBLIC" -Direction inbound -Profile Any -Action all -LocalPort 5685 -Protocol TCP
  New-NetFirewallRule -DisplayName "WINRM-HTTP-Out-TCP-PUBLIC" -Direction outbound -Profile Any -Action all -LocalPort 5685 -Protocol TCP
    
#rulechek 
Write-host "Rule check $env:computername ---------------------------" -ForegroundColor Cyan
$rule = "Allow smb 445"
Get-NetFirewallRule -DisplayName $rule | ft -Property Name, DisplayName, @{Name='Protocol';Expression={($PSItem | Get-NetFirewallPortFilter).Protocol}}, @{Name='LocalPort';Expression={($PSItem | Get-NetFirewallPortFilter).LocalPort}}, @{Name='RemotePort';Expression={($PSItem | Get-NetFirewallPortFilter).RemotePort}}, @{Name='RemoteAddress';Expression={($PSItem | Get-NetFirewallAddressFilter).RemoteAddress}}, Enabled, Profile, Direction, Action

$rule = "WINRM-HTTP-In-TCP-PUBLIC"
Get-NetFirewallRule -DisplayName $rule | ft -Property Name, DisplayName, @{Name='Protocol';Expression={($PSItem | Get-NetFirewallPortFilter).Protocol}}, @{Name='LocalPort';Expression={($PSItem | Get-NetFirewallPortFilter).LocalPort}}, @{Name='RemotePort';Expression={($PSItem | Get-NetFirewallPortFilter).RemotePort}}, @{Name='RemoteAddress';Expression={($PSItem | Get-NetFirewallAddressFilter).RemoteAddress}}, Enabled, Profile, Direction, Action

Write-host " $env:computername is enabled for port 445 unless you see a failure"
Write-host " TESTING $USING:mymachine -----------------------------------------" -ForegroundColor Cyan
$ports = 445,5985
#portcheck 
Write-host "Port  check $env:computername -----------------------------" -ForegroundColor Cyan
$ports | ForEach-Object {$port = $_; if (Test-NetConnection -ComputerName "$env:COMPUTERNAME" -Port "$port" -InformationLevel Quiet -WarningAction SilentlyContinue -ErrorAction SilentlyContinue) {"Port $port is open" } else {"Port $port is closed"} }



}


} 



do
 {
    Show-Menu
     $selection = Read-Host "Please make a selection"
     switch ($selection)
     {    
           '1' {
             'Install Idrac tools'
             Do-Idrac
       }   '2' {
             'Install ISM'
            Do-ISM
         } '3' {
             'results of install'
             check-work
         } '4' {
             'check apipa addresses'
              Do-apipa
        }  '5' {
             'check apipa addresses'
             do-additionaltest
        }
        
         }
     pause
 }

 until ($selection -eq 'q')