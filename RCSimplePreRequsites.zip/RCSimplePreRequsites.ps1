﻿# Get the ID and security principal of the current user account
$myWindowsID=[System.Security.Principal.WindowsIdentity]::GetCurrent()
$myWindowsPrincipal=new-object System.Security.Principal.WindowsPrincipal($myWindowsID)
 
# Get the security principal for the Administrator role
$adminRole=[System.Security.Principal.WindowsBuiltInRole]::Administrator
 
# Check to see if we are currently running "as Administrator"
if ($myWindowsPrincipal.IsInRole($adminRole))
 
   {
   # We are running "as Administrator" - so change the title and background color to indicate this
   $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)"
   $Host.UI.RawUI.BackgroundColor = "DarkBlue"
   clear-host
 
   }
else
   {
   # We are not running "as Administrator" - so relaunch as administrator
 
   # Create a new process object that starts PowerShell
   $newProcess = new-object System.Diagnostics.ProcessStartInfo "PowerShell";
 
   # Specify the current script path and name as a parameter
   $newProcess.Arguments = $myInvocation.MyCommand.Definition;
 
   # Indicate that the process should be elevated
   $newProcess.Verb = "runas";
 
   # Start the new process
   [System.Diagnostics.Process]::Start($newProcess);
 
   # Exit from the current, unelevated, process
   exit
 
   }
  
  $myspanser = read-host "what is the cluster name we are working on? "
  $myspanse = get-cluster
  $global:mydom 
 $mydom = $env:USERDOMAIN
 $myuser= $env:username
$global:creds = Get-Credential -UserName $mydom\$myuser -Message "Creds for OMIMSWAC Repair"
 

 


 
 
 
 #Be Sure to use a : instead of a $ for the username variable
$global:mymachine= $env:COMPUTERNAME
$my=@()
$where2 ="C:\users\$env:username\downloads\RCSimplePreRequisites"
set-location -Path "C:\users\$env:username\downloads\RCSimplePreRequisites"
Push-Location -Path $where2 
$myloc= $where2 
$mycluster= Get-Cluster -Name $myspanser
$mynodes = Get-ClusterNode -Cluster $mycluster | Select-Object name
#$counter = (@($mynodes).name).Count
$my= (@($mynodes).name) 
$computername = $my -split " "
$selection = "a"

function Show-Menu
{
    param (
        [string]$Title = 'Menu For OMIMSWAC Help'
    )

    Clear-Host
    Write-Host "================ $Title ===================================================================" -ForegroundColor Green
     
    Write-host " Offline Setup and test menu" -ForegroundColor Green
    Write-host " ===========================================================================================" -ForegroundColor Green

    Write-Host "1: doidrac   '1' IDracTools install and pre-requisites" -ForegroundColor Green
    Write-Host "2: doism     '2' Install ISM" -ForegroundColor Green
    Write-Host "3: checkwork '3' Verification of steps 1 and 2 " -ForegroundColor Green
    Write-Host "4: chkip     '4' Check IP and USB NIC connectivity" -ForegroundColor Green
    Write-Host "5: moretes   '5' Fix port 445 and winrm 5985 " -ForegroundColor Green
    write-host "6: fixstuf   '6' Multi Item Menu- Fixes 4 cluster history, CAU repair,remove usbnic from cluster comms, restart all dracs" -ForegroundColor Green
    write-host "7: getlogs   '7' Getting logs -provide a share location. run this one cluster node and again on the WAC server.  " -ForegroundColor Green
    write-host "8: tshot     '8' Multi Item Menu Redfish, Delegation, Wac Install, USBRepair" -ForegroundColor Green
    write-host "9: dprox     '9' Proxy exceptions or other proxy setup" -ForegroundColor Green
    Write-Host "Q: Press     'Q' to quit."
}

Write-host " Option 6 Fix stuff with cluster fixes, fix usb nic, remove drac nic cluster communications and install wac on server" -ForegroundColor Magenta
Write-host "==============================================================================" -ForegroundColor Magenta
function fixstuf
{
 $where2 ="C:\users\$env:username\downloads\RCSimplePreRequisites"
  set-location -Path "C:\users\$env:username\downloads\RCSimplePreRequisites"
   
 $global:where2 
 
set-location -Path $where2
set-location $where2
Push-Location -Path $where2 
$myloc= $PWD.Path 
#CLs 
 $pwd

$Destination = "C$\Users\$Env:Username\downloads" #Be Sure to use a : instead of a $ for the username variable
$global:mymachine= $env:COMPUTERNAME
$my=@()
$mycluster= Get-Cluster -Name $myspanser
$mynodes = Get-ClusterNode -Cluster $mycluster | Select-Object name
#$counter = (@($mynodes).name).Count
$my= (@($mynodes).name) 
$computername = $my -split " "
 Write-host "==============Fix Stuff Sub Routine==============================================================="
 cls

 function blemu {
    param (
        [string]$Title = 'We love fixe'
    )
    Clear-Host
    Write-Host "================ $Title ================"
    
    Write-Host "1: cluhis  '1' Repair cluster performance history."
    Write-Host "2: fixcau  '2' Repair Cluster aware update."
    Write-Host "3: cluscom '3' Remove the USBNIC from cluster communications."
    Write-Host "4: resdrac '4' Restart all dracs will not harm production servers."
    Write-Host "5: rolcal  '5' *Multi test open firewall,reset Cluster perf history, drac racreset, fix CAU if already setup with VCO ."
    Write-Host "Q: Press   'Q' to quit."
}

function rolcal
{

Write-host " This section will present you with some output that you should review. This may mean you may need to make corrections manually. "
Write-host " We may correct some items as well" 
Write-host " =========================================" -ForegroundColor Green
Write-host " Testing cluster communication to port 445 smb"

Test-netConnection -ComputerName ($myspanser) -Port 445
Write-host " =========================================" -ForegroundColor Green

Read-host " If resultes of port 445 fail, you will need to run a cluster validation. hit enter to move to next test. "

clear-host
Invoke-command -computername (get-clusternode).name -ScriptBlock {Get-NetFirewallProfile | Format-Table Name, Enabled}

Write-host "If your OMIMSWAC fails to update, you can disable all profiles on all servers here for testing."
$simplejack = read-host " Do it now? y/n then hit enter"

if ($simplejack -ilike '*y*') {Invoke-command -computername (get-clusternode).name -ScriptBlock {Set-NetFirewallProfile -Profile Domain, Public, Private -Enabled False}}

read-host "next test port 135 and 5985 (5985) will partially fail. look for pingsuceeded. tcptestsucceed can fail. - hit enter"

Test-NetConnection $myspanser -port 135
Test-NetConnection $myspanser -port 5985

Write-host " If these fail fail then you will need to run cluster validation"
$simplejk1= read-host = "next section is going to check DC connectivity to all nodes in cluster y=go ahead and n=skip"

if ($simplejk1 -like '*y*')
{
clear-host
Invoke-Command -ComputerName (get-clusternode).name -ScriptBlock {


 $myname = $env:computername + "." +$env:USERDNSDOMAIN 
 Write-host " $env:computername Test DC connectivity" -ForegroundColor Green 
 Nltest /Server:$myname /query

 }
 }

 read-host "Does the output look like your ok to move to the next section? If not stop and check AD. Y= move on." 

 $myreport = read-host "please enter a path for where you want your cluster validation report called Dellreport.htm?. example entry: c:\users\$env:username\desktop"
 
 If($myreport.EndsWith('\')){
$myreport = $myreport -replace '\\$',""}
write-host " Now running cluster validation " 
 test-cluster -ReportName "$myreport\Dellreport.html" -Cluster $myspanser -Force


Read-host "see cluster report at $myreport\Dellreport.html. Hit a key to continue"
write-host " Now we are just showing you any evidence of a certificate role and any certificates"
invoke-command (get-clusternode).name -scriptblock {

Write-host "now checking dcom firewall on $env:computername. I added a certificate check here too, maybe not so important but its here for view."
 netsh advfirewall firewall show rule name="windows management instrumentation (async-in)"
 netsh advfirewall firewall show rule name="windows management instrumentation (wmi-out)"
 netsh advfirewall firewall show rule name="windows management instrumentation (wmi-in)"
 netsh advfirewall firewall show rule name="windows management instrumentation (dcom-in)"

  certutil -ping
  $computer='localhost';
$ro=[System.Security.Cryptography.X509Certificates.OpenFlags]"ReadOnly"
$lm=[System.Security.Cryptography.X509Certificates.StoreLocation]"LocalMachine"
$store=new-object System.Security.Cryptography.X509Certificates.X509Store("\\$computer\My",$lm)
$store.Open($ro)
$certificates=$store.Certificates
  $certificates | select subject



  }


Write-host " take action if needed and run again if needed. This is the end of the section"

 Read-host " this concludes the checks for now. Dont hit enter until you have reviewd all you need to see"



 #future checks
 
#Now returned All ip are tested, no only need to check other things 
# get-wmiobject mscluster_resourcegroup -namespace "ROOT\MSCluster"
# netstat -ano | findstr "135"
# get-netAdapter -includeHidden | where {$_.interfaceDescription -match 'failover'}
#Set-NetFirewallProfile -Profile Domain, Public, Private -Enabled False
#Get-NetFirewallProfile | Format-Table Name, Enabled


# get-clusterNetwork | ft name,address,role
 #add-CAUclusterRole -daysOfWeek saturday -weeksOfMonth 1 -requireAllNodesOnline -maxFailedNodes 1 -enableFirewallRules -CAUpluginName Microsoft.WindowsUpdatePlugin -virtualComputerObjectName myCluster-CAU -groupName myCluster-CAU
 #test-connection -Protocol DCOM -ComputerName -port 445

# "sc query Winmgmt && sc query rpcss"

# service Remote Procedure Call (RPC) is running (OK)
 #Test-NetConnection IP -port 135 (OK)
 #Test-NetConnection IP -port 49703 (WARNING: TCP connect to (IP : 49703) failed)



}


Function resdrac
{

clear-host
write-host " This will reset the dracs in the cluster. each drac will reset. no data is lost and the server stays in productions durring the whole process" -ForegroundColor Green
read-host " Ready then hist a hey and or enter"

invoke-command -computername (get-clusternode).name -scriptblock {

set-location 'C:\Program Files\dell\SysMgt\iDRACTools\racadm'

.\racadm.exe racreset -f   
}

Write-host "Each Drac has been reset. This will take about 5 minutes and you can contunue and go do updates" 
}


Function  cluhis
{


Stop-clusterperformancehistory -deletehistory
start-clusterperformancehistory
Get-ClusterResource -Name "Cluster Virtual Disk (ClusterPerformanceHistory)"
Get-ClusterResource | where-object {$_.resourcetype.name -eq "Health Service"}
Get-ClusterResource | where-object {$_.resourcetype.name -eq "Health Service"} | Stop-ClusterResource
Get-ClusterResource | where-object {$_.resourcetype.name -eq "Health Service"} | start-ClusterResource

read-host " Cluster communication cleared. Wait 5 minutes and run  Get-ClusterPerformanceHistory. As long as it completes, this section is complete. Hit enter to complete."

}


function fixcau
{



<###################################################

CAU may look like the issue. there is basic troubleshooting

here and the steps to setup the CAU VCO and ROLE. 





####################################################>

Clear-Host
Write-host " there are two choices in this section." -ForegroundColor Green
Write-host " 1. You have configured CAU and you want an automated repair (reinstall)." -forgroundcolor yellow
Write-host " 2. You dont have CAU configured but you have created a computer Object (VCO) in the cluster OU and added it to the OU above the cluster with full write/create objects permissions." -forgroundcolor yellow
Write-host " 3. If you dont meet the criteria for 1 or 2- then your only other option is to create the VCO and then use cluster manager or choice 2 to setup CAU." -ForegroundColor Green
Write-host "===================================" -ForegroundColor Green 
$read3ans = Read-Host " What is your choice? 1= Reinstall (already setup) 2= Deploy CAU and I have a VCO to enter 3=Quit and I will use cluster manager to setup CAU"

If ($read3ans -eq "1"){

#$b=@()
#$a = read-host "enter cluster name"
#$b= Test-CauSetup -ClusterName $a 

Get-ClusterResource  "Distributed Network Name"
 
$myclustername = $myspanser
$CAUName= (Get-Cluster $myclustername | Get-ClusterParameter -Name CauCredentialResourceName).Value
$CVOName = (Get-Cluster $myclustername | Get-ClusterParameter -name CauResourceName).Value

Remove-CauClusterRole -ClusterName $myclustername -Force

Get-Cluster $myclustername  | get-ClusterParameter "CauResourceName" 
Get-Cluster $myclustername  | Set-ClusterParameter "CauResourceName" -Delete

Get-ClusterResource -Name $CAUName | Remove-ClusterResource
Get-ClusterResource -Name $CVOName | Remove-ClusterResource


write-host "Wait 10 seconds-Then RUN GET-CLUSTERRESOURCE and see that the CAU objects are gone.those names are printed below" -ForegroundColor Green
$CVOName
$CAUName
Read-host "Once you verified the objects are gone, hit  enter and we will auto fix the role back properly."

Add-CauClusterRole -ClusterName $myclustername -MaxFailedNodes 0 -RequireAllNodesOnline -EnableFirewallRules -VirtualComputerObjectName $CVOName -Force -CauPluginName Microsoft.WindowsUpdatePlugin -MaxRetriesPerNode 3 -CauPluginArguments @{ 'IncludeRecommendedUpdates' = 'False' } -StartDate "3/2/2020 3:00:00 AM" -DaysOfWeek 4 -WeeksOfMonth @(3) -verbose

 
 
}  





If ($read3ans -eq "2"){

clear-host
Write-host " You need to run get-clusterresource and make sure CAU distributed network name is gone. If its gone, create the VCO in AD and set permissions per the documentaiton" 
Write-host " If you have the name, then continue."
$CVOName = Read-host " What is the VCO name you created? "


Add-CauClusterRole -ClusterName $myclustername -MaxFailedNodes 0 -RequireAllNodesOnline -EnableFirewallRules -VirtualComputerObjectName $CVOName -Force -CauPluginName Microsoft.WindowsUpdatePlugin -MaxRetriesPerNode 3 -CauPluginArguments @{ 'IncludeRecommendedUpdates' = 'False' } -StartDate "3/2/2020 3:00:00 AM" -DaysOfWeek 4 -WeeksOfMonth @(3) -verbose

Write-host " The CAU is installing Wait 5 minutes and check get-clusterresource"

}

If ($read3ans -eq "3"){Write-host "Exiting. Thank you for using cluster manager to enable CAU. Pre-create the CVO first" ; start-sleep(3)}


}


Function cluscom
{

 
 Clear-Host
 Write-host " This final step in this section will attempt to disable the USB nic from the cluster communication." -ForegroundColor Green

 Write-host "Please open cluster manager and confirm the USBNIC network is showing under networks." -ForegroundColor Green
 Write-host " come back to step 2 after discovery if needed to diable cluster communicaiton for the USBNIC network" -ForegroundColor Green
 
 
 Get-ClusterNetwork | Format-Table Name, Metric
$my169net = Get-ClusterNetwork | sort-object metric
$my169max = ($my169net| Select-Object -last 1)

write-host "$my169max we are removing this network from cluster communications" -ForegroundColor Yellow
Write-host "$my169max is the network we identified to remove from cluster communications. Please verify in the network section of cluster manager. this should be the NDIS compatible device nics" -ForegroundColor Green
$myread69 = Read-host "please hit Y and enter to confirm this network is ok to disable for cluster communicaiton"

if ($myread69 -ilike '*y*') {$my169max.role = 0 } 

$myusbnic1 = Get-NetAdapter -InterfaceDescription "Remote NDIS Compatible Device" 

$myusbnic1| Disable-NetAdapter
$myusbnic1 | Enable-NetAdapter

Clear-Host
Write-host "USB Network now removed from cluster network communications"  -ForegroundColor Green
read-host "hit a key or enter to continue"   

}



do
 {
    blemu
    $selection = Read-Host "Repair Options for OMIMSWAC"
    switch ($selection)
    {
    '1' {
    'Option 1 is for cleanup Cluster History'
    cluhis
    } '2' {
    'Option 2 is to fix cluster aware update'
    fixcau
    } '3' {
      'is to remove usb network from cluster communications'
      cluscom
   }   '4' {
      'Restart all dracs in cluster. will not hurt server'
      resdrac

   } '5' {
      'multi-test'
     rolcal

        }
    }
    
    pause
 }
 until ($selection -eq 'q')


write-host "==========OMIMSWACTOOL====================" -ForegroundColor Green


}

Write-host "============================================" -ForegroundColor Magenta
Function getlogs {

#Enter-PSSession -ComputerName $Chlost
$datet= (Get-Date).AddDays(-1)
 $mycluster8= $myspanser
#$mynode8= Get-ClusterNode -Name $mycluster8
$revs = @(Get-ClusterNode -Cluster $mycluster8)
 
 
$Uusername= $env:USERNAME
Clear-Host
$destination = Read-host "please put a unc path to a share for backup \\host\folder. If your not backing up, stop the script and comment out the copy-item lines"
#$destination = "\\gsejumpbox\repositoryDSU\backup"
$ans11= read-host "Ready to backup logs? Y or N"

If($destination.EndsWith('\')){
$destination = $destination -replace '\\$',""
}
foreach ($myrev in $revs)
{
 

    
 $MainLogs = "\\$myrev\c$\Windows\ServiceProfiles\NetworkService\Appdata\Local\Temp\generated\"
 $pushfiles = "\\$myrev\c$Windows\Temp\OMIMSWAC\"
$Failedupdate= "\\$myrev\c$\ProgramData\Server Management Experience\Extensions\dell-emc.openmanage-integration.2.2.1\"
$Duplog = "\\$myrev\c$\temp\sme\dell-emc.openmanage-integration.2.2.1\"
$updatelog = "\\$myrev\c$\Users\*\appdata\roaming\update\log\"
$applogs1= "\\$myrev\c$\Users\$Uusername\AppData\Roaming\Update\"
$applogs2 = "\\$myrev\c$\Users\$Uusername\AppData\Roaming\compliance\"
    $Share1= "\\$myrev\c$\Users\$Uusername\AppData\Local\Temp\CAU\"

 $finalDest = join-path $destination $myrev
   if (!(Test-Path $finaldest)) { mkdir $finalDest }
   

 #Set-Location $share1 -PassThru
    Set-Location -Path $share1
    $debug=@()
    $bugstore=@()
    $share1
   

#if (!(Test-Path $destination)) { mkdir $rev.Id }
#$finalDest = "$destination$rev"

$debug = Get-ChildItem -Path $Share1 -Recurse | Where-Object {$_.CreationTime -gt ($datet)}
    #$debug = Get-childItem -Path $Share1 -Filter *.etl


    #$debug = (Get-Item -Path $Share1).LastWriteTime
    Foreach ($bug in $debug)
    {
    Try {

    invoke-expression " Netsh Trace Convert $bug" 

    } Catch {Write-host "THis file wont convert" -ForegroundColor Green  }


    $bugstore = Get-ChildItem -Path $Share1 -Recurse *.txt
    }

copy-item $MainLogs -Recurse $finalDest  -verbose
copy-item $pushfiles -Recurse $finalDest  -verbose
copy-item $Failedupdate -Recurse $finalDest  -verbose
copy-item $Duplog -Recurse $finalDest -verbose
copy-item $updatelog -Recurse $finalDest  -verbose
copy-item $applogs1 -Recurse $finalDest  -verbose
copy-item $applogs2  -Recurse $finalDest  -verbose
#copy-item $Share1 -recurse $finaldest -Verbose
copy-item $bugstore -Recurse $finalDest -Verbose
if ( $ans11 -like '*Y*')
 {

Remove-Item -Path "$mainlogs\*" -Recurse -force
Remove-Item -Path "$share1\*" -Recurse -force
Remove-Item -Path "$pushfiles\*" -Recurse -force
Remove-Item -Path "$updatelog\*" -Recurse -force
Remove-Item -Path "$applogs1\*" -Recurse -force
Remove-Item -Path "$applogs1\*" -Recurse -force
Remove-Item -Path "$applogs2\*" -Recurse -force
#Remove-Item -Path "$applogs3\*" -Recurse -force
Remove-Item -Path "$Failedupdate\*" -Recurse -force
}
   





}

If ($env:computername -notin $revs)
{
Write-host " Is this the WAC server? " -ForegroundColor Green
$iswac= read-host " Hit y to proceed or n. I am going to collect logs if you type y" 

If ($iswac -ne "n")
{
#### WAC sererlogs

#$destination = Read-host "please put a unc path to a share for backup \\host\folder. If your not backing up, stop the script and comment out lines 518-520"
$rev= "WAC"
 

if (!(Test-Path $destination)) { mkdir $rev }
$finalDest = "$destination$rev"
$clearWAClog= "C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Temp\generated\"
$dellDupLog = "C:\ProgramData\Dell\DELL EMC System Update"
$dsuInstaller = "C:\ProgramData\Dell\UpdatePackage\log"

copy-item $clearWAClog -Recurse $finalDest  -verbose
copy-item $dellDupLog -Recurse $finalDest  -verbose
copy-item $dsuInstaller -Recurse $finalDest  -verbose

Remove-Item -Path "$clearWAClog\*" -Recurse -Force
Remove-Item -Path "$dellDupLog\*" -Recurse -Force
Remove-Item -Path "$dsuInstaller\*" -Recurse -Force


Write-host "Files are copying to the share you specified. hit a key to continue" -ForegroundColor Green; read-host '$myans12'
} else {Write-host "no Wac logs collected"}


# try tommys 
# $bugstore.fullname | %{Start-Process -FilePath "Netsh.exe" -ArgumentList @("Trace","Convert","$_")}

}

}


Write-host "===============COPY FILE=============================" -ForegroundColor Magenta
Function Copy-File
{
  [Cmdletbinding()]
  Param(
   [Parameter(ValueFromPipeline=$true,Mandatory=$true)]
    [String[]]$ComputerName,
   [Parameter(ValueFromPipeline=$true,Mandatory=$true)]
    [String]$Path,
   [Parameter(ValueFromPipeline=$true,Mandatory=$true)]
    [String]$Destination
   
)
  Process {
   #Extract FileName from Path
   $File = $Path.Split('\')
   $File = $File[$File.Length-1]

# Computername - is all nodes in cluster
# $path = local location of file - 
# Destination will be the target location download folder destination gets a star for secret share 
#final path will be computer\destination

  ForEach ($Computer in $ComputerName)
  {
    $CopytoDest=""
    $CopytoDest = "\\$computer\$Destination"
    Write-Verbose "Starting copy to $Computer"
    IF(Test-Path $CopytoDest)
    {
     Write-Verbose "Folder $Destination exists on $Computer"
    }
    ELSE
    {
     Write-Verbose "Creating folder $Destination on $Computer"
    }
 
   Write-Verbose "Copying $File to $Computer"
   TRY
   {
    If (Copy-Item -Path $Path -Destination $CopytoDest -Force) { Write-Host "Copied to $CopytoDest\$File`n" -ForegroundColor GREEN
   } 

   }    CATCH
   {
    Write-Warning "Copy failed to $Computer`n"
    
   } 
     

   }
   }
   }
   

Write-host "===============DO IDRAC =============================" -ForegroundColor Magenta
 
 function doidrac
 {
 
 #install IDrac tools
clear-host 


$where2 = set-location "C:\users\$env:username\downloads\RCSimplePreRequisites"
Push-Location -Path $where2 

$myloc= $where2 
#CLs 
 $pwd
$global:mymachine
if ( $env:COMPUTERNAME -in (get-clusternode).Name) {Write-host " We Need to be on a clusternode! We are on a cluser node! Good Job! "
$simcity=""
 $simcity = read-host " We now need some input from you. May I use the internet to download needed item? 1= Yes 2=no"

if ($simcity -like '*1*'){
#but not today!
# maybe use this sometime https://duffney.io/using-powershell-markdown-cmdlets/
#Install-Module -Name ConvertFromMarkdown -RequiredVersion 1.0.0
#https://social.technet.microsoft.com/wiki/contents/articles/30591.convert-markdown-to-html-using-powershell.aspx
#https://github.com/xoofx/markdig
Clear-Host
$cntr = (get-clusternode).Name
Write-host "checking and installing Racadm Tools if needed. You may have to answer menu items $cntr.count number of times, once per cluster node "
Write-host " you may see results below. this is just a check if ISM also installed any failure is fixed in step"


Invoke-Command -ComputerName (Get-ClusterNode).name -ScriptBlock { 
    # Check if racadmin is installed
        $racadminIsInstalled=Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where-Object{$_.DisplayName -imatch "idrac tools"} |  Select-Object DisplayName, DisplayVersion, Publisher, InstallDate | Format-Table –AutoSize
    # If not then download and install racadmin tools
        If(!($racadminIsInstalled)){
            Try {
                Write-Host "Downloading RACAdmin Tools..."  
                # alternate link https://dl.dell.com/FOLDER05171522M/1/OM-DRAC-Dell-Web-WINX64-9.2.0-3142_A00.exe          
                Invoke-WebRequest -UseBasicParsing -Uri 'https://downloads.dell.com/FOLDER07549599M/1/DellEMC-iDRACTools-Web-WINX64-10.2.0.0-4583_A00.exe' -OutFile "$where2\racadmininstall.exe" -ErrorAction SilentlyContinue -ErrorVariable RACAdminDownloadFailed }
            Catch{
                Write-Host "ERROR: RACAdmin Tools download failed." -ForegroundColor Red
                
            }
            Try {
                Write-Host "Expanding RACAdmin Tools..."
                Start-Process -FilePath "$where2\racadmininstall.exe" -ArgumentList "/auto" -Wait -ErrorAction SilentlyContinue -ErrorVariable RACAdminExtractFail }
            Catch {
                Write-Host "ERROR: Failed to extract RACAdmin tools" -ForegroundColor Red
                
            }
            Try {
                Write-Host "Installing RACAdmin Tools..."
                Start-Process -FilePath "C:\OpenManage\iDRACTools_x64.msi" -ArgumentList '/quiet /norestart' -Wait -ErrorAction SilentlyContinue -ErrorVariable RACAdminInstallFail}
            Catch {
                Write-Host "ERROR: Failed to isntall RADAdmin Tools." -ForegroundColor Red
               
            }}
            
          # RACAdmin Checks
        Try{Set-Location 'C:\Program Files\Dell\SysMgt\iDRACTools\racadm'
            $RACAdminChecks=[PSCustomObject]@{
                osinfo = ((.\racadm.exe get idrac.servicemodule | Where-Object{$_ -imatch 'osinfo'}) -split '=')[-1]
                ServiceModuleEnable = ((.\racadm.exe get idrac.servicemodule | Where-Object{$_ -imatch 'ServiceModuleEnable'}) -split '=')[-1]
                ServiceModuleState = ((.\racadm.exe get idrac.servicemodule | Where-Object{$_ -imatch 'ServiceModuleState'}) -split '=')[-1]
                adminstate = ((.\racadm.exe get idrac.os-bmc.adminstate | Where-Object{$_ -imatch 'adminstate'}) -split '=')[-1]
                HostHeaderCheck = ((.\racadm.exe get iDRAC.WebServer.HostHeaderCheck | Where-Object{$_ -imatch 'HostHeaderCheck'}) -split '=')[-1]
                LifecycleControllerState = (.\racadm.exe get LifeCycleController.LCAttributes.LifecycleControllerState)[0]
            }
            $RACAdminChecks
            If($RACAdminChecks.osinfo -ne 'Enabled'){.\racadm.exe set idrac.servicemodule.osinfo 1}
            IF($RACAdminChecks.ServiceModuleEnable -ne 'Enabled'){.\racadm.exe set idrac.servicemodule.ServiceModuleEnable 1}
            IF($RACAdminChecks.adminstate -ne 'Enabled'){.\racadm.exe set idrac.os-bmc.adminstate 1}
            IF($RACAdminChecks.HostHeaderCheck -ne 'Disabled'){.\racadm.exe set iDRAC.WebServer.HostHeaderCheck 0}
            IF($RACAdminChecks.LifecycleControllerState -ne 'Enabled'){.\racadm.exe set LifeCycleController.LCAttributes.LifecycleControllerState 1}


Set-Executionpolicy -executionpolicy remotesigned -Force
Set-Item WSMan:\localhost\Client\TrustedHosts * -Force
 

Enable-WSManCredSSP -Role Client -Delegate $env:USERDNSDOMAIN -force
Enable-WSManCredSSP -Role Server -Force
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192 -Force
New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowFreshCredentialsWhenNTLMOnly -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name 1 -Value * -PropertyType String -Force
  Read-host " Install and cleanup complete $env:computername. Hit a key to continue"
        } Catch {Write-host "Failures so aborting "}  
            
            }
        

Set-Executionpolicy -executionpolicy remotesigned -Force
Set-Item WSMan:\localhost\Client\TrustedHosts * -Force
 

Enable-WSManCredSSP -Role Client -Delegate $env:USERDNSDOMAIN -force
Enable-WSManCredSSP -Role Server -Force
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192 -Force
New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowFreshCredentialsWhenNTLMOnly -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name 1 -Value * -PropertyType String -Force
 
 }  

  if ($simcity -notlike '*1*'){ # I cant use the internet to get the files 
  $freeguy1=""
clear-host
$freeguy1= read-host "The github instuctions should tell you to manually download the idrac tools and the Dell ISM Installer. Have you done that mate? 1=y and 2=n"


if ($freeguy1 -like '*1*'){ # I have the files and now telling user to rename and place in the correct directory 
clear-host 
write-host -NoNewline "Good job! now pay attention. Rename the drac file to " -ForegroundColor white
write-host -NoNewline "racadmininstall.exe" -ForegroundColor Green
write-host -NoNewline " and the ISM module rename to " -ForegroundColor White
write-host "isminstall.exe" -ForegroundColor Green
$where2 = "C:\users\$env:username\downloads\RCSimplePreRequisites"
set-location -Path $where2
$youdone= ""
$youdone = read-host "You MUST place the renamed files into this location $where2. Is this done? 1=y and 2= n. stop the script if your not in alighnment at this point"
 

   $my=@()
   $myspanser= get-cluster
$mycluster= Get-Cluster -Name $myspanser
$mynodes = Get-ClusterNode -Cluster $mycluster | Select-Object name
#$counter = (@($mynodes).name).Count
$my= (@($mynodes).name) 
$computername = $my -split " "
$Path = "c:\users\$env:username\downloads\RCSimplePreRequisites\racadmininstall.exe" 
$Destination = "C$\Users\$Env:Username\downloads"
 set-location -Path "C:\users\$env:username\downloads\RCSimplePreRequisites"

#Quick Variables
Copy-File -Verbose $computername $Path $Destination
Write-host "Copying.... "


if ($youdone -like '*1*') {

  $racadminIsInstalled=Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where-Object{$_.DisplayName -imatch "idrac tools"} |  Select-Object DisplayName, DisplayVersion, Publisher, InstallDate | Format-Table –AutoSize
    # If not then download and install racadmin tools
        If(-not($racadminIsInstalled)) 
 { 
    Invoke-Command -computername (Get-ClusterNode).name -ScriptBlock 
 {
                                    {
$ISMInstalled = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where-Object{$_.DisplayName -imatch "Dell EMC iDRAC Service Module"} |  Select-Object DisplayName, DisplayVersion, Publisher, InstallDate | Format-Table –AutoSize
Try
{
 
Start-Process -FilePath  "C:\users\$env:username\Downloads\racadmininstall.exe" -ArgumentList "/auto" -Wait -ErrorAction SilentlyContinue -ErrorVariable RACAdminExtractFail}
catch{Write-host "Didnt work. Comms issue with at least one node"}

}


    } #I have the files or am willing do download the files, rename and copy to the right place

    Invoke-Command -computername (Get-ClusterNode).name -ScriptBlock {
    Try{Start-Process -FilePath "C:\OpenManage\iDRACTools_x64.msi" -ArgumentList '/quiet /norestart' -Wait -ErrorAction SilentlyContinue -ErrorVariable RACAdminInstallFail} 

    catch {Write-host "we were able to extract but not install"}
}

# RACAdmin Checks
        Try{Set-Location 'C:\Program Files\Dell\SysMgt\iDRACTools\racadm'
            $RACAdminChecks=[PSCustomObject]@{
                osinfo = ((.\racadm.exe get idrac.servicemodule | Where-Object{$_ -imatch 'osinfo'}) -split '=')[-1]
                ServiceModuleEnable = ((.\racadm.exe get idrac.servicemodule | Where-Object{$_ -imatch 'ServiceModuleEnable'}) -split '=')[-1]
                ServiceModuleState = ((.\racadm.exe get idrac.servicemodule | Where-Object{$_ -imatch 'ServiceModuleState'}) -split '=')[-1]
                adminstate = ((.\racadm.exe get idrac.os-bmc.adminstate | Where-Object{$_ -imatch 'adminstate'}) -split '=')[-1]
                HostHeaderCheck = ((.\racadm.exe get iDRAC.WebServer.HostHeaderCheck | Where-Object{$_ -imatch 'HostHeaderCheck'}) -split '=')[-1]
                LifecycleControllerState = (.\racadm.exe get LifeCycleController.LCAttributes.LifecycleControllerState)[0]
            }
            $RACAdminChecks
            If($RACAdminChecks.osinfo -ne 'Enabled'){.\racadm.exe set idrac.servicemodule.osinfo 1}
            IF($RACAdminChecks.ServiceModuleEnable -ne 'Enabled'){.\racadm.exe set idrac.servicemodule.ServiceModuleEnable 1}
            IF($RACAdminChecks.adminstate -ne 'Enabled'){.\racadm.exe set idrac.os-bmc.adminstate 1}
            IF($RACAdminChecks.HostHeaderCheck -ne 'Disabled'){.\racadm.exe set iDRAC.WebServer.HostHeaderCheck 0}
            IF($RACAdminChecks.LifecycleControllerState -ne 'Enabled'){.\racadm.exe set LifeCycleController.LCAttributes.LifecycleControllerState 1}


Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any 
Set-Executionpolicy -executionpolicy remotesigned -Force
Set-Item WSMan:\localhost\Client\TrustedHosts * -Force
Enable-WSManCredSSP -Role Client -Delegate $env:USERDNSDOMAIN -Force
Enable-WSManCredSSP -Role Server -Force
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192 -Force
New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowFreshCredentialsWhenNTLMOnly -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name 1 -Value * -PropertyType String -Force


  Read-host " Install and cleanup complete. Hit a key to continue"






 


if ($freeguy1 -notlike '*1*'){ # I dont have the files and cant download with internet so feed back to #1
clear-host 
Write-host " If you have no internet on this node, then you have to get the files. If you chose no to having the files then control-c this script or stop in ISE and"
Write-host " come back later when you have the files, renamed them and placed into the sctipt folder. OMIMSWAC wont work without the Idrac Tools installed." 
read-host  " Re-run the script and choose 1 when you have the files renamed to isminstall.exe and racadmininstall.exe and copied to the directory $global:where2 " 
return  

}

} catch {Write-host "Could not check racadmin checks after install. spot check manually."}
  
}
} 


}
} 

}

if ( !($env:COMPUTERNAME -in (get-clusternode).Name))
{
Clear-Host
write-host "We detected this node is not a cluster node or you did not enter a reachable cluster. "
write-host " That is Ok. we can still do work if this is your WAC machine"
Write-host " Here we will run the WAC permisions repair"
##Begin PowerShell Script – Paste this in ISE PowerShell##
#$a= Read-Host “what is the full domain name?”
#$str1="*" 
#$ans1= $str1+"."+$a
 
#ix source machines
Set-Executionpolicy -executionpolicy unrestricted -Force
Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any 
Set-Item WSMan:\localhost\Client\TrustedHosts * -Force
Enable-WSManCredSSP -Role Client -Delegate $env:USERDNSDOMAIN -Force
Enable-WSManCredSSP -Role Server -Force
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192 -Force

New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowFreshCredentialsWhenNTLMOnly -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name 1 -Value * -PropertyType String -Force
##End PowerShell Script – Paste this in ISE PowerShell##
 
Write-host "This completes the Prerequisites"
return
 }

}  




Write-host "===================MYISM =========================" -ForegroundColor Magenta

function myism
{
$where2 ="C:\users\$env:username\downloads\RCSimplePreRequisites"
set-location -Path $where2
Push-Location -Path $where2 
clear-host 
 
start-sleep(3)
$myloc= $where2 
#CLs 
 $pwd
$global:mymachine
if ( $env:COMPUTERNAME -in (get-clusternode).Name) {Write-host " We Need to be on a clusternode! We are on a cluser node! Good Job! "
$isimcity =""
 $isimcity = read-host " We now need some input from you. May I use the internet to download needed item? 1= Yes 2=no"

if ($isimcity -like '*1*'){

Clear-Host
$cntr = (get-clusternode).Name
Write-host "Fixing and installing ISM tools if needed. You may have to answer menu items $cntr.count number of times, once per cluster node "
read-host "ready to begin. hit enter"


 
    Invoke-Command -computername (Get-ClusterNode).name -ScriptBlock  {
                                  
$ISMInstalled = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where-Object{$_.DisplayName -imatch "Dell EMC iDRAC Service Module"} |  Select-Object DisplayName, DisplayVersion, Publisher, InstallDate | Format-Table –AutoSize

 If(!($ISMInstalled)) {
Try{

  set-location -Path 'C:\Program Files\Dell\SysMgt\iDRACTools\racadm'

$RACAdminChecks
            If($RACAdminChecks.osinfo -ne 'Enabled'){.\racadm.exe set idrac.servicemodule.osinfo 1}
            IF($RACAdminChecks.ServiceModuleEnable -ne 'Enabled'){.\racadm.exe set idrac.servicemodule.ServiceModuleEnable 1}
            IF($RACAdminChecks.adminstate -ne 'Enabled'){.\racadm.exe set idrac.os-bmc.adminstate 1}
            IF($RACAdminChecks.HostHeaderCheck -ne 'Disabled'){.\racadm.exe set iDRAC.WebServer.HostHeaderCheck 0}
            IF($RACAdminChecks.LifecycleControllerState -ne 'Enabled'){.\racadm.exe set LifeCycleController.LCAttributes.LifecycleControllerState 1}
            IF($RACAdminChecks.ServiceModuleState -ne 'Running')
       {
                         
            
            
            
            # uninstall ism
           
                            (Get-WmiObject -Class Win32_Product -Filter "Name = 'Dell EMC iDRAC Service Module'").uninstall()
                        # download new ism
                            Try {
                                Write-Host "Downloading ISM..." 
                                Invoke-WebRequest -UseBasicParsing -Uri 'https://dl.dell.com/FOLDER07508105M/1/OM-iSM-Dell-Web-X64-4.1.0.0-2410_A00.exe' -OutFile "$Env:Temp\isminstall.exe" -ErrorAction SilentlyContinue -ErrorVariable ISMDownloadFailed }
                            Catch{
                                Write-Host "ERROR: ISM download failed. $ISMDownloadFailed" -ForegroundColor Red
                                EndScript
                                }
                        # extract the downloaded ism
                            Try{
                                Write-Host "Expanding ISM..."
                                Start-Process -FilePath "$Env:Temp\isminstall.exe" -ArgumentList "-auto" -Wait -ErrorAction SilentlyContinue -ErrorVariable ISMExtractFail}
                            Catch {
                                Write-Host "ERROR: Failed to isntall RADAdmin Tools. $ISMExtractFail" -ForegroundColor Red
                                EndScript
                                }

                        # install ism
                            Try{
                                Write-Host "Installing ISM..."
                                Start-Process -FilePath "C:\OpenManage\iSM\windows\iDRACSvcMod.msi" -ArgumentList '/quiet /norestart' -Wait -ErrorAction SilentlyContinue -ErrorVariable ISMInstallFail}
                            
                            Catch {
                                Write-Host "ERROR: Failed to isntall RADAdmin Tools. $ISMInstallFail" -ForegroundColor Red
                                EndScript
                                }
                    
            } else {    
            Read-host "You are all setup with ISM and cleanup. Press a key (may need several times, 1x per node) and enter to continue."
            endscript}
               
    
     Read-host " Install and cleanup complete. Hit a key to continue"
     return
 } Catch { write-host " Not installed ISM on $env:computername"}
 Read-host " Install and cleanup complete. Hit a key to continue"

 }  
 }
 }
  if ($isimcity -notlike '*1*'){ # I cant use the internet to get the files 

clear-host
$ifreeguy1= read-host "The github instuctions should tell you to manually download the idrac tools and the Dell ISM Installer. Have you done that mate? 1=y and 2=n"


if ($ifreeguy1 -like '*1*'){ # I have the files and now telling user to rename and place in the correct directory 
clear-host 
write-host -NoNewline "Good job! now pay attention. Rename the drac file to " -ForegroundColor white
write-host -NoNewline "racadmininstall.exe" -ForegroundColor Green
write-host -NoNewline " and the ISM module rename to " -ForegroundColor White
write-host "isminstall.exe" -ForegroundColor Green

 $where2 ="C:\users\$env:username\downloads\RCSimplePreRequisites"
  set-location -Path "C:\users\$env:username\downloads\RCSimplePreRequisites"

$youdone = read-host "You MUST place the renamed files into this location $where2. Is this done? 1=y and 2= n. stop the script if your not in alighnment at this point"


if ($youdone -like '*1*') {
#######################################


   $my=@()
   $myspanser= get-cluster
$mycluster= Get-Cluster -Name $myspanser
$mynodes = Get-ClusterNode -Cluster $mycluster | Select-Object name
#$counter = (@($mynodes).name).Count
$my= (@($mynodes).name) 
$computername = $my -split " "
$Path = "C:\users\$env:username\downloads\RCSimplePreRequisites\isminstall.exe" 
$Destination = "C$\Users\$Env:Username\downloads"
 set-location -Path "C:\users\$env:username\downloads\RCSimplePreRequisites"

 #download ism module 
copy-file -verbose $computername $Path $Destination

##############################################
 
Write-host " files copying and installing. It may be several minutes, up to 40 minutes to do a 16 node cluster. Come back and finish after a break. "
Write-host " this is one of the rare moments when errors are not bad" -ForegroundColor Green
Write-host " Errors show if the files are already coppied " -ForegroundColor Green
Write-host " Errors show if the Start-process fails because the service is running and doesnt need reapir. Just take errors as working for this one section. "
Write-host " but wait for completion! this is repairing all nodes ISM modules" -ForegroundColor Green



Invoke-Command -computername (Get-ClusterNode).name -ScriptBlock {
    
  

$ans1 = $env:USERDNSDOMAIN
###copy files 
 $global:where2 

#$insmyloc = "C:\users\$env:username\Downloads"

try{
Start-Process -FilePath "C:\users\$env:username\Downloads\isminstall.exe" -ArgumentList "/auto" -Wait -ErrorAction SilentlyContinue -ErrorVariable RACAdminExtractFail}catch{Write-host "extract failed for some reason "}

}


Invoke-command -computername (get-clusternode).name -scriptblock {

try{
Start-Process -FilePath "C:\OpenManage\iSM\windows\iDRACSvcMod.msi" -ArgumentList '/quiet /norestart' -Wait -ErrorAction SilentlyContinue -ErrorVariable ISMInstallFail


Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any 
Set-Executionpolicy -executionpolicy remotesigned 
Set-Item WSMan:\localhost\Client\TrustedHosts * -Force
Enable-WSManCredSSP -Role Client -Delegate $env:USERDNSDOMAIN -Force
Enable-WSManCredSSP -Role Server -Force
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192 -Force
New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowFreshCredentialsWhenNTLMOnly -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name 1 -Value * -PropertyType String 


}catch{Write-host "failure of some kind occured. try again"}



}

 Read-host " Install and cleanup complete. Hit a key to continue"

if ($ifreeguy1 -notlike '*1*'){ # I dont have the files and cant download with internet so feed back to #1
clear-host 
Write-host " If you have no internet on this node, then you have to get the files. If you chose no to having the files then control-c this script or stop in ISE and"
Write-host " come back later when you have the files, renamed them and placed into the sctipt folder. OMIMSWAC wont work without the Idrac Tools installed." 
read-host  " Re-run the script and choose 1 when you have the files renamed to isminstall.exe and racadmininstall.exe and copied to the directory $global:where2 " 
return 


}


} #I have the files or am willing do download the files, rename and copy to the right place 


}

 
 }



}

}




#test results of all nodes
Write-host "================CHKWRK ============================" -ForegroundColor Magenta
function chkwrk 
{

Invoke-command -ComputerName (Get-Clusternode).Name -ScriptBlock {

$mycurhost = $env:COMPUTERNAME
$mycurdom =$env:userdnsdomain
$myfqdn= $mycurhost + "."+$mycurdom
Write-host -NoNewline " REPORT FOR HOSTNAME:" -ForegroundColor Green ; $myfqdn
Write-host -NoNewline "get-executionpolicy for $myfqdn is " -ForegroundColor Green ; Get-executionpolicy 

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host -NoNewline "WINRM RULE STATUS for " -ForegroundColor Green ; write-host $myfqdn -ForegroundColor Green
Get-NetFirewallRule -PolicyStore ActiveStore -Name "WINRM-HTTP-In-TCP-PUBLIC"  
#get-NetFirewallRule -Name "WINRM-HTTP-In-TCP-PUBLIC" | Select-Object PrimaryStatus ,action, enabled
write-host "-----------------------------------" -ForegroundColor Yellow
write-host " WSMAN Trusted Host Setting for $myfqdn" -ForegroundColor Green ; get-Item WSMan:\localhost\Client\TrustedHosts
write-host "-----------------------------------" -ForegroundColor Yellow
Write-host "should say alow delegate fresh and a domain name for host $myfqdn" -ForegroundColor Green
Get-WSManCredSSP -Verbose
write-host "-----------------------------------" -ForegroundColor Yellow

set-location "C:\Program Files\Dell\SysMgt\iDRACTools\racadm"

Write-host " THIS IS THE DRAC PORTION SETTINGS for $myfqdn" -ForegroundColor Green
write-host "-----------------------------------" -ForegroundColor Green
write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " OSINFO should be enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get idrac.servicemodule.osinfo 

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " ServiceModuleEnable  should be Enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get idrac.servicemodule.ServiceModuleEnable

write-host "-----------------------------------"-ForegroundColor Yellow
Write-host " AdminState  should be Enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get idrac.os-bmc.adminstate

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " hostheader   should be Disabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get iDRAC.WebServer.HostHeaderCheck

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " LCAttributes.LifecycleControllerState  should be enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get LifeCycleController.LCAttributes.LifecycleControllerState 

Write-host "-----------------------------------" -ForegroundColor Green

Write-host " This concludes " ; $myfqdn
Write-host "-----------------------------------" -ForegroundColor Green



}
}

# Test all node Node APIPA
Write-host "===================CHKIP=========================" -ForegroundColor Magenta
function chkip {



cls
$global:myorig = $env:computername
Write-host "==================================" -ForegroundColor Green
Write-host " $env:computername of cluster node connectivity for omimswac" -ForegroundColor Green

invoke-command -ComputerName (get-clusternode).name -ScriptBlock {



function sendIP
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [string]$SourceIpa,

        [Parameter(Mandatory=$true, Position=1)]
        [string]$TargetDestination,

        [Parameter(Mandatory=$true, Position=2)]
        [string]$TargetResponseCount,

        [Parameter(Mandatory=$true, Position=3)]
        [string]$DestinationPort,

         [Parameter(Mandatory=$true, Position=4)]
        [string]$myfinalFCVA,

         [Parameter(Mandatory=$true, Position=5)]
        [string]$myorig

        
         
       
        
    )


 $a= $env:COMPUTERNAME
 $b = Resolve-DnsName -Name $a | where-object {$_.type -eq "A"}
$c = $b | Where-Object {$_.ipaddress -inotmatch "169.254"} | Select-Object 
$myaddress1 =@()
$myaddress1 = $c.ipaddress
$countip = $myaddress1.count

 $desthoot= "3343"
 $mylocal1 = [string]$myaddress1
 $blae = $mylocal1.Split(" ")
 $myhostIP = $mylocal1
 

    try
{
    $DestinationIpa = (Test-Connection -Source $SourceIpa -ComputerName $TargetDestination -Count $TargetResponseCount).ipv4address.ipaddressToString
    $tcpObj = New-Object Net.Sockets.TcpClient($DestinationIpa, $DestinationPort)

    if($tcpObj -ne $null)
    {
 $tcpObj.close()
         ################################################################################
write-host "=========================================" -ForegroundColor Green
write-host " USBNIC/REDFISH Report : $env:computername " -ForegroundColor Green
write-host "=========================================" -ForegroundColor Green

       
write-host "Using the USBNIC source $SourceIpa. The port $DestinationPort on destination Redfish Drac IP $TargetDestination is open." -ForegroundColor Green
write-host "`USBNIC value: $SourceIpa"
  write-host "`REDFISH value: $TargetDestination"
    write-host "`Cluster Virtual nic value: $myfinalFCVA"
start-sleep(2) 
for ($i = 0; $i -lt ($blae.Length) ; $i++) 
#foreach ($nots in $blae[$i])
 {
 
 $desthoot= "3343"
 $myip =$blae[$i]
  #Test-Connection  -computername $USING:myorig -Source $myhostIP[$i]  -Protocol WSMan
 $Destinationbloop = (Test-Connection -Source $myip -ComputerName $env:COMPUTERNAME -Count $TargetResponseCount).ipv4address.ipaddressToString
    $ncpObj = New-Object Net.Sockets.TcpClient($Destinationbloop,$desthoot)
   if($ncpObj -ne $null) {write-host "$Destinationbloop<-----------This Cluster network checks out as connected to $env:COMPUTERNAME" -ForegroundColor Green} else {write-host "$Destinationbloop <----------is failing the connections checkpoint" -ForegroundColor red}
$ncpObj.close()
  $myip="0"
    
 #Write-host "$myip <--------------Current" -ForegroundColor Green
 

 
  }

  $ncpObj.close()
  start-sleep(2) 


  $ipmi1 = Get-service -name IPMIDRV


$ipmi2 = Get-PnpDevice -Class system -FriendlyName "microsoft Generic IPMI compliant device"
If ($ipmi1 -and $ipmi2) {$ipmi3= "True"} else {$ipmi3= "false"}

Write-host "-----------------------" -ForegroundColor Yellow
if ($ipmi3 = "true") { Write-host "IPMI Service is "$ipmi1.status" and device is present on $env;computername." -ForegroundColor Green} else { Write-host " IPMI Service is $ipmi1.status or  device is not present on $env;computername." -ForegroundColor yellow}

 
  
    }
}
catch {Write-host -Message "Using the source $blae[$i]. The port $DestinationPort on destination $TargetDestination is not open." -ForegroundColor red
    $tcpObj.close()}







}


$global:myorig = $env:computername


 $myfinalclusIP =@()
  #hostname A records
    $myFQDN=(Get-WmiObject win32_computersystem).DNSHostName+"."+(Get-WmiObject win32_computersystem).Domain 
    #resolved Hostname 
$cresolve = Resolve-DnsName $myFQDN | Where-Object {$_.Type -ne "AAAA"}
   $finalClusIP = @()
  #USBNIC 
$myusbnic = @(Get-NetAdapter -InterfaceDescription "Remote NDIS Compatible Device" | Get-NetIPAddress -AddressFamily "ipv4")
 $myusbip = $myusbnic.IPAddress
 $alsoUSBNI= get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=true and DHCPEnabled=true" -ComputerName .
#RedfishIP
 $mytempfih = (get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=true and DHCPEnabled=true" -ComputerName . | Where-Object -FilterScript {$_.Description -contains "Remote NDIS Compatible Device"} | Select-Object -Property DHCPSERVER)
 $myRedJustIP = ($mytempfih.dhcpserver)
 #microsoft failover virtual cluster virtual IP address 
 $myfinalClusIP =  @(Get-NetAdapter -IncludeHidden -InterfaceDescription "*Microsoft Failover Cluster Virtual Adapter*" | Get-NetIPAddress -AddressFamily "ipv4")
 
 $myfinalFCVA= $myfinalclusip.ipaddress

$bothnotUSB= ($temp1APIP.IPAddress| Where-Object -FilterScript {$_.Description -ne "Remote NDIS Compatible Device"}) 

 




$SourceIpa = $myusbip
$TargetDestination = $myRedJustIP
$TargetResponseCount = 1
$DestinationPort = 443

#sending the USBNICS to the SENDIP function, where the local Host will pull the cluster IP and test them

sendip $SourceIpa $TargetDestination 1 80 $myfinalFCVA $myorig






  }



 



}



Write-host "==============MORETEST==============================" -ForegroundColor Magenta

function moretes
{

param($mymachine)


Invoke-Command -ComputerName (get-clusternode).Name -ScriptBlock {

Enable-NetFirewallRule -name WMI-WinMgmt-In-TCP, WMI-RPCSS-In-TCP

Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any 
 #port on port 445

  New-NetFirewallRule -DisplayName "Allow smb 445 in" -Direction inbound -Profile Any -Action all -LocalPort 445 -Protocol TCP
  New-NetFirewallRule -DisplayName "Allow smb 445 out" -Direction outbound -Profile Any -Action all -LocalPort 445 -Protocol TCP
   

#port on port 5985
  
 
  New-NetFirewallRule -DisplayName "WINRM-HTTP-In-TCP-PUBLIC" -Direction inbound -Profile Any -Action all -LocalPort 5985 -Protocol TCP
  New-NetFirewallRule -DisplayName "WINRM-HTTP-Out-TCP-PUBLIC" -Direction outbound -Profile Any -Action all -LocalPort 5985 -Protocol TCP
    
#rulechek 
Write-host "Rule check $env:computername ---------------------------" -ForegroundColor Green
$rule = "Allow smb 445"
Get-NetFirewallRule -DisplayName $rule -Property Name, DisplayName, @{Name='Protocol';Expression={($PSItem | Get-NetFirewallPortFilter).Protocol}}, @{Name='LocalPort';Expression={($PSItem | Get-NetFirewallPortFilter).LocalPort}}, @{Name='RemotePort';Expression={($PSItem | Get-NetFirewallPortFilter).RemotePort}}, @{Name='RemoteAddress';Expression={($PSItem | Get-NetFirewallAddressFilter).RemoteAddress}}, Enabled, Profile, Direction, Action

$rule = "WINRM-HTTP-In-TCP-PUBLIC"
Get-NetFirewallRule -DisplayName $rule -Property Name, DisplayName, @{Name='Protocol';Expression={($PSItem | Get-NetFirewallPortFilter).Protocol}}, @{Name='LocalPort';Expression={($PSItem | Get-NetFirewallPortFilter).LocalPort}}, @{Name='RemotePort';Expression={($PSItem | Get-NetFirewallPortFilter).RemotePort}}, @{Name='RemoteAddress';Expression={($PSItem | Get-NetFirewallAddressFilter).RemoteAddress}}, Enabled, Profile, Direction, Action

Write-host " $env:computername is enabled for port 445 unless you see a failure"
Write-host " TESTING $USING:mymachine -----------------------------------------" -ForegroundColor Green
$ports = 445,5985
#portcheck 
Write-host "Port  check $env:computername -----------------------------" -ForegroundColor Green
$ports | ForEach-Object {$port = $_; if (Test-NetConnection -ComputerName "$env:COMPUTERNAME" -Port "$port" -InformationLevel Quiet -WarningAction SilentlyContinue -ErrorAction SilentlyContinue) {"Port $port is open" } else {"Port $port is closed"} }



}


} 

write-host "===========Multi menu options wac install, redfish,clear usb nics, set constrained delegation, future use==========" -ForegroundColor Magenta

Function tshot 
{


function Showboat {
    param (
        [string]$Title = 'My showboat Menu'
    )
    Clear-Host
    Write-Host "================ $Title ================"
    
    Write-Host "1: wacinstall '1' Wac Install ."
    Write-Host "2: redfish    '2' Redfish installand testing."
    Write-Host "3: clrusb     '3' usbnic repair and device remove."
    Write-Host "4: constr     '4' constrained Delegation setup."
    Write-Host "5: future     '5' Future use."
    Write-Host "Q: Press      'Q' to quit."
}



function constr
{
 

If (Get-WindowsFeature RSAT-AD-PowerShell) {Add-WindowsFeature RSAT-AD-PowerShell}
else {Enable-WindowsOptionalFeature -Online -FeatureName RSATClient-Roles-AD-Powershell}
# {Add-WindowsCapability –online –Name “Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0”}
#############################
$HVHost = @{}
 $my=@()
   $myspanser= get-cluster
$mycluster= Get-Cluster -Name $myspanser
$mynodes = Get-ClusterNode -Cluster $mycluster | Select-Object name
#$counter = (@($mynodes).name).Count
$my= (@($mynodes).name) 
$var = $my -split " "

###############################

  

# Variables
$HVHost01 = $var[0]
$HVHost02 = $var[1]
$HVHost03 = $var[3]
$HVHost04 = $var[4]
$HVHost05= $management
$mydom = $env:userdomain
$global:creds = Get-Credential -UserName $mydom\$mycurUser -Message "Creds for OMIMSWAC Repair"


#Run this Script from within your Management VM or THE DC VM
cls
Write-host "THis script will try to add the nodes automatically. If its not possible, Edit the script on line "

write-host "Get-WindowsCapability -name rsat* -Online will be run and installed"

If (Get-WindowsFeature RSAT-AD-PowerShell) {Add-WindowsFeature RSAT-AD-PowerShell}
else {Enable-WindowsOptionalFeature -Online -FeatureName RSATClient-Roles-AD-Powershell}
# {Add-WindowsCapability –online –Name “Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0”}




$management= read-host " what is the hosthame for the Windows admin center machine? We need to add this to the constrained delegation list"

Import-Module ActiveDirectory

# Delegate Microsoft Virtual System Migration Service and CIFS for every other possible Live Migration host
$S2d1Spns = @("Microsoft Virtual System Migration Service/$HVHost01", "cifs/$HVHost01")
$S2d2Spns = @("Microsoft Virtual System Migration Service/$HVHost02", "cifs/$HVHost02")
$S2d3Spns = @("Microsoft Virtual System Migration Service/$HVHost03", "cifs/$HVHost03")
$s2d4Spns = @("Microsoft Virtual System Migration Service/$HVHost04", "cifs/$HVHost04")
$s2d5Spns = @("Microsoft Virtual System Migration Service/$HVHost04", "cifs/$HVHost05")

$delegationProperty = "msDS-AllowedToDelegateTo"
$delegateToSpns = $S2d1Spns + $S2d2Spns + $S2d3Spns + $s2d4Spns + $s2d5Spns

# Configure Kerberos to (Use any authentication protocol)
$S2d1Account = Get-ADComputer $HVHost01
$S2d1Account | Set-ADObject -Add @{$delegationProperty=$delegateToSpns}
Set-ADAccountControl $S2d1Account -TrustedToAuthForDelegation $true -Credential $global:creds

$S2d2Account = Get-ADComputer $HVHost02
$S2d2Account| Set-ADObject -Add @{$delegationProperty=$delegateToSpns}
Set-ADAccountControl $S2d2Account -TrustedToAuthForDelegation $true -Credential $global:creds

$S2d3Account = Get-ADComputer $HVHost03
$S2d3Account | Set-ADObject -Add @{$delegationProperty=$delegateToSpns}
Set-ADAccountControl $S2d3Account -TrustedToAuthForDelegation $true -Credential $global:creds

$s2d4Account = Get-ADComputer $HVHost04
$s2d4Account | Set-ADObject -Add @{$delegationProperty=$delegateToSpns}
Set-ADAccountControl $s2d4Account -TrustedToAuthForDelegation $true -Credential $global:creds

$s2d5Account = Get-ADComputer $HVHost05
$s2d5Account | Set-ADObject -Add @{$delegationProperty=$delegateToSpns}
Set-ADAccountControl $s2d5Account -TrustedToAuthForDelegation $true -Credential $global:creds


#Courtesy of Ricky Bobby Inc. AKA Louis_Reeves@Dell.com
#>

cls
Write-host "The constrained Delegation settings are now complete. GO in Peace and may your updates work well!"

}



Function redfish
{

  $myusbnic =@()

#$myusbnic = Get-NetAdapter Where {$_InterfaceDescription -eq  "Remote NDIS Compatible Device"}
$myusbnic = @(Get-NetAdapter -InterfaceDescription "Remote NDIS Compatible Device" | Get-NetIPAddress -AddressFamily "ipv4")
$myusbip = $myusbnic.IPAddress
$mytempfih = (get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=true and DHCPEnabled=true" -ComputerName . | Where-Object -FilterScript {$_.Description -contains "Remote NDIS Compatible Device"} | Select-Object -Property DHCPSERVER)
 
 $myRedishIP= ($mytempfih.DHCPSERVER )

 cls 
 Write-host " this section is all about the USB NIC. this should be the ip of the Redfish -->  $myRedishIP <---- If you nothing between the 2 arrows, check your drac."
 write-host " this section will test only the local drac. the drac has 2 IP. regular ip and one is in the redfish tab. a third, is in the windows OS. they both begin with 169.154.x.x"
write-host "this tool tests that connectivity. You need the drac user and password to begin."
$savy= read-host " Savvy? (Y/N) -> Y to continue"


function fish-Menu
{
    param (
        [string]$Title = 'My Menu'
    )

    Clear-Host
    Write-Host "================ $Title ================"
    
    Write-Host "1: Press '1' To Download and Install the required files for the Redfish Commands to work using Powershell commands." -ForegroundColor Green
    Write-Host "2: Press '2' Run Example Get-IdracRemoteServiceApiStatusREDFISH." -ForegroundColor Green
    Write-Host "3: Press '3' Run Example Invoke-ExportHwInventoryLocalREDFISH" -ForegroundColor Green
    Write-Host "4: Press '4' Run Example Get-IdracServerSlotInformationREDFISH" -ForegroundColor Green
    Write-Host "5: Press '5' Run Example Get-ImportServerConfigurationProfilePreviewREDFISH" -ForegroundColor Green
    Write-Host "6: Press '6' Choose this option To Get a list of other Commands you can run by using your own switchs" -ForegroundColor Green
    Write-Host "7: Press '7' Press 7 to complete troubleshooting and remove the powershell modules from the target system" -ForegroundColor Green
    Write-Host "Q: Press 'Q' to quit."
}


Function Install-Fedfish{
$where2=$PSScriptRoot
$RunIdrac = "create_dir_structure_download_iDRAC_Redfish_cmdlets.ps1"
cd $where2

write-host " the files you need include below (all in the powershell script running folder): "   -ForegroundColor Red
Write-host " Listof possiblecmds.html"   -ForegroundColor Red
write-host " and create_dir_structure_download_iDRAC_Redfish_cmdlets.ps1"   -ForegroundColor Red

# Create the folder structure syntax for setup of refish powershell comands
$targetnode = $($env:COMPUTERNAME)
#$cred = Get-Credential
$Pwrshell = $PSVersionTable
 
$finalFishpath= "C:\users\"+$($env:USERDOMAIN)+ "\" +$($env:USERNAME)+ "\"+ "Documents\WindowsPowerShell\Modules\*"
$createdirpath= "C:\users\"+$($env:USERDOMAIN)+ "\" +$($env:USERNAME)+ "\"+ "Documents\WindowsPowerShell\Modules\"
$userdomain1 = $($env:USERDOMAIN)+ "\" +$($env:USERNAME)

 
#$sourcefile = Get-ChildItem $createdirpath -File |Where {$_.Name -imatch $RunIdrac}
#IF (!$sourcefile){
#cd $PSScriptRoot
#Copy $RunIdrac $createdirpath
#}

#Create Registration Path for Powershell Module  

$checkif = test-path -Path $createdirpath -pathtype any

# review path creation if needed https://urldefense.com/v3/__https://www.powershelladmin.com/wiki/Powershell_check_if_folder_exists.php__;!!LpKI!jhvo9QLBDPeYtUkFnQyFwnc0Wm1XpvyHmoZsoHlhzfX4-VGhPYNyRDkZB7OGK-EOfw0mC1RhXxnozPfyGEGThhJHz9V6$ [powershelladmin[.]com]
If (!$checkif) { MKDIR $createdirpath} else {Write-host "Path to Redfish Powershell commands Exists and is Valid!"}

  
#################################################################### 
$Int1 = [system.version]"6.0" # threshold for New value to the Redfish install
$NewOrOld= ($PSVersionTable | Where-Object {$_.PSVersion -lt $int1})

$NewOrOld = $PSVersionTable 
$where2 = $PSScriptRoot

if ($NewOrOld | Where-Object {$_.PSVersion -lt $int1}) {.\create_dir_structure_download_iDRAC_Redfish_cmdlets.ps1 -powershell_version "old" -os_username $userdomain1}`
 else {.\create_dir_structure_download_iDRAC_Redfish_cmdlets.ps1 -powershell_version "new" -os_username $userdomain1}

 $finalFishpath | gci -Include '*.psm1','*.ps1' -Recurse | Import-Module


# Example use case

#  Get-IdracRemoteServiceApiStatusREDFISH -idrac_ip 100.72.4.25 -idrac_username root -idrac_password calvin

#Get-IdracServerSlotInformationREDFISH
#Get-ImportServerConfigurationProfilePreviewREDFISH
#Get-StorageInventoryREDFISH
#IdracRedfishSupport

 
}

Function redfish-two {


write-host " this section will test Invoke-ExportHwInventoryLocalREDFISH for target IP ---> $myRedishIP  <---" -ForegroundColor Green
$DracIP = $myRedishIP 
$dracuser = Read-host " enter the user name of the drac admin"
$dracpass = read-host "Enter the Password for the Drac Admin"
Invoke-ExportHwInventoryLocalREDFISH -idrac_ip $DracIP -idrac_username $dracuser -idrac_password $dracpass

}

Function redfish-three {


write-host " this section will test Invoke-ExportHwInventoryLocalREDFISH target IP ---> $myRedishIP  <---" -ForegroundColor Green
$DracIP = $myRedishIP 
$dracuser = Read-host " enter the user name of the drac admin"
$dracpass = read-host "Enter the Password for the Drac Admin"
Get-IdracRemoteServiceApiStatusREDFISH -idrac_ip $DracIP -idrac_username $dracuser -idrac_password $dracpass

}

Function redfish-four {

write-host " this section will test Get-IdracServerSlotInformationREDFISH target IP ---> $myRedishIP  <---" -ForegroundColor Green
$DracIP = $myRedishIP 
$dracuser = Read-host " enter the user name of the drac admin"
$dracpass = read-host "Enter the Password for the Drac Admin"
Get-IdracServerSlotInformationREDFISH -idrac_ip $DracIP -idrac_username $dracuser -idrac_password $dracpass
 
 

}
Function redfish-five {
 
write-host " this section will test Invoke-CreateXauthTokenSessionREDFISH target IP ---> $myRedishIP  <---" -ForegroundColor Green
$DracIP = Read-host $myRedishIP 
$dracuser = Read-host " enter the user name of the drac admin"
$dracpass = read-host "Enter the Password for the Drac Admin"
Invoke-CreateXauthTokenSessionREDFISH -idrac_ip $DracIP -idrac_username $dracuser -Idrac_password $dracpass -create_x_auth_token_session y
 #Invoke-CreateXauthTokenSessionREDFISH -idrac_ip 192.168.0.120 -username root -password calvin -create_x_auth_token_session y
 #  This example will create a new X-auth token session for the iDRAC.
 Write-host " token is now created"
 Write-host " you may now want to use the command below to delete the token you just created."
 Write-host "    Invoke-CreateXauthTokenSessionREDFISH -idrac_ip 192.168.0.120 -username root -password calvin -delete_idrac_session /redfish/v1/SessionService/Sessions/22
 #  This example will delete iDRAC session /redfish/v1/SessionService/Sessions/22."
}
Function redfish-six {
write-host " Opening up HTML file located in the root of Script Directory" -ForegroundColor Green
$where2=$PSScriptRoot
invoke-expression '.\ListofRedfish.html'| Out-GridView
 

}
Function redfish-seven {

$where2=$PSScriptRoot
$RunIdrac = "create_dir_structure_download_iDRAC_Redfish_cmdlets.ps1"
cd $where2
Set-Location -Path $where2
write-host " Removing PS Shell Modules... : "   -ForegroundColor Red

# Create the folder structure syntax for setup of refish powershell comands
$targetnode = $($env:COMPUTERNAME)
$Pwrshell = $PSVersionTable
 
$finalFishpath= "C:\users\"+$($env:USERDOMAIN)+ "\" +$($env:USERNAME)+ "\"+ "Documents\WindowsPowerShell\Modules\*"
$createdirpath= "C:\users\"+$($env:USERDOMAIN)+ "\" +$($env:USERNAME)+ "\"+ "Documents\WindowsPowerShell\Modules\"
$userdomain1 = $($env:USERDOMAIN)+ "\" +$($env:USERNAME)

 
 

#Create Registration Path for Powershell Module  

$checkif = test-path -Path $createdirpath -pathtype any

# review path creation if needed https://urldefense.com/v3/__https://www.powershelladmin.com/wiki/Powershell_check_if_folder_exists.php__;!!LpKI!jhvo9QLBDPeYtUkFnQyFwnc0Wm1XpvyHmoZsoHlhzfX4-VGhPYNyRDkZB7OGK-EOfw0mC1RhXxnozPfyGEGThhJHz9V6$ [powershelladmin[.]com]
If (!$checkif) { Write-host "nothing to Delete!" } else {Write-host "Path to Redfish Powershell commands Exists and is Valid!"}

  
#################################################################### 
 
$where2 = $PSScriptRoot
cd $createdirpath

#$myPSlist = gci -Include '*.psm1','*.ps1' -Recurse
(Get-Module | Where-Object {$_.Name -like "*redfish*"}) | Remove-Module
$myDelList = Get-ChildItem -Recurse –Path $createdirpath | ?{$_.Name -like "*redfish*"}
foreach ($my in $myDellist)
{
$my.FullName
Remove-item -Force $my.Name -Recurse


#get-childitem -Path $createdirpath -Filter {$_.Name -imatch "*redfish*"}

}

#gci -Include '*.psm1','*.ps1' -Recurse | Remove-Module -Force

#Get-ChildItem -Path $createdirpath -Include *.* -File -Recurse | foreach { $_.Delete()}

}


Cls

$wherefilesare = $pwd 

Write-host " This script will allow you to perform Redfish Queries without knowing redish." -ForegroundColor Green
Write-host " You should check to make sure the correct installer files are in place before choosing any other item." -ForegroundColor Green
Write-host " If you dont choose #1 First, then you may get failures. check the script about redfish 1 to check the file path for the proper Powershell modules" -ForegroundColor Green

Write-host "This Script Requires INternet connection to get the files from Github. Hit Q now if you dont have internet or the files needed." -ForegroundColor Red
Write-host " This Script Requires PS remoting and will fail if this is not already enabled." -ForegroundColor Red

Write-host " Choose to install Redfish Powershell Modules for Redfish to run on a specific Host" -ForegroundColor Green

write-host "Option 6 has a list of commands that you can use. edit the script if your interested in making a script of different Redfish commands. "
do

 {
    fish-Menu
     $selection = Read-Host "Please make a selection"
     switch ($selection)
     {
         '1' {
             'You chose redfish #1- Download and Install Required Powershell Modules'
             Install-Fedfish
         } '2' {
             'You chose redfish #2- Get-IdracRemoteServiceApiStatusREDFISH -idrac_ip 100.72.4.25 -idrac_username root -idrac_password calvin '
             redfish-two
         } '3' {
             'You chose redfish #3 Invoke-ExportHwInventoryLocalREDFISH'
            redfish-three
         } '4' {
             'You chose redfish #4 Get-IdracServerSlotInformationREDFISH'
             redfish-four
     }   '5' {
             'You chose redfish #5- Invoke-CreateXauthTokenSessionREDFISH'
             redfish-five
        } '6' {
             'You chose redfish #6 - Get a list of other Commands you can run by using your own switchs'
              redfish-six
       }  '7' {
             'You chose redfish #7 - Press here to unregister the powershell commands and Delete the directory'
              redfish-seven
        }

         }
     pause
 }

 until ($selection -eq 'q')
 Write-Output "Time taken: $((Get-Date).Subtract($start_time).Seconds) second(s)"


# 
#  

#
#
#Get-StorageInventoryREDFISH
#IdracRedfishSupport

}


Function wacinstall{
cls
$myspanser  
$myscluster
Write-host " This section will Install Windows admin center. Below are some restrictions for OMIMSWAC"

WRITE-HOST " You Do not want WAC installed on: "  -ForegroundColor Green
Write-host " =You Do not want WAC installed on Any VM in the Cluster."  -ForegroundColor Green
write-host " =You Do not want WAC installed on Any host in the cluster."  -ForegroundColor Green
write-host " =You Do not want WAC installed on Any remote site. Exceptions apply for this one"  -ForegroundColor Green
Write-host " Do you still want to Install Wac? ... Hit a key... and then hit enter." 
$typesomethinghitenter = read-host typesomethinghitenter$


if ($myscurentcomputer -ine $myscluster)
{
   Invoke-WebRequest -UseBasicParsing -Uri https://aka.ms/WACDownload -OutFile "$env:USERPROFILE\Downloads\WindowsAdminCenter.msi"
     


 Add-LocalGroupMember -Group "Windows Admin Center CredSSP Administrators" -Member $env:USERDOMAIN\$env:username -ErrorAction SilentlyContinue
 Add-LocalGroupMember -Group  "administrators" -Member $env:USERDOMAIN\$env:username -ErrorAction SilentlyContinue

 Write-host " you have been added to the CredSSP group. and check your browser for the WAC frequently asked questions"
# invoke-webrequest -usebasicparsing -uri 'http://docs.microsoft.com/en-us/windows-server/manage/windows-admin-center/understand/faq*which-web-browsers-are-supported-by-windows-admin-center'
   Start-Process msiexec.exe -Wait -ArgumentList "/i $env:USERPROFILE\Downloads\WindowsAdminCenter.msi /qn /L*v waclog.txt REGISTRY_REDIRECT_PORT_80=1 SME_PORT=443 SSL_CERTIFICATE_OPTION=generate"
}



if ($myscurentcomputer -in  $myscluster) 
{


Write-host "we have detected your trying to install WAC on a cluster node. This is not supported. Please install outside the cluster"
$unsup= Read-host "proceed with an unsupported deployment? "
 
 if ($unsup -ilike '*y*')

 {

 Invoke-WebRequest -UseBasicParsing -Uri https://aka.ms/WACDownload -OutFile "$env:USERPROFILE\Downloads\WindowsAdminCenter.msi"

 Add-LocalGroupMember -Group "Windows Admin Center CredSSP Administrators" -Member $env:USERDOMAIN\$env:username -ErrorAction SilentlyContinue
 Add-LocalGroupMember -Group  "administrators" -Member $env:USERDOMAIN\$env:username -ErrorAction SilentlyContinue

 Write-host " you have been added to the CredSSP group. and check your browser for the WAC frequently asked questions"
# invoke-webrequest -usebasicparsing -uri 'http://docs.microsoft.com/en-us/windows-server/manage/windows-admin-center/understand/faq*which-web-browsers-are-supported-by-windows-admin-center'
  #start-process -filepath 'https://docs.microsoft.com/en-us/windows-server/manage/windows-admin-center/understand/faq*which-web-browsers-are-supported-by-windows-admin-center'
  Start-Process msiexec.exe -Wait -ArgumentList "/i $env:USERPROFILE\Downloads\WindowsAdminCenter.msi /qn /L*v waclog.txt REGISTRY_REDIRECT_PORT_80=1 SME_PORT=443 SSL_CERTIFICATE_OPTION=generate"


}

 }
}


Function clrusb
{

Clear-host 
Write-host "We are going to clear the usbnic devices on all nodes" -ForegroundColor Green
Write-host "Once finished, if you refresh cluster manager, look in the network section. the USBNIC network should go away" -ForegroundColor Green
write-host "Next go to Open manage integration and do the Inventory . THIS MAY FAIL" -ForegroundColor Green
write-host "You will need to stop, before the update. Use this tool and choose option 6 multi-menu and choose option 3" -ForegroundColor Green
Write-host "this tool option 6 multi-menu and choose option 3 to remove the newly discovered usb nics from cluster communications " -ForegroundColor Green
Write-host "There is a picture I poped up to show you what I mean. the NDIS nics in this network will need to be disabled for cluster communication again" -ForegroundColor Green



 <#  {
$1pwd= "c:\users\$env:username\downloads\RCSimplePreRequsites"
$mypic= "$1pwd\1usbnic.jpeg"
$image = New-Object -ComObject Wia.ImageFile
$image.LoadFile($mypic)

$image.Width, $image.Height 

start-process "$1pwd\1usbnic.jpg"

$file = (get-item "$1pwd\1usbnic.jpg") 

[void][reflection.assembly]::LoadWithPartialName("System.Windows.Forms")
$form = new-object Windows.Forms.Form
$form.Text = "Image Viewer"
$form.width = 1280
$form.height = 1024
$pictureBox = new-object Windows.Forms.PictureBox
$pictureBox.Width = 1280
$pictureBox.Height = 1024

$pictureBox.Image = [System.Drawing.Image]::Fromfile($file)
$form.controls.add($pictureBox)
$form.Add_Shown( { $form.Activate() } )
$form.ShowDialog()
}#>

Invoke-Command -ComputerName (get-clusternode).name -ScriptBlock  {
 
 Write-host "clearing $env:hostname"
# Device is used with Inventory collector SECUPD along with some drive letter
$unDevs = @(Get-PnpDevice -class USB | ? Status -eq Unknown)
$devs = @(Get-PnpDevice -Class wpd)

ForEach ($Dev in $Devs) {
    Write-Host "Removing $($Dev.FriendlyName)" -ForegroundColor Green
    $RemoveKey = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($Dev.InstanceId)"
    Get-Item $RemoveKey | Select-Object -ExpandProperty Property | %{ Remove-ItemProperty -Path $RemoveKey -Name $_ -Verbose }

    # now removing USB nic as well
try {
$deviceName="Remote NDIS Compatible Device"
$DeviceById= Get-PnpDevice -InstanceId "USB\VID_413C&PID_A102\5678" -ErrorAction SilentlyContinue -ErrorVariable SilentlyContinue
$DeviceByDeviceName = Get-PnpDevice | Where-Object {$_.Name -eq $deviceName} -ErrorAction SilentlyContinue -ErrorVariable SilentlyContinue
} Catch {Write-host "device not found"}

If ($DeviceById)
{
try{
pnputil /remove-device -instanceid "USB\VID_413C&PID_A102\5678"
} Catch {Write-host "USB not present"}

}
Write-Host "Done removing Secupd, Dell Drive Letter and USBNIC"

Try{
 
ForEach ($unDev in $UnKDevs) {
    Write-Host "Removing $($unDev.FriendlyName)" -ForegroundColor Green
    $RemoveKey = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($unDev.InstanceId)"
    $myre1 = (Get-Item $RemoveKey | Select-Object -ExpandProperty Property | %{ Remove-ItemProperty -Path $RemoveKey -Name $_ -Verbose })
}

Write-Host "Done removing unknown Devices from the server"
}Catch {Write-host "Device is not present"}
}

### If the IPMI device is not able to be added back - you may try this command Rundll32 ipmisetp.dll, AddTheDevice

Write-host "================================" -ForegroundColor Green
Write-host " ---> $env:hostname <----------"
Get-service -name IPMIDRV
$myIPMIdevice = Get-PnpDevice -Class system -FriendlyName "microsoft Generic IPMI compliant device"

Write-host " not clearing the IPMI driver, but if the results here show not online or not ok, then check that node out "

Write-host "===================================" -ForegroundColor Green

}


Write-host " IPMI driver is something you should check manually. Here is the checklist while troubleshooting." -ForegroundColor Green
Write-host " It should be running if you look above, unless WAC/OMIMSWAC has never worked. If this is the case, just move forward. Install Will correct this" -ForegroundColor Green
Write-host " Look for event id 1004 and concider a timeout change if needed -https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2008-R2-and-2008/dd363714(v=ws.10)" -ForegroundColor Green
Write-host " If the device is present (system) and the Service is running , Monitor for errors" -ForegroundColor Green

Write-Host "Devices been cleared by this script. The goals is for the devices to be recreated, and the communication between IPMI, USBNIC, SECUPD, WINRM/WMI and Powershell will be restored" -ForegroundColor Green
}

function future
{
read-host "Ready to look at SPN? enter to begin. This is bonus future feature"

$myfuture = (get-clusternode).Name
$myfuture = $myfuture -split(" ")

 

invoke-command -ComputerName (get-clusternode).name -ScriptBlock {


write-host "$env:computername "
Get-CimInstance win32_operatingsystem -ComputerName $env:computername 
gwmi win32_operatingsystem -ComputerName $env:computername 

reg add "\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v LocalAccountTokenFilterPolicy /t REG_DWORD /d 1"


  setspn -L $env:computername
Setspn -X

}





do
 {
    Showboat
    $selection = Read-Host "Please make a selection"
    switch ($selection)
    {
    '1' {
    'Option 1 is for cleanup Cluster History'
    wacinstall
    } '2' {
    'Option 2 is to fix cluster aware update'
    redfish
    } '3' {
      'is to remove usb network from cluster communications'
      clrusb
   }   '4' {
      'Restart all dracs in cluster. will not hurt server'
     constr

   } '5' {
      'Cluster validation and other tests'
     future

        }
    }
    
    pause
 }
 until ($selection -eq 'q')

} future

Write-host "===============DPROX=============================" -ForegroundColor Magenta

# Proxy Setup options
 Function dprox
 {  Write-host " you have 2 choices. You have the Internet proxy and the wininetproxy. please choose generally wininetproxy for Windows admin center: "
 $readprox= read-host " Choose 1= WinInetProxy or 2= Inter or other proxy"

 If ($readprox -like '*1*')
 {
 
 Clear-Host
$myuserdomain = ("*." + $env:userdnsdomain)
Write-host " Please read one off the following: " -ForegroundColor Green
write-host "1: https://www.powershellgallery.com/packages/WinInetProxy/0.1.0"
write-host "2: Install-module -name WinInetProxy"
write-host "3. HCI proxy vs WAC procy- both use WinInetProxy. Ok to use both. https://docs.microsoft.com/en-us/azure-stack/hci/concepts/firewall-requirements?tabs=allow-table%2Cpublic-cloud#set-up-a-proxy-server"
write-host "4. Install the WinInetPxoxy module"

read-host " You ready to move forward hit enter"
clear-host

Write-host "Your putting in 2 entries here. I am including exmaple for each. The lines have to be right for this to work. dont worry about parenthasis but all else must match:"
write-host -NoNewline "Here is an example of the proxy server entry."; Write-host "mymachine.mydomain.com:8080" -ForegroundColor Green
$proxyvalue = read-HOST "Please ENTER THE PROXY SERVER in the format server:port"


clear-host

Write-host "Your putting in the second line here . I am including exmaple. the lines have to be right for this to work. dont worry about parenthasis but all else must match:"
write-host -NoNewline "here is an example of the proxy server entry."; Write-host "localhost;127.0.0.1;*.Dell.com;*.microsoft.com;*louisreeves.net;169.254.'*'" -ForegroundColor Green
$bypass = read-HOST "Please enter the BYPASS in the format server:port;server:port "

 


$noremote = @()
$rerun = @()
$table = @()
$copyfail = @()
$applyfail = @()

Write-Host "Ensure you are running this from a WAC VM and not from your local workstation or VDI" -ForegroundColor Magenta
Write-Host

$localmodchk = Get-Item -Path "C:\Program Files\WindowsPowershell\Modules\WinInetProxy\0.1.0\WinInetProxy.psm1" -ErrorAction SilentlyContinue
if (!$localmodchk.Exists)
    {
        Write-Host "WinInetProxy module not found on this system. Aborting!" -ForegroundColor Red
        break
    }
else
    {
        $servers = (get-content -Path C:\temp\setproxy.txt -ErrorAction SilentlyContinue)
        if ($servers.count -eq 0)
            {
                $servers = (read-host "Server name please:").Trim()
                Clear-Host
            }
        foreach ($server in $servers.Trim())
            {
                Write-Host "Checking on ---> "$server -ForegroundColor Yellow
                $prechk = Invoke-Command -ComputerName $server -ScriptBlock {1} -ErrorAction SilentlyContinue
                if ($prechk -eq 1)
                    {
                        $applyproxy = $null
                        Write-Host `t "Remoting OK..." -ForegroundColor Gray
                        $modchk = Invoke-Command -ComputerName $server -ScriptBlock {Get-Module -ListAvailable -Name WinInetProxy -ErrorAction SilentlyContinue}
                        if ($modchk.Name -like "WinInetProxy")
                            {
                                Write-Host `t`t "WinInetProxy module found..."
                                $applyproxy = Invoke-Command -ComputerName $server -ScriptBlock {Set-WinInetProxy -ProxySettingsPerUser 0 -ProxyServer $using:proxyvalue -ProxyByPass $using:bypass} | `
                                                    Select-String -Pattern "^ProxyServer"
                                if ($applyproxy -like "*$proxyvalue")
                                    {
                                        Write-Host `t`t`t "Proxy configuration successfully applied" -ForegroundColor Cyan
                                        Write-Host `t`t`t`t "Configuration set to --->" $applyproxy.ToString() -ForegroundColor Green
                                    }
                                else
                                    {
                                        Write-Host `t`t`t "Proxy configuration not correctly applied. Tagging for manual scrub" -ForegroundColor Red
                                        $applyfail += $server
                                    }
                            }
                        else
                            {
                                Write-Host `t`t`t "WinInetProxy module not found..." -ForegroundColor Yellow
                                Copy-Item -Path "c:\Program Files\WindowsPowerShell\Modules\WinInetProxy\" -Destination \\$server\c$\Program Files\WindowsPowerShell\Modules\ -Recurse -Force
                                Write-Host `t`t`t`t "Copy completed, verifying"
                                $copychk = Get-Item -Path \\$server\c$\Program Files\WindowsPowerShell\Modules\WinInetProxy\0.1.0\WinInetProxy.psm1 -ErrorAction SilentlyContinue
                                if ($copychk.Exists)
                                    {
                                        Write-Host `t`t`t`t`t "Copy successful. Re-run the script against this node" -ForegroundColor Green
                                        $rerun += $server
                                    }
                                else
                                    {
                                        Write-Host `t`t`t`t`t "Copy was not successful. System tagged for review" -ForegroundColor Red
                                        $copyfail += $server
                                    }
                            }
                    }
                else
                    {
                        Write-Host `t "Remoting NOT OK. Tagged!" -ForegroundColor Red
                        $noremote += $server
                    }
            }
        Write-Host
        if ($noremote -ne $null)
            {
                Write-Host "Could not remote"
                Write-Host "================"
                $noremote | ft -AutoSize
                Write-Host
            }
        if ($copyfail -ne $null)
            {
                Write-Host "Module copy failure"
                Write-Host "==================="
                $copyfail | ft -AutoSize
                Write-Host
            }
        if ($applyfail -ne $null)
            {
                Write-Host "Proxy configuration apply failed"
                Write-Host "================================"
                $applyfail | ft -AutoSize
                Write-Host
            }
        if ($rerun -ne $null)
            {
                Write-Host "Re-run script against these servers"
                Write-Host "==================================="
                $rerun | ft -AutoSize
                Write-Host
            }
        if ($table -ne $null)
            {
                Write-Host "Tabulated details"
                Write-Host "================="
                $table | ft Server,Source,Class,Identity -AutoSize
                Write-Host
            }
    } 

 
 
 }

 if ($readprox -notlike '*1*')

 {
 
 

function bloatshow {
    param (
        [string]$Title = 'My showboat Menu'
    )
    Clear-Host
    Write-Host "================ $Title ================"
    
    Write-Host "1: Press '1' Get Proxy ."
    Write-Host "2: Press '2' Set Proxy"
    Write-Host "3: Press '3' Remove Proxy."
    Write-Host "4: Press '4' Set Proxy Exception."
    Write-Host "5: Press '5' Future use."
    Write-Host "Q: Press 'Q' to quit."
}



function GetProx (){
    Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' | Select-Object ProxyServer, ProxyEnable  
    read-host "hit a key to return"      
}
 
function SetProx { 
    [CmdletBinding()]
    [Alias('proxy')]
    [OutputType([string])]
    Param
    (
        # server address
        [Parameter(Mandatory = $true,
            ValueFromPipelineByPropertyName = $true,
            Position = 0)]
        $server,
        # port number
        [Parameter(Mandatory = $true,
            ValueFromPipelineByPropertyName = $true,
            Position = 1)]
        $port    
    )
    #Test if the TCP Port on the server is open before applying the settings
    If ((Test-NetConnection -ComputerName $server -Port $port).TcpTestSucceeded) {
        Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -name ProxyServer -Value "$($server):$($port)"
        Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -name ProxyEnable -Value 1
        Get-Proxy #Show the configuration 
    }
    Else {
        Write-Error -Message "The proxy address is not valid:  $($server):$($port)"
    }    
}
 
  
function Remprox (){    
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -name ProxyServer -Value ""
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -name ProxyEnable -Value 0

    read-host "proxy removed. anyting else we can do for you today? Hint the answer is n"
}



Function setexec
{

write-host "here is the format for entering the proxy exception:"
Write-host " `";*.google.com;*.microsoft.com, 169.254.*, *.dell.com`"" -ForegroundColor Green
$ProxyExceptionList = Read-host "enter just like above with quotes"

#$ProxyExceptionList = ";*.google.com;*.microsoft.com, 169.254.*, *.dell.com"

$ProxyProperty = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings"

If ($ProxyProperty.ProxyOverride) {
    $OldValue = $ProxyProperty.ProxyOverride
    $NewValue = $OldValue+$ProxyExceptionList
    $ProxyProperty | Set-ItemProperty -Name ProxyOverride -Value $NewValue
} else {
    Write-Warning "Proxy overrides not set!"
}
}

function future
{
read-host "future use hit enter"

}

do
 {
    bloatshow
    $selection = Read-Host "Thank you for setting the proxy!"
    switch ($selection)
    {
    '1' {
    'Get Proxy'
    getprox
    } '2' {
    'Set proxy'
    $server = read-host "please enter the server to add as proxy"
    $port = read-host "please enter the port the proxy will use"
    setprox $server $port 
    } '3' {
      'remove proxy'
      remprox
   }   '4' {
      'set proxy exceptions'
     setexec

   } '5' {
      'future use'
     futureuse

        }
    }
    
    pause
 }
 until ($selection -eq 'q')

 
 
 }
 
 }


 do
 {
    Show-Menu
     $selection = Read-Host "Please make a selection"
     switch ($selection)
     {    
           '1' {
             'Install Idrac tools'
             DoIdrac
       }   '2' {
             'Install ISM'
            myISM
         } '3' {
             'Verification of steps 1 and 2'
             chkwrk
         } '4' {
             'Check IP and USB NIC connectivity'
              chkip 
        }  '5' {
             'fix ports 443 and 5985'
             moretes
        }
           '6' {
             Fixstuf
            
        }'7' {
             'Pull logs'
             getlogs
        } '8' {
             'Misc Troubleshoot'
             tshot
        }   '9' {
             'setup proxy'
             Dprox
        }
        
         }
     pause
 }

 until ($selection -eq 'q')
