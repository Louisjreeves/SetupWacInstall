﻿
  if (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")){
        throw 'Admin permission missing! Restart and run as administrator!' #or anything else you like
    }
  $myspanser = read-host "what is the cluster name we are working on? "
 $global:where2 
$where2 = $PSScriptRoot
set-location -Path $where2
set-location $where2
Push-Location -Path $where2 
set-location $PSScriptRoot
$myloc= $PWD.Path 
#CLs 
 $pwd
$Path = $myloc + "\"+ "racadmininstall.exe" #Include the FileName and Extension
$Destination = "C$\Users\$Env:Username\" #Be Sure to use a : instead of a $ for the username variable
$global:mymachine= $env:COMPUTERNAME
$my=@()
$mycluster= Get-Cluster -Name $myspanser
$mynodes = Get-ClusterNode -Cluster $mycluster | Select-Object name
#$counter = (@($mynodes).name).Count
$my= (@($mynodes).name) 
$computername = $my -split " "
$selection = "a"

function Show-Menu
{
    param (
        [string]$Title = 'My Menu'
    )

    Clear-Host
    Write-Host "================ $Title ===================================================================" -ForegroundColor Magenta
     
    Write-host " Offline Setup and test menu" -ForegroundColor Magenta
    Write-host " ===========================================================================================" -ForegroundColor Magenta

    Write-Host "1: Press '1' IDracTools install and pre-requisites" -ForegroundColor Cyan
    Write-Host "2: Press '2' Install ISM" -ForegroundColor Cyan
    Write-Host "3: Press '3' Verification of steps 1 and 2 " -ForegroundColor Cyan
    Write-Host "4: Press '4' Check IP and USB NIC connectivity" -ForegroundColor Cyan
    Write-Host "5: Press '5' Fix port 445 and winrm 5985 " -ForegroundColor Cyan
    write-host "6: Press '6' Fixes for cluster and WAC useage" -ForegroundColor Cyan
    write-host "7: Press '7' Getting logs -provide a share location. run this one cluster node and again on the WAC server.  " -ForegroundColor Cyan
    Write-Host "Q: Press 'Q' to quit."
}

function fixstuff
{

   
 $global:where2 
$where2 = $PSScriptRoot
set-location -Path $where2
set-location $where2
Push-Location -Path $where2 
set-location $PSScriptRoot
$myloc= $PWD.Path 
#CLs 
 $pwd
$Path = $myloc + "\"+ "racadmininstall.exe" #Include the FileName and Extension
$Destination = "C$\Users\$Env:Username\" #Be Sure to use a : instead of a $ for the username variable
$global:mymachine= $env:COMPUTERNAME
$my=@()
$mycluster= Get-Cluster -Name $myspanser
$mynodes = Get-ClusterNode -Cluster $mycluster | Select-Object name
#$counter = (@($mynodes).name).Count
$my= (@($mynodes).name) 
$computername = $my -split " "
 #=============================================================================
 cls
 function Show-Menu {
    param (
        [string]$Title = 'My Menu'
    )
    Clear-Host
    Write-Host "================ $Title ================"
    
    Write-Host "1: Press '1' for repair cluster performance history."
    Write-Host "2: Press '2' for repair Cluster aware update."
    Write-Host "3: Press '3' Set usb network as removed from cluster communications."
    Write-Host "4: Press '4' Restart all dracs will not harm production servers."
    Write-Host "5: Press '5' Rapid check session."
    Write-Host "Q: Press 'Q' to quit."
}

function rapidcheck
{

Write-host " This section will present you with some output that you should review. This may mean you may need to make corrections manually. "
Write-host " We may correct some items as well" 
Write-host " =========================================" -ForegroundColor Magenta
Write-host " Testing cluster communication to port 445 smb"

Test-netConnection -ComputerName ($myspanser) -Port 445
Write-host " =========================================" -ForegroundColor Magenta

Read-host " If resultes of port 445 fail, you will need to run a cluster validation. hit enter to move to next test. "

clear-host
Invoke-command -computername (get-clusternode).name -ScriptBlock {Get-NetFirewallProfile | Format-Table Name, Enabled}

Write-host "If your OMIMSWAC fails to update, you can disable all profiles on all servers here for testing."
$simplejack = read-host " Do it now? y/n then hit enter"

if ($simplejack -ilike '*y*') {Invoke-command -computername (get-clusternode).name -ScriptBlock {Set-NetFirewallProfile -Profile Domain, Public, Private -Enabled False}}

read-host "next test port 135 and 5685 (5685) will partially fail. look for pingsuceeded. tcptestsucceed can fail. - hit enter"

Test-NetConnection $myspanser -port 135
Test-NetConnection $myspanser -port 5685

Write-host " If these fail fail then you will need to run cluster validation"
$simplejk1= read-host = "next section is going to check DC connectivity to all nodes in cluster y=go ahead and n=skip"

if ($simplejk1 -like '*y*')
{
clear-host
Invoke-Command -ComputerName (get-clusternode).name -ScriptBlock {


 $myname = $env:computername + "." +$env:USERDNSDOMAIN 
 Nltest /Server:$myname /query

 }
 }

 read-host " Does the output look like your ok to move to the next section? If not stop and check AD. Y= move on." 










 #future checks
 
#Now returned All ip are tested, no only need to check other things 
# get-wmiobject mscluster_resourcegroup -namespace "ROOT\MSCluster"
# netstat -ano | findstr "135"
# get-netAdapter -includeHidden | where {$_.interfaceDescription -match 'failover'}
#Set-NetFirewallProfile -Profile Domain, Public, Private -Enabled False
#Get-NetFirewallProfile | Format-Table Name, Enabled

 #netsh advfirewall firewall show rule name="windows management instrumentation (async-in)"
 #netsh advfirewall firewall show rule name="windows management instrumentation (wmi-out)"
 #netsh advfirewall firewall show rule name="windows management instrumentation (wmi-in)"
 #netsh advfirewall firewall show rule name="windows management instrumentation (dcom-in)"

 

# get-clusterNetwork | ft name,address,role
 #add-CAUclusterRole -daysOfWeek saturday -weeksOfMonth 1 -requireAllNodesOnline -maxFailedNodes 1 -enableFirewallRules -CAUpluginName Microsoft.WindowsUpdatePlugin -virtualComputerObjectName myCluster-CAU -groupName myCluster-CAU
 #test-connection -Protocol DCOM -ComputerName -port 445

# "sc query Winmgmt && sc query rpcss"

# service Remote Procedure Call (RPC) is running (OK)
 #Test-NetConnection IP -port 135 (OK)
 #Test-NetConnection IP -port 49703 (WARNING: TCP connect to (IP : 49703) failed)

 # certutil -ping

}


Function resetidrac
{

clear-host
write-host " This will reset the dracs in the cluster. each drac will reset. no data is lost and the server stays in productions durring the whole process" -ForegroundColor Cyan
read-host " Ready then hist a hey and or enter"

invoke-command -computername (get-clusternode).name -scriptblock {

set-location 'C:\Program Files\dell\SysMgt\iDRACTools\racadm'

.\racadm.exe racreset -f   
}

Write-host "Each Drac has been reset. This will take about 5 minutes and you can contunue and go do updates" 
}


Function  clusterhistory
{


Stop-clusterperformancehistory -deletehistory
start-clusterperformancehistory
Get-ClusterResource -Name "Cluster Virtual Disk (ClusterPerformanceHistory)"
Get-ClusterResource | where-object {$_.resourcetype.name -eq "Health Service"}
Get-ClusterResource | where-object {$_.resourcetype.name -eq "Health Service"} | Stop-ClusterResource
Get-ClusterResource | where-object {$_.resourcetype.name -eq "Health Service"} | start-ClusterResource
}


function fixcauupdate
{



<###################################################

CAU may look like the issue. there is basic troubleshooting

here and the steps to setup the CAU VCO and ROLE. 





####################################################>

Clear-Host
Write-host " there are two choices in this section." -ForegroundColor Magenta
Write-host " 1. You have configured CAU and you want an automated repair (reinstall)." -forgroundcolor yellow
Write-host " 2. You dont have CAU configured but you have created a computer Object (VCO) in the cluster OU and added it to the OU above the cluster with full write/create objects permissions." -forgroundcolor yellow
Write-host " 3. If you dont meet the criteria for 1 or 2- then your only other option is to create the VCO and then use cluster manager or choice 2 to setup CAU." -ForegroundColor Magenta
Write-host "===================================" -ForegroundColor Magenta 
$read3ans = Read-Host " What is your choice? 1= Reinstall (already setup) 2= Deploy CAU and I have a VCO to enter 3=Quit and I will use cluster manager to setup CAU"

If ($read3ans -eq "1"){

#$b=@()
#$a = read-host "enter cluster name"
#$b= Test-CauSetup -ClusterName $a 

Get-ClusterResource  "Distributed Network Name"
 
$myclustername = $myspanser
$CAUName= (Get-Cluster $myclustername | Get-ClusterParameter -Name CauCredentialResourceName).Value
$CVOName = (Get-Cluster $myclustername | Get-ClusterParameter -name CauResourceName).Value

Remove-CauClusterRole -ClusterName $myclustername -Force

Get-Cluster $myclustername  | get-ClusterParameter "CauResourceName" 
Get-Cluster $myclustername  | Set-ClusterParameter "CauResourceName" -Delete

Get-ClusterResource -Name $CAUName | Remove-ClusterResource
Get-ClusterResource -Name $CVOName | Remove-ClusterResource


write-host "Wait 10 seconds-Then RUN GET-CLUSTERRESOURCE and see that the CAU objects are gone.those names are printed below" -ForegroundColor Green
$CVOName
$CAUName
Read-host "Once you verified the objects are gone, hit  enter and we will auto fix the role back properly."

Add-CauClusterRole -ClusterName $myclustername -MaxFailedNodes 0 -RequireAllNodesOnline -EnableFirewallRules -VirtualComputerObjectName $CVOName -Force -CauPluginName Microsoft.WindowsUpdatePlugin -MaxRetriesPerNode 3 -CauPluginArguments @{ 'IncludeRecommendedUpdates' = 'False' } -StartDate "3/2/2020 3:00:00 AM" -DaysOfWeek 4 -WeeksOfMonth @(3) -verbose

 
 
}  





If ($read3ans -eq "2"){

clear-host
Write-host " You need to run get-clusterresource and make sure CAU distributed network name is gone. If its gone, create the VCO in AD and set permissions per the documentaiton" 
Write-host " If you have the name, then continue."
$CVOName = Read-host " What is the VCO name you created? "


Add-CauClusterRole -ClusterName $myclustername -MaxFailedNodes 0 -RequireAllNodesOnline -EnableFirewallRules -VirtualComputerObjectName $CVOName -Force -CauPluginName Microsoft.WindowsUpdatePlugin -MaxRetriesPerNode 3 -CauPluginArguments @{ 'IncludeRecommendedUpdates' = 'False' } -StartDate "3/2/2020 3:00:00 AM" -DaysOfWeek 4 -WeeksOfMonth @(3) -verbose

Write-host " The CAU is installing Wait 5 minutes and check get-clusterresource"

}

If ($read3ans -eq "3"){Write-host "Exiting" ; start-sleep(1)}


}


Function FixClusComs
{

 
 Clear-Host
 Write-host " This final step in this section will attempt to disable the USB nic from the cluster communication." -ForegroundColor Green

 Write-host "Please open cluster manager and confirm the USBNIC network is showing under networks." -ForegroundColor Green
 Write-host " come back to step 2 after discovery if needed to diable cluster communicaiton for the USBNIC network" -ForegroundColor Green
 
 
 Get-ClusterNetwork | Format-Table Name, Metric
$my169net = Get-ClusterNetwork | sort-object metric
$my169max = ($my169net| Select-Object -last 1)

write-host "$my169max we are removing this network from cluster communications" -ForegroundColor Yellow
Write-host "$my169max is the network we identified to remove from cluster communications. Please verify in the network section of cluster manager. this should be the NDIS compatible device nics" -ForegroundColor Green
$myread69 = Read-host "please hit Y and enter to confirm this network is ok to disable for cluster communicaiton"

if ($myread69 -ilike '*y*') {$my169max.role = 0 } 

$myusbnic1 = Get-NetAdapter -InterfaceDescription "Remote NDIS Compatible Device" 

$myusbnic1| Disable-NetAdapter
$myusbnic1 | Enable-NetAdapter

Clear-Host
Write-host "USB Network now removed from cluster network communications"  -ForegroundColor Green
read-host "hit a key or enter to continue"   

}



do
 {
    Show-Menu
    $selection = Read-Host "Please make a selection"
    switch ($selection)
    {
    '1' {
    'Option 1 is for cleanup Cluster History'
    clusterhistory
    } '2' {
    'Option 2 is to fix cluster aware update'
    fixcauupdate
    } '3' {
      'is to remove usb network from cluster communications'
      FixClusComs
   }   '4' {
      'Restart all dracs in cluster. will not hurt server'
      resetidrac

   } '5' {
      'Rapid check cluster health session'
     rapidcheck

        }
    }
    
    pause
 }
 until ($selection -eq 'q')





}


Function getlogs {

#Enter-PSSession -ComputerName $Chlost
$datet= (Get-Date).AddDays(-1)
 $mycluster8= $myspanser
#$mynode8= Get-ClusterNode -Name $mycluster8
$revs = @(Get-ClusterNode -Cluster $mycluster8)
 
 
$Uusername= $env:USERNAME
Clear-Host
$destination = Read-host "please put a unc path to a share for backup \\host\folder. If your not backing up, stop the script and comment out the copy-item lines"
#$destination = "\\gsejumpbox\repositoryDSU\backup"
$ans11= read-host "Ready to backup logs? Y or N"

If($destination.EndsWith('\')){
$destination = $destination -replace '\\$',""
}
foreach ($myrev in $revs)
{
 

    
 $MainLogs = "\\$myrev\c$\Windows\ServiceProfiles\NetworkService\Appdata\Local\Temp\generated\"
 $pushfiles = "\\$myrev\c$Windows\Temp\OMIMSWAC\"
$Failedupdate= "\\$myrev\c$\ProgramData\Server Management Experience\Extensions\dell-emc.openmanage-integration.2.2.1\"
$Duplog = "\\$myrev\c$\temp\sme\dell-emc.openmanage-integration.2.2.1\"
$updatelog = "\\$myrev\c$\Users\*\appdata\roaming\update\log\"
$applogs1= "\\$myrev\c$\Users\$Uusername\AppData\Roaming\Update\"
$applogs2 = "\\$myrev\c$\Users\$Uusername\AppData\Roaming\compliance\"
    $Share1= "\\$myrev\c$\Users\$Uusername\AppData\Local\Temp\CAU\"

 $finalDest = join-path $destination $myrev
   if (!(Test-Path $finaldest)) { mkdir $finalDest }
   

 #Set-Location $share1 -PassThru
    Set-Location -Path $share1
    $debug=@()
    $bugstore=@()
    $share1
   

#if (!(Test-Path $destination)) { mkdir $rev.Id }
#$finalDest = "$destination$rev"

$debug = Get-ChildItem -Path $Share1 -Recurse | Where-Object {$_.CreationTime -gt ($datet)}
    #$debug = Get-childItem -Path $Share1 -Filter *.etl


    #$debug = (Get-Item -Path $Share1).LastWriteTime
    Foreach ($bug in $debug)
    {
    Try {

    invoke-expression " Netsh Trace Convert $bug" 

    } Catch {Write-host "THis file wont convert" -ForegroundColor Green  }


    $bugstore = Get-ChildItem -Path $Share1 -Recurse *.txt
    }

copy-item $MainLogs -Recurse $finalDest  -verbose
copy-item $pushfiles -Recurse $finalDest  -verbose
copy-item $Failedupdate -Recurse $finalDest  -verbose
copy-item $Duplog -Recurse $finalDest -verbose
copy-item $updatelog -Recurse $finalDest  -verbose
copy-item $applogs1 -Recurse $finalDest  -verbose
copy-item $applogs2  -Recurse $finalDest  -verbose
#copy-item $Share1 -recurse $finaldest -Verbose
copy-item $bugstore -Recurse $finalDest -Verbose
if ( $ans11 -like '*Y*')
 {

Remove-Item -Path "$mainlogs\*" -Recurse -force
Remove-Item -Path "$share1\*" -Recurse -force
Remove-Item -Path "$pushfiles\*" -Recurse -force
Remove-Item -Path "$updatelog\*" -Recurse -force
Remove-Item -Path "$applogs1\*" -Recurse -force
Remove-Item -Path "$applogs1\*" -Recurse -force
Remove-Item -Path "$applogs2\*" -Recurse -force
#Remove-Item -Path "$applogs3\*" -Recurse -force
Remove-Item -Path "$Failedupdate\*" -Recurse -force
}
   





}

If ($env:computername -notin $revs)
{
Write-host " Is this the WAC server? " -ForegroundColor Green
$iswac= read-host " Hit y to proceed or n. I am going to collect logs if you type y" 

If ($iswac -ne "n")
{
#### WAC sererlogs

#$destination = Read-host "please put a unc path to a share for backup \\host\folder. If your not backing up, stop the script and comment out lines 518-520"
$rev= "WAC"
 

if (!(Test-Path $destination)) { mkdir $rev }
$finalDest = "$destination$rev"
$clearWAClog= "C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Temp\generated\"
$dellDupLog = "C:\ProgramData\Dell\DELL EMC System Update"
$dsuInstaller = "C:\ProgramData\Dell\UpdatePackage\log"

copy-item $clearWAClog -Recurse $finalDest  -verbose
copy-item $dellDupLog -Recurse $finalDest  -verbose
copy-item $dsuInstaller -Recurse $finalDest  -verbose

Remove-Item -Path "$clearWAClog\*" -Recurse -Force
Remove-Item -Path "$dellDupLog\*" -Recurse -Force
Remove-Item -Path "$dsuInstaller\*" -Recurse -Force


Write-host "Files are copying to the share you specified. hit a key to continue" -ForegroundColor Green; read-host '$myans12'
} else {Write-host "no Wac logs collected"}


# try tommys 
# $bugstore.fullname | %{Start-Process -FilePath "Netsh.exe" -ArgumentList @("Trace","Convert","$_")}

}

}

Function Copy-File
{
  [Cmdletbinding()]
  Param(
   [Parameter(ValueFromPipeline=$true,Mandatory=$true)]
    [String[]]$ComputerName,
   [Parameter(ValueFromPipeline=$true,Mandatory=$true)]
    [String]$Path,
   [Parameter(ValueFromPipeline=$true,Mandatory=$true)]
    [String]$Destination
   
)
  Process {
   #Extract FileName from Path
   $File = $Path.Split('\')
   $File = $File[$File.Length-1]



  ForEach ($Computer in $ComputerName)
  {
   
  
    Write-Verbose "Starting copy to $Computer"
    IF(Test-Path "\\$Computer\$Destination")
    {
     Write-Verbose "Folder $Destination exists on $Computer"
    }
    ELSE
    {
     Write-Verbose "Creating folder $Destination on $Computer"
    IF (New-Item "\\$Computer\$Destination" -Type Directory) {$global:shareyes++}
    }
 
   Write-Verbose "Copying $File to $Computer"
   TRY
   {
    If (Copy-Item -Path $Path -Destination "\\$Computer\$Destination" -Force) {$global:shareyes++}
    Write-Host "Copied to \\$Computer\$Destination\$File`n" -ForegroundColor GREEN

   }
   CATCH
   {
    Write-Warning "Copy failed to $Computer`n"
    
   } 
     

  }#EndForEach
 }#EndProcess
}#EndFunction

#check permissions 
# DOwnload Drac Tools to all nodes
copy-file $computername $Path $Destination
$Path = $myloc + "\"+ "isminstall.exe"
 #download ism module 
copy-file $computername $Path $Destination

 
 function doidrac
 {
 
#install IDrac tools

Invoke-Command -computername (Get-ClusterNode).name -ScriptBlock {
$ans1 = $env:USERDNSDOMAIN
Start-Process -FilePath “c:\users\$env:username\racadmininstall.exe" -ArgumentList "/auto" -Wait -ErrorAction SilentlyContinue -ErrorVariable RACAdminExtractFail
Start-Process -FilePath "C:\OpenManage\iDRACTools_x64.msi" -ArgumentList '/quiet /norestart' -Wait -ErrorAction SilentlyContinue -ErrorVariable RACAdminInstallFail
Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any 
Set-Executionpolicy -executionpolicy remotesigned 
Set-Item WSMan:\localhost\Client\TrustedHosts *
Enable-WSManCredSSP -Role Client -Delegate $ans1
Enable-WSManCredSSP -Role Server
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192
New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowFreshCredentialsWhenNTLMOnly -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name 1 -Value * -PropertyType String }

}

function doism
{

 #install ISM
Invoke-Command -computername (Get-ClusterNode).name -ScriptBlock {
$ans1 = $env:USERDNSDOMAIN
 Start-Process -FilePath "c:\users\$Env:username\isminstall.exe" -ArgumentList "-auto" -Wait -ErrorAction SilentlyContinue -ErrorVariable ISMExtractFail
 Start-Process -FilePath "C:\OpenManage\iSM\windows\iDRACSvcMod.msi" -ArgumentList '/quiet /norestart' -Wait -ErrorAction SilentlyContinue -ErrorVariable ISMInstallFail

 Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any 
# for NVME failed disks – reset-physicaldisk -serialnumber xxxxx
Set-Executionpolicy -executionpolicy remotesigned 
Set-Item WSMan:\localhost\Client\TrustedHosts *
Enable-WSManCredSSP -Role Client -Delegate $ans1
Enable-WSManCredSSP -Role Server
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192
New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowFreshCredentialsWhenNTLMOnly -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name 1 -Value * -PropertyType String

set-location "c:\program files\dell\sysmgt\idractools\racadm\" -PassThru
.\racadm set idrac.os-bmc.adminstate 1
.\racadm set iDRAC.WebServer.HostHeaderCheck Disabled
.\racadm set LifeCycleController.LCAttributes.LifecycleControllerState 1
# n45d5 if your using drac8 – check the sessions tab to make sure racadm closessn –u n45d5
.\Racadm set idrac.OS-BMC.PTMode 1
.\racadm set idrac.lockdown.SystemLockdown 0


 }

 }

#test results of all nodes

function checkwork
{

Invoke-command -ComputerName (Get-Clusternode).Name -ScriptBlock {

$mycurhost = $env:COMPUTERNAME
$mycurdom =$env:userdnsdomain
$myfqdn= $mycurhost + "."+$mycurdom
Write-host -NoNewline " REPORT FOR HOSTNAME:" -ForegroundColor magenta ; $myfqdn
Write-host -NoNewline "get-executionpolicy for $myfqdn is " -ForegroundColor Green ; Get-executionpolicy 

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host -NoNewline "WINRM RULE STATUS for " -ForegroundColor Green ; write-host $myfqdn -ForegroundColor Green
Get-NetFirewallRule -PolicyStore ActiveStore -Name "WINRM-HTTP-In-TCP-PUBLIC"  
#get-NetFirewallRule -Name "WINRM-HTTP-In-TCP-PUBLIC" | Select-Object PrimaryStatus ,action, enabled
write-host "-----------------------------------" -ForegroundColor Yellow
write-host " WSMAN Trusted Host Setting for $myfqdn" -ForegroundColor Green ; get-Item WSMan:\localhost\Client\TrustedHosts
write-host "-----------------------------------" -ForegroundColor Yellow
Write-host "should say alow delegate fresh and a domain name for host $myfqdn" -ForegroundColor Green
Get-WSManCredSSP -Verbose
write-host "-----------------------------------" -ForegroundColor Yellow

set-location "C:\Program Files\Dell\SysMgt\iDRACTools\racadm"

Write-host " THIS IS THE DRAC PORTION SETTINGS for $myfqdn" -ForegroundColor Cyan
write-host "-----------------------------------" -ForegroundColor Cyan
write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " OSINFO should be enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get idrac.servicemodule.osinfo 

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " ServiceModuleEnable  should be Enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get idrac.servicemodule.ServiceModuleEnable

write-host "-----------------------------------"-ForegroundColor Yellow
Write-host " AdminState  should be Enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get idrac.os-bmc.adminstate

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " hostheader   should be Disabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get iDRAC.WebServer.HostHeaderCheck

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " LCAttributes.LifecycleControllerState  should be enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get LifeCycleController.LCAttributes.LifecycleControllerState 

Write-host "-----------------------------------" -ForegroundColor Magenta

Write-host " This concludes " ; $myfqdn
Write-host "-----------------------------------" -ForegroundColor Magenta



}
}

# Test all node Node APIPA

function CheckalIP  {



cls
$global:myorig = $env:computername
Write-host "==================================" -ForegroundColor Magenta
Write-host " $env:computername of cluster node connectivity for omimswac" -ForegroundColor Magenta

invoke-command -ComputerName (get-clusternode).name -ScriptBlock {



function sendIP
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [string]$SourceIpa,

        [Parameter(Mandatory=$true, Position=1)]
        [string]$TargetDestination,

        [Parameter(Mandatory=$true, Position=2)]
        [string]$TargetResponseCount,

        [Parameter(Mandatory=$true, Position=3)]
        [string]$DestinationPort,

         [Parameter(Mandatory=$true, Position=4)]
        [string]$myfinalFCVA,

         [Parameter(Mandatory=$true, Position=5)]
        [string]$myorig

        
         
       
        
    )


 $a= $env:COMPUTERNAME
 $b = Resolve-DnsName -Name $a | where-object {$_.type -eq "A"}
$c = $b | Where-Object {$_.ipaddress -inotmatch "169.254"} | Select-Object 
$myaddress1 =@()
$myaddress1 = $c.ipaddress
$countip = $myaddress1.count

 $desthoot= "3343"
 $mylocal1 = [string]$myaddress1
 $blae = $mylocal1.Split(" ")
 $myhostIP = $mylocal1
 

    try
{
    $DestinationIpa = (Test-Connection -Source $SourceIpa -ComputerName $TargetDestination -Count $TargetResponseCount).ipv4address.ipaddressToString
    $tcpObj = New-Object Net.Sockets.TcpClient($DestinationIpa, $DestinationPort)

    if($tcpObj -ne $null)
    {
 $tcpObj.close()
         ################################################################################
write-host "=========================================" -ForegroundColor Magenta
write-host " USBNIC/REDFISH Report : $env:computername " -ForegroundColor Cyan
write-host "=========================================" -ForegroundColor Magenta

       
write-host "Using the USBNIC source $SourceIpa. The port $DestinationPort on destination Redfish Drac IP $TargetDestination is open." -ForegroundColor Green
write-host "`USBNIC value: $SourceIpa"
  write-host "`REDFISH value: $TargetDestination"
    write-host "`Cluster Virtual nic value: $myfinalFCVA"
start-sleep(2) 
for ($i = 0; $i -lt ($blae.Length) ; $i++) 
#foreach ($nots in $blae[$i])
 {
 
 $desthoot= "3343"
 $myip =$blae[$i]
  #Test-Connection  -computername $USING:myorig -Source $myhostIP[$i]  -Protocol WSMan
 $Destinationbloop = (Test-Connection -Source $myip -ComputerName $env:COMPUTERNAME -Count $TargetResponseCount).ipv4address.ipaddressToString
    $ncpObj = New-Object Net.Sockets.TcpClient($Destinationbloop,$desthoot)
   if($ncpObj -ne $null) {write-host "$Destinationbloop<-----------This Cluster network checks out as connected to $env:COMPUTERNAME" -ForegroundColor Green} else {write-host "$Destinationbloop <----------is failing the connections checkpoint" -ForegroundColor red}
$ncpObj.close()
  $myip="0"
    
 #Write-host "$myip <--------------Current" -ForegroundColor Magenta
 

 
  }

  $ncpObj.close()
  start-sleep(2) 


  $ipmi1 = Get-service -name IPMIDRV


$ipmi2 = Get-PnpDevice -Class system -FriendlyName "microsoft Generic IPMI compliant device"
If ($ipmi1 -and $ipmi2) {$ipmi3= "True"} else {$ipmi3= "false"}

Write-host "-----------------------" -ForegroundColor Yellow
if ($ipmi3 = "true") { Write-host "IPMI Service is "$ipmi1.status" and device is present on $env;computername." -ForegroundColor Green} else { Write-host " IPMI Service is $ipmi1.status or  device is not present on $env;computername." -ForegroundColor yellow}

 
  
    }
}
catch {Write-host -Message "Using the source $blae[$i]. The port $DestinationPort on destination $TargetDestination is not open." -ForegroundColor red
    $tcpObj.close()}







}


$global:myorig = $env:computername


 $myfinalclusIP =@()
  #hostname A records
    $myFQDN=(Get-WmiObject win32_computersystem).DNSHostName+"."+(Get-WmiObject win32_computersystem).Domain 
    #resolved Hostname 
$cresolve = Resolve-DnsName $myFQDN | Where-Object {$_.Type -ne "AAAA"}
   $finalClusIP = @()
  #USBNIC 
$myusbnic = @(Get-NetAdapter -InterfaceDescription "Remote NDIS Compatible Device" | Get-NetIPAddress -AddressFamily "ipv4")
 $myusbip = $myusbnic.IPAddress
 $alsoUSBNI= get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=true and DHCPEnabled=true" -ComputerName .
#RedfishIP
 $mytempfih = (get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=true and DHCPEnabled=true" -ComputerName . | Where-Object -FilterScript {$_.Description -contains "Remote NDIS Compatible Device"} | Select-Object -Property DHCPSERVER)
 $myRedJustIP = ($mytempfih.dhcpserver)
 #microsoft failover virtual cluster virtual IP address 
 $myfinalClusIP =  @(Get-NetAdapter -IncludeHidden -InterfaceDescription "*Microsoft Failover Cluster Virtual Adapter*" | Get-NetIPAddress -AddressFamily "ipv4")
 
 $myfinalFCVA= $myfinalclusip.ipaddress

$bothnotUSB= ($temp1APIP.IPAddress| Where-Object -FilterScript {$_.Description -ne "Remote NDIS Compatible Device"}) 

 




$SourceIpa = $myusbip
$TargetDestination = $myRedJustIP
$TargetResponseCount = 1
$DestinationPort = 443

#sending the USBNICS to the SENDIP function, where the local Host will pull the cluster IP and test them

sendip $SourceIpa $TargetDestination 1 80 $myfinalFCVA $myorig






  }



 



}





function doadditionaltest
{

param($mymachine)


Invoke-Command -ComputerName (get-clusternode).Name -ScriptBlock {

Enable-NetFirewallRule -name WMI-WinMgmt-In-TCP, WMI-RPCSS-In-TCP

Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any 
 #port on port 445

  New-NetFirewallRule -DisplayName "Allow smb 445 in" -Direction inbound -Profile Any -Action all -LocalPort 445 -Protocol TCP
  New-NetFirewallRule -DisplayName "Allow smb 445 out" -Direction outbound -Profile Any -Action all -LocalPort 445 -Protocol TCP
   

#port on port 5685
  
 
  New-NetFirewallRule -DisplayName "WINRM-HTTP-In-TCP-PUBLIC" -Direction inbound -Profile Any -Action all -LocalPort 5685 -Protocol TCP
  New-NetFirewallRule -DisplayName "WINRM-HTTP-Out-TCP-PUBLIC" -Direction outbound -Profile Any -Action all -LocalPort 5685 -Protocol TCP
    
#rulechek 
Write-host "Rule check $env:computername ---------------------------" -ForegroundColor Cyan
$rule = "Allow smb 445"
Get-NetFirewallRule -DisplayName $rule -Property Name, DisplayName, @{Name='Protocol';Expression={($PSItem | Get-NetFirewallPortFilter).Protocol}}, @{Name='LocalPort';Expression={($PSItem | Get-NetFirewallPortFilter).LocalPort}}, @{Name='RemotePort';Expression={($PSItem | Get-NetFirewallPortFilter).RemotePort}}, @{Name='RemoteAddress';Expression={($PSItem | Get-NetFirewallAddressFilter).RemoteAddress}}, Enabled, Profile, Direction, Action

$rule = "WINRM-HTTP-In-TCP-PUBLIC"
Get-NetFirewallRule -DisplayName $rule -Property Name, DisplayName, @{Name='Protocol';Expression={($PSItem | Get-NetFirewallPortFilter).Protocol}}, @{Name='LocalPort';Expression={($PSItem | Get-NetFirewallPortFilter).LocalPort}}, @{Name='RemotePort';Expression={($PSItem | Get-NetFirewallPortFilter).RemotePort}}, @{Name='RemoteAddress';Expression={($PSItem | Get-NetFirewallAddressFilter).RemoteAddress}}, Enabled, Profile, Direction, Action

Write-host " $env:computername is enabled for port 445 unless you see a failure"
Write-host " TESTING $USING:mymachine -----------------------------------------" -ForegroundColor Cyan
$ports = 445,5985
#portcheck 
Write-host "Port  check $env:computername -----------------------------" -ForegroundColor Cyan
$ports | ForEach-Object {$port = $_; if (Test-NetConnection -ComputerName "$env:COMPUTERNAME" -Port "$port" -InformationLevel Quiet -WarningAction SilentlyContinue -ErrorAction SilentlyContinue) {"Port $port is open" } else {"Port $port is closed"} }



}


} 



do
 {
    Show-Menu
     $selection = Read-Host "Please make a selection"
     switch ($selection)
     {    
           '1' {
             'Install Idrac tools'
             DoIdrac
       }   '2' {
             'Install ISM'
            DoISM
         } '3' {
             'Verification of steps 1 and 2'
             checkwork
         } '4' {
             'Check IP and USB NIC connectivity'
              CheckalIP 
        }  '5' {
             'fix ports 443 and 5685'
             doadditionaltest
        }
           '6' {
             Fixstuff
            
        }'7' {
             'Pull logs'
             getlogs
        }
        
         }
     pause
 }

 until ($selection -eq 'q')