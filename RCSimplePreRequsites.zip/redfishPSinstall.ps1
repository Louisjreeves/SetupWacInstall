﻿



function Show-Menu
{
    param (
        [string]$Title = 'My Menu'
    )

    Clear-Host
    Write-Host "================ $Title ================"
    
    Write-Host "1: Press '1' To Download and Install the required files for the Redfish Commands to work using Powershell commands." -ForegroundColor Green
    Write-Host "2: Press '2' Run Example Get-IdracRemoteServiceApiStatusREDFISH." -ForegroundColor Green
    Write-Host "3: Press '3' Run Example Invoke-ExportHwInventoryLocalREDFISH" -ForegroundColor Green
    Write-Host "4: Press '4' Run Example Get-IdracServerSlotInformationREDFISH" -ForegroundColor Green
    Write-Host "5: Press '5' Run Example Get-ImportServerConfigurationProfilePreviewREDFISH" -ForegroundColor Green
    Write-Host "6: Press '6' Choose this option To Get a list of other Commands you can run by using your own switchs" -ForegroundColor Green
    Write-Host "7: Press '7' Press 7 to complete troubleshooting and remove the powershell modules from the target system" -ForegroundColor Green
    Write-Host "Q: Press 'Q' to quit."
}


Function Install-Fedfish{
$where2=$PSScriptRoot
$RunIdrac = "create_dir_structure_download_iDRAC_Redfish_cmdlets.ps1"
cd $where2

write-host " the files you need include below (all in the powershell script running folder): "   -ForegroundColor Red
Write-host " Listof possiblecmds.html"   -ForegroundColor Red
write-host " and create_dir_structure_download_iDRAC_Redfish_cmdlets.ps1"   -ForegroundColor Red

# Create the folder structure syntax for setup of refish powershell comands
$targetnode = $($env:COMPUTERNAME)
#$cred = Get-Credential
$Pwrshell = $PSVersionTable
 
$finalFishpath= "C:\users\"+$($env:USERDOMAIN)+ "\" +$($env:USERNAME)+ "\"+ "Documents\WindowsPowerShell\Modules\*"
$createdirpath= "C:\users\"+$($env:USERDOMAIN)+ "\" +$($env:USERNAME)+ "\"+ "Documents\WindowsPowerShell\Modules\"
$userdomain1 = $($env:USERDOMAIN)+ "\" +$($env:USERNAME)

 
#$sourcefile = Get-ChildItem $createdirpath -File |Where {$_.Name -imatch $RunIdrac}
#IF (!$sourcefile){
#cd $PSScriptRoot
#Copy $RunIdrac $createdirpath
#}

#Create Registration Path for Powershell Module  

$checkif = test-path -Path $createdirpath -pathtype any

# review path creation if needed https://www.powershelladmin.com/wiki/Powershell_check_if_folder_exists.php
If (!$checkif) { MKDIR $createdirpath} else {Write-host "Path to Redfish Powershell commands Exists and is Valid!"}

  
#################################################################### 
$Int1 = [system.version]"6.0" # threshold for New value to the Redfish install
$NewOrOld= ($PSVersionTable | Where-Object {$_.PSVersion -lt $int1})

$NewOrOld = $PSVersionTable 
$where2 = $PSScriptRoot

if ($NewOrOld | Where-Object {$_.PSVersion -lt $int1}) {.\create_dir_structure_download_iDRAC_Redfish_cmdlets.ps1 -powershell_version "old" -os_username $userdomain1}`
 else {.\create_dir_structure_download_iDRAC_Redfish_cmdlets.ps1 -powershell_version "new" -os_username $userdomain1}

 $finalFishpath | gci -Include '*.psm1','*.ps1' -Recurse | Import-Module


# Example use case

#  Get-IdracRemoteServiceApiStatusREDFISH -idrac_ip 100.72.4.25 -idrac_username root -idrac_password calvin

#Get-IdracServerSlotInformationREDFISH
#Get-ImportServerConfigurationProfilePreviewREDFISH
#Get-StorageInventoryREDFISH
#IdracRedfishSupport

 
}

Function Option-two {


write-host " this section will test Invoke-ExportHwInventoryLocalREDFISH" -ForegroundColor Green
$DracIP = Read-host "Enter the target Drac IP you wish to test from this machine. For OMIMSWAC EMULATION PUT IN THE IP Of the OS PASSTHOUGH IP of the Redfish Tab" 
$dracuser = Read-host " enter the user name of the drac admin"
$dracpass = read-host "Enter the Password for the Drac Admin"
Invn -idrac_ip $DracIP -idrac_username $dracuser -idrac_password $dracpass

}

Function Option-three {


write-host " this section will test Invoke-ExportHwInventoryLocalREDFISH" -ForegroundColor Green
$DracIP = Read-host "Enter the target Drac IP you wish to test from this machine. For OMIMSWAC EMULATION PUT IN THE IP Of the OS PASSTHOUGH IP of the Redfish Tab" 
$dracuser = Read-host " enter the user name of the drac admin"
$dracpass = read-host "Enter the Password for the Drac Admin"
Get-IdracRemoteServiceApiStatusREDFISH -idrac_ip $DracIP -idrac_username $dracuser -idrac_password $dracpass

}

Function Option-four {

write-host " this section will test Get-IdracServerSlotInformationREDFISH" -ForegroundColor Green
$DracIP = Read-host "Enter the target Drac IP you wish to test from this machine. For OMIMSWAC EMULATION PUT IN THE IP Of the OS PASSTHOUGH IP of the Redfish Tab" 
$dracuser = Read-host " enter the user name of the drac admin"
$dracpass = read-host "Enter the Password for the Drac Admin"
Get-IdracServerSlotInformationREDFISH -idrac_ip $DracIP -idrac_username $dracuser -idrac_password $dracpass
 
 

}
Function Option-five {
 
write-host " this section will test Invoke-CreateXauthTokenSessionREDFISH " -ForegroundColor Green
$DracIP = Read-host "Enter the target Drac IP you wish to test from this machine. For OMIMSWAC EMULATION PUT IN THE IP Of the OS PASSTHOUGH IP of the Redfish Tab" 
$dracuser = Read-host " enter the user name of the drac admin"
$dracpass = read-host "Enter the Password for the Drac Admin"
Invoke-CreateXauthTokenSessionREDFISH -idrac_ip $DracIP -idrac_username $dracuser -Idrac_password $dracpass -create_x_auth_token_session y
 #Invoke-CreateXauthTokenSessionREDFISH -idrac_ip 192.168.0.120 -username root -password calvin -create_x_auth_token_session y
 #  This example will create a new X-auth token session for the iDRAC.
 Write-host " token is now created"
 Write-host " you may now want to use the command below to delete the token you just created."
 Write-host "    Invoke-CreateXauthTokenSessionREDFISH -idrac_ip 192.168.0.120 -username root -password calvin -delete_idrac_session /redfish/v1/SessionService/Sessions/22
 #  This example will delete iDRAC session /redfish/v1/SessionService/Sessions/22."
}
Function Option-six {
write-host " Opening up HTML file located in the root of Script Directory" -ForegroundColor Green
$where2=$PSScriptRoot
invoke-expression '.\ListofRedfish.html'| Out-GridView
 

}
Function Option-seven {

$where2=$PSScriptRoot
$RunIdrac = "create_dir_structure_download_iDRAC_Redfish_cmdlets.ps1"
cd $where2

write-host " Removing PS Shell Modules... : "   -ForegroundColor Red

# Create the folder structure syntax for setup of refish powershell comands
$targetnode = $($env:COMPUTERNAME)
$Pwrshell = $PSVersionTable
 
$finalFishpath= "C:\users\"+$($env:USERDOMAIN)+ "\" +$($env:USERNAME)+ "\"+ "Documents\WindowsPowerShell\Modules\*"
$createdirpath= "C:\users\"+$($env:USERDOMAIN)+ "\" +$($env:USERNAME)+ "\"+ "Documents\WindowsPowerShell\Modules\"
$userdomain1 = $($env:USERDOMAIN)+ "\" +$($env:USERNAME)

 
 

#Create Registration Path for Powershell Module  

$checkif = test-path -Path $createdirpath -pathtype any

# review path creation if needed https://www.powershelladmin.com/wiki/Powershell_check_if_folder_exists.php
If (!$checkif) { Write-host "nothing to Delete!" } else {Write-host "Path to Redfish Powershell commands Exists and is Valid!"}

  
#################################################################### 
 
$where2 = $PSScriptRoot
cd $createdirpath

#$myPSlist = gci -Include '*.psm1','*.ps1' -Recurse
(Get-Module | Where-Object {$_.Name -like "*redfish*"}) | Remove-Module
$myDelList = Get-ChildItem -Recurse –Path $createdirpath | ?{$_.Name -like "*redfish*"}
foreach ($my in $myDellist)
{
$my.FullName
Remove-item -Force $my.Name -Recurse


#get-childitem -Path $createdirpath -Filter {$_.Name -imatch "*redfish*"}

}

#gci -Include '*.psm1','*.ps1' -Recurse | Remove-Module -Force

#Get-ChildItem -Path $createdirpath -Include *.* -File -Recurse | foreach { $_.Delete()}

}





Cls

$wherefilesare = $pwd 

Write-host " This script will allow you to perform Redfish Queries without knowing redish." -ForegroundColor Green
Write-host " You should check to make sure the correct installer files are in place before choosing any other item." -ForegroundColor Green
Write-host " If you dont choose #1 First, then you may get failures. check the script about option 1 to check the file path for the proper Powershell modules" -ForegroundColor Green

Write-host "This Script Requires INternet connection to get the files from Github. Hit Q now if you dont have internet or the files needed." -ForegroundColor Red
Write-host " This Script Requires PS remoting and will fail if this is not already enabled." -ForegroundColor Red

Write-host " Choose to install Redfish Powershell Modules for Redfish to run on a specific Host" -ForegroundColor Green
do
 {
    Show-Menu
     $selection = Read-Host "Please make a selection"
     switch ($selection)
     {
         '1' {
             'You chose option #1- Download and Install Required Powershell Modules'
             Install-Fedfish
         } '2' {
             'You chose option #2- Get-IdracRemoteServiceApiStatusREDFISH -idrac_ip 100.72.4.25 -idrac_username root -idrac_password calvin '
             Option-two
         } '3' {
             'You chose option #3 Invoke-ExportHwInventoryLocalREDFISH'
            Option-three
         } '4' {
             'You chose option #4 Get-IdracServerSlotInformationREDFISH'
             option-four
     }   '5' {
             'You chose option #5- Invoke-CreateXauthTokenSessionREDFISH'
             option-five
        } '6' {
             'You chose option #6 - Get a list of other Commands you can run by using your own switchs'
              option-six
       }  '7' {
             'You chose option #7 - Press here to unregister the powershell commands and Delete the directory'
              option-seven
        }

         }
     pause
 }

 until ($selection -eq 'q')
 Write-Output "Time taken: $((Get-Date).Subtract($start_time).Seconds) second(s)"


# 
#  

#
#
#Get-StorageInventoryREDFISH
#IdracRedfishSupport