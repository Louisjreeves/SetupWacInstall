﻿
  $myspanser = read-host "what is the cluster name we are working on? "
 $global:where2 
$where2 = $PSScriptRoot
set-location -Path $where2
cd $where2
Push-Location -Path $where2 
set-location $PSScriptRoot
$mylocation = set-location $PSScriptRoot
$myloc= $PWD.Path 
#CLs 
 $pwd
$Path = $myloc + "\"+ "racadmininstall.exe" #Include the FileName and Extension
$Destination = "C$\Users\$Env:Username\" #Be Sure to use a : instead of a $ for the username variable
$mymachine= $env:COMPUTERNAME
$my=@()
$mycluster= Get-Cluster -Name $myspanser
$mynodes = Get-ClusterNode -Cluster $mycluster | Select-Object name
$counter = (@($mynodes).name).Count
$my= (@($mynodes).name) 
$computername = $my -split " "


Function Copy-File
{
  [Cmdletbinding()]
  Param(
   [Parameter(ValueFromPipeline=$true,Mandatory=$true)]
    [String[]]$ComputerName,
   [Parameter(ValueFromPipeline=$true,Mandatory=$true)]
    [String]$Path,
   [Parameter(ValueFromPipeline=$true,Mandatory=$true)]
    [String]$Destination
   
)
  Process {
   #Extract FileName from Path
   $File = $Path.Split('\')
   $File = $File[$File.Length-1]



  ForEach ($Computer in $ComputerName)
  {
  if ($computer -ne $env:computername)
  {
  
    Write-Verbose "Starting copy to $Computer"
    IF(Test-Path "\\$Computer\$Destination")
    {
     Write-Verbose "Folder $Destination exists on $Computer"
    }
    ELSE
    {
     Write-Verbose "Creating folder $Destination on $Computer"
    IF (New-Item "\\$Computer\$Destination" -Type Directory) {$global:shareyes++}
    }
 
   Write-Verbose "Copying $File to $Computer"
   TRY
   {
    If (Copy-Item -Path $Path -Destination "\\$Computer\$Destination" -Force) {$global:shareyes++}
    Write-Host "Copied to \\$Computer\$Destination\$File`n" -ForegroundColor GREEN

   

  #  New-SMBShare –Name "mytest" `
   ##         –FullAccess Everyone `
     #        -ChangeAccess 'Server Operators' `
      #       -ReadAccess Everyone`
             
#If (New-PSDrive -Name "mytest" -PSProvider "FileSystem" -Root \\$computer\$destination) {$global:shareyes++}

   }
   CATCH
   {
    Write-Warning "Copy failed to $Computer`n"
    
   } 
   } Else {$global:blunder++}

  }#EndForEach
 }#EndProcess
}#EndFunction


# DOwnload Drac Tools to all nodes

copy-file $computername $Path $Destination

$Path = $myloc + "\"+ "isminstall.exe"

 #download ism module 

copy-file $computername $Path $Destination
 



Invoke-Command -computername (Get-ClusterNode).name -ScriptBlock {
$ans1 = $env:USERDNSDOMAIN
Start-Process -FilePath “c:\users\$env:username\racadmininstall.exe" -ArgumentList "/auto" -Wait -ErrorAction SilentlyContinue -ErrorVariable RACAdminExtractFail
Start-Process -FilePath "C:\OpenManage\iDRACTools_x64.msi" -ArgumentList '/quiet /norestart' -Wait -ErrorAction SilentlyContinue -ErrorVariable RACAdminInstallFail
Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any 
Set-Executionpolicy -executionpolicy remotesigned 
Set-Item WSMan:\localhost\Client\TrustedHosts *
Enable-WSManCredSSP -Role Client -Delegate $ans1
Enable-WSManCredSSP -Role Server
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192
New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowFreshCredentialsWhenNTLMOnly -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name 1 -Value * -PropertyType String }


Invoke-Command -computername (Get-ClusterNode).name -ScriptBlock {
$ans1 = $env:USERDNSDOMAIN
 #Start-Process -FilePath "$Env:username\isminstall.exe" -ArgumentList "-auto" -Wait -ErrorAction SilentlyContinue -ErrorVariable ISMExtractFail
 #Start-Process -FilePath "C:\OpenManage\iSM\windows\iDRACSvcMod.msi" -ArgumentList '/quiet /norestart' -Wait -ErrorAction SilentlyContinue -ErrorVariable ISMInstallFail

 Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any 
# for NVME failed disks – reset-physicaldisk -serialnumber xxxxx
Set-Executionpolicy -executionpolicy remotesigned 
Set-Item WSMan:\localhost\Client\TrustedHosts *
Enable-WSManCredSSP -Role Client -Delegate $ans1
Enable-WSManCredSSP -Role Server
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192
New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowFreshCredentialsWhenNTLMOnly -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name 1 -Value * -PropertyType String

set-location "c:\program files\dell\sysmgt\idractools\racadm\" -PassThru
.\racadm set idrac.os-bmc.adminstate 1
.\racadm set iDRAC.WebServer.HostHeaderCheck Disabled
.\racadm set LifeCycleController.LCAttributes.LifecycleControllerState 1
# n45d5 if your using drac8 – check the sessions tab to make sure racadm closessn –u n45d5
.\Racadm set idrac.OS-BMC.PTMode 1
.\racadm set idrac.lockdown.SystemLockdown 0


 }


Invoke-command -ComputerName (Get-Clusternode).Name -ScriptBlock {

$mycurhost = $env:COMPUTERNAME
$mycurdom =$env:userdnsdomain
$myfqdn= $mycurhost + "."+$mycurdom
Write-host -NoNewline " REPORT FOR HOSTNAME:" -ForegroundColor magenta ; $myfqdn
Write-host -NoNewline "get-executionpolicy for $myfqdn is " -ForegroundColor Green ; Get-executionpolicy 

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host -NoNewline "WINRM RULE STATUS for " -ForegroundColor Green ; write-host $myfqdn -ForegroundColor Green
Get-NetFirewallRule -PolicyStore ActiveStore -Name "WINRM-HTTP-In-TCP-PUBLIC"  
#get-NetFirewallRule -Name "WINRM-HTTP-In-TCP-PUBLIC" | Select-Object PrimaryStatus ,action, enabled
write-host "-----------------------------------" -ForegroundColor Yellow
write-host " WSMAN Trusted Host Setting for $myfqdn" -ForegroundColor Green ; get-Item WSMan:\localhost\Client\TrustedHosts
write-host "-----------------------------------" -ForegroundColor Yellow
Write-host "should say alow delegate fresh and a domain name for host $myfqdn" -ForegroundColor Green
Get-WSManCredSSP -Verbose
write-host "-----------------------------------" -ForegroundColor Yellow

set-location "C:\Program Files\Dell\SysMgt\iDRACTools\racadm"

Write-host " THIS IS THE DRAC PORTION SETTINGS for $myfqdn" -ForegroundColor Cyan
write-host "-----------------------------------" -ForegroundColor Cyan
write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " OSINFO should be enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get idrac.servicemodule.osinfo 

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " ServiceModuleEnable  should be Enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get idrac.servicemodule.ServiceModuleEnable

write-host "-----------------------------------"-ForegroundColor Yellow
Write-host " AdminState  should be Enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get idrac.os-bmc.adminstate

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " hostheader   should be Disabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get iDRAC.WebServer.HostHeaderCheck

write-host "-----------------------------------" -ForegroundColor Yellow
Write-host " LCAttributes.LifecycleControllerState  should be enabled for $myfqdn" -ForegroundColor Green

.\racadm.exe get LifeCycleController.LCAttributes.LifecycleControllerState 

Write-host "-----------------------------------" -ForegroundColor Magenta

Write-host " This concludes " ; $myfqdn
Write-host "-----------------------------------" -ForegroundColor Magenta



}


