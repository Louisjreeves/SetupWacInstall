﻿set-location "C:\Program Files\Dell\SysMgt\iDRACTools\racadm"

Write-host "get-executionpolicy is "
Get-executionpolicy 
write-host "-----------------------------------"
get-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC 

Write-host "rule should say outbound allow" -ForegroundColor Green

write-host "-----------------------------------"
get-Item WSMan:\localhost\Client\TrustedHosts

write-host " should say * or domain name " -ForegroundColor Green


write-host "-----------------------------------"
Get-WSManCredSSP -Verbose

Write-host "should say alow delegate fresh  and a domain name " -ForegroundColor Green


write-host "-----------------------------------"
Write-host " OSINFO should be enable" -ForegroundColor Green

.\racadm.exe get idrac.servicemodule.osinfo 

write-host "-----------------------------------" 
Write-host " ServiceModuleEnable  should be Enable" -ForegroundColor Green

.\racadm.exe get idrac.servicemodule.ServiceModuleEnable

write-host "-----------------------------------"
Write-host " AdminState  should be Enabled" -ForegroundColor Green

.\racadm.exe get idrac.os-bmc.adminstate

write-host "-----------------------------------"
Write-host " hostheader   should be Disabled" -ForegroundColor Green

.\racadm.exe get iDRAC.WebServer.HostHeaderCheck

write-host "-----------------------------------"
Write-host " LCAttributes.LifecycleControllerState  should be enabled" -ForegroundColor Green

.\racadm.exe get LifeCycleController.LCAttributes.LifecycleControllerState