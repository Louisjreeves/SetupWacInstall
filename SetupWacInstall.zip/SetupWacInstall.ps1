﻿
#############################################################
#
#
#  CleanUP WAC, OMIMSWAC and Reinstall Properly
#
#
#
#   Clean OMIMSWAC Reinstall Properly CORP Tool 
#
#
#
##############################################################



 $StartTime = get-date 
 $global:blunder
 $global:result
 $global:shareyes
 $global:ans1
$global:shareyes
 $global:multipledetect
 $global:myspanser  
$global:myscluster 
$global:myscurentcomputer
$global:mydom 
$global:mycurUser
$mydom = $env:USERDOMAIN
$global:myFQ = $env:USERDNSDOMAIN
$mycurUser= $Env:USERNAME
$global:where2 
$where2 = $PSScriptRoot
set-location -Path $where2
cd $where2
Push-Location -Path $where2
$myspanser = read-host "what is the name of the cluster we are working on today? "
$myscluster= (Get-clusternode).Name
$myscurentcomputer= $env:COMPUTERNAME
 $global:creds

$global:creds = Get-Credential -UserName $mydom\$mycurUser -Message "Creds for OMIMSWAC Repair"

function Show-Menu
{
    param (
        [string]$Title = 'My Menu'
    )

    Clear-Host
    Write-Host "================ $Title ===================================================================" -ForegroundColor Magenta
    Write-host "Menu MAP  (C) Means changes all Nodes (N) means single node activity (*)(red) is part of Installation" -ForegroundColor Magenta
    Write-host " THE RED ONES ARE THE MINIMUM AND MUST BE RUN FRON ONE CLUSTER NODE. THIS IS YOUR DEPLOYMENT" -ForegroundColor Magenta
    Write-host " ===========================================================================================" -ForegroundColor Magenta

    Write-Host "0: Press '0' (*)IDracTools and Prerequisite Script (C)" -ForegroundColor Red
    Write-Host "1: Press '1' (*)Remove Bad Wac installs and clean out old logs" -ForegroundColor Red
    Write-Host "2: Press '2' (*)Install ISM module or repair And Sets the Proper Racadm Settings for the Host to talk to Drac (C) " -ForegroundColor Red
    Write-Host "3: Press '3' (*)PreRequisites - Test to run for all nodes. Test each Nodes for Connectivity. (N)" -ForegroundColor  Red
    Write-Host "4: Press '4' (*)Installs WAC in Gateway Mode (WAC SERVER) (N) " -ForegroundColor Red

    Write-host " Repair or troubleshooting Options "
    

    Write-Host "5: Press '5' Repair Step. Run on Trouble node. USB NIC clear from Target Machines (N)" -ForegroundColor Yellow

    Write-Host "6: Press '6' Option 6 Will test Redfish And Tell you if you need to check this setting in the Drac. (N)" -ForegroundColor Yellow
    Write-Host "7: Press '7' Option 7 Will remove CAU objects and try to manually recreate. Try CLuster Manager CAU install first. Its likely to work.(C)" -ForegroundColor Green
    Write-Host "8: Press '8' Option 8 WIll collect a full log bundle from all nodes. The ETL are converted to TXT for the Days runs. It puts to a share you define (C)" -ForegroundColor Yellow
    Write-Host "9: Press '9' (*)Optional. This is constrained delegation. Only works for cluster nodes and the WAC machine (C) (C)" -ForegroundColor Green
    Write-Host "Q: Press 'Q' to quit."
}


Function prereque {

cls
$ans= $global:myFQ
 

if ($myscurentcomputer -in $myscluster) 
{
Write-host "checking and installing Racadm Tools if needed"
Write-host " you may see results below. this is just a check if ISM is installed any failure is fixed in step 31"

$global:where2 
$where2 = $PSScriptRoot
set-location -Path $where2
cd $where2
Push-Location -Path $where2
Invoke-Command -ComputerName (Get-ClusterNode).name -ScriptBlock { 
    # Check if racadmin is installed
        $racadminIsInstalled=Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where-Object{$_.DisplayName -imatch "idrac tools"} |  Select-Object DisplayName, DisplayVersion, Publisher, InstallDate | Format-Table –AutoSize
    # If not then download and install racadmin tools
        If(-not($racadminIsInstalled)){
            Try {
                Write-Host "Downloading RACAdmin Tools..."  
                # alternate link https://dl.dell.com/FOLDER05171522M/1/OM-DRAC-Dell-Web-WINX64-9.2.0-3142_A00.exe          
                Invoke-WebRequest -UseBasicParsing -Uri 'https://downloads.dell.com/FOLDER07549599M/1/DellEMC-iDRACTools-Web-WINX64-10.2.0.0-4583_A00.exe' -OutFile "$where2\racadmininstall.exe" -ErrorAction SilentlyContinue -ErrorVariable RACAdminDownloadFailed }
            Catch{
                Write-Host "ERROR: RACAdmin Tools download failed." -ForegroundColor Red
                
            }
            Try {
                Write-Host "Expanding RACAdmin Tools..."
                Start-Process -FilePath "$where2\racadmininstall.exe" -ArgumentList "/auto" -Wait -ErrorAction SilentlyContinue -ErrorVariable RACAdminExtractFail }
            Catch {
                Write-Host "ERROR: Failed to extract RACAdmin tools" -ForegroundColor Red
                
            }
            Try {
                Write-Host "Installing RACAdmin Tools..."
                Start-Process -FilePath "C:\OpenManage\iDRACTools_x64.msi" -ArgumentList '/quiet /norestart' -Wait -ErrorAction SilentlyContinue -ErrorVariable RACAdminInstallFail}
            Catch {
                Write-Host "ERROR: Failed to isntall RADAdmin Tools." -ForegroundColor Red
               
            }}
            
          # RACAdmin Checks
        Try{cd 'C:\Program Files\Dell\SysMgt\iDRACTools\racadm'
            $RACAdminChecks=[PSCustomObject]@{
                osinfo = ((.\racadm.exe get idrac.servicemodule | Where-Object{$_ -imatch 'osinfo'}) -split '=')[-1]
                ServiceModuleEnable = ((.\racadm.exe get idrac.servicemodule | Where-Object{$_ -imatch 'ServiceModuleEnable'}) -split '=')[-1]
                ServiceModuleState = ((.\racadm.exe get idrac.servicemodule | Where-Object{$_ -imatch 'ServiceModuleState'}) -split '=')[-1]
                adminstate = ((.\racadm.exe get idrac.os-bmc.adminstate | Where-Object{$_ -imatch 'adminstate'}) -split '=')[-1]
                HostHeaderCheck = ((.\racadm.exe get iDRAC.WebServer.HostHeaderCheck | Where-Object{$_ -imatch 'HostHeaderCheck'}) -split '=')[-1]
                LifecycleControllerState = (.\racadm.exe get LifeCycleController.LCAttributes.LifecycleControllerState)[0]
            }
            $RACAdminChecks
            If($RACAdminChecks.osinfo -ne 'Enabled'){.\racadm.exe set idrac.servicemodule.osinfo 1}
            IF($RACAdminChecks.ServiceModuleEnable -ne 'Enabled'){.\racadm.exe set idrac.servicemodule.ServiceModuleEnable 1}
            IF($RACAdminChecks.adminstate -ne 'Enabled'){.\racadm.exe set idrac.os-bmc.adminstate 1}
            IF($RACAdminChecks.HostHeaderCheck -ne 'Disabled'){.\racadm.exe set iDRAC.WebServer.HostHeaderCheck 0}
            IF($RACAdminChecks.LifecycleControllerState -ne 'Enabled'){.\racadm.exe set LifeCycleController.LCAttributes.LifecycleControllerState 1}

        } Catch {Write-host "Failures so aborting "}  
            
            }
        
    


Set-Executionpolicy -executionpolicy remotesigned -Force
Set-Item WSMan:\localhost\Client\TrustedHosts * -Force
 

Enable-WSManCredSSP -Role Client -Delegate $env:USERDNSDOMAIN -force
Enable-WSManCredSSP -Role Server -Force
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192 -Force
New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowFreshCredentialsWhenNTLMOnly -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name 1 -Value * -PropertyType String -Force
 
 }      

 ELse {
 If ($myscurentcomputer -notin $myscluster){
cls
write-host "We detected this node is not a cluster node or you did not enter a reachable cluster. "
write-host " That is Ok. we can still do work if this is your WAC machine"
Write-host " Here we will run the WAC permisions repair"
##Begin PowerShell Script – Paste this in ISE PowerShell##
#$a= Read-Host “what is the full domain name?”
#$str1="*" 
#$ans1= $str1+"."+$a
$ans1 = $env:USERDNSDOMAIN
#ix source machines
Set-Executionpolicy -executionpolicy unrestricted -Force
Set-NetFirewallRule -Name WINRM-HTTP-In-TCP-PUBLIC -RemoteAddress Any 
Set-Item WSMan:\localhost\Client\TrustedHosts * -Force
Enable-WSManCredSSP -Role Client -Delegate $env:USERDNSDOMAIN -Force
Enable-WSManCredSSP -Role Server -Force
Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb 8192 -Force

New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation -Name AllowFreshCredentialsWhenNTLMOnly -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentialsWhenNTLMOnly -Name 1 -Value * -PropertyType String -Force
##End PowerShell Script – Paste this in ISE PowerShell##
 

}
}
Write-host "This completes the Prerequisites"

}

Function Super-cleanWAC
{

#Calling Powershell as Admin and setting Execution Policy to Bypass to avoid Cannot run Scripts error
param ([switch]$Elevated)
function CheckAdmin {
    $currentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent())
    $currentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
}
if ((CheckAdmin) -eq $false) {
    if ($elevated) {
        # could not elevate, quit
    }
    else {
        # Detecting Powershell (powershell.exe) or Powershell Core (pwsh), will return true if Powershell Core (pwsh)
        if ($IsCoreCLR) { $PowerShellCmdLine = "pwsh.exe" } else { $PowerShellCmdLine = "powershell.exe" }
        $CommandLine = "-noprofile -ExecutionPolicy Bypass -File `"" + $MyInvocation.MyCommand.Path + "`" " + $MyInvocation.UnboundArguments + ' -Elevated'
        Start-Process "$PSHOME\$PowerShellCmdLine" -Verb RunAs -ArgumentList $CommandLine
    }
    Exit
}

# Rename Title Window
$host.ui.RawUI.WindowTitle = "Clean Browser Temp Files"

Function Cleanup {
    # Set Date for Log
    $LogDate = Get-Date -Format "MM-d-yy-HHmm"

    # Ask for confirmation to delete users Downloaded files - Anything older than 90 days
    $DeleteOldDownloads = Read-Host "Would you like to delete files older than 90 days in the Downloads folder for All Users? (Y/N)"
    
    # Set Deletion Date for Downloads Folder
    $DelDownloadsDate = (Get-Date).AddDays(-90)

    # Set Deletion Date for Inetpub Log Folder
    $DelInetLogDate = (Get-Date).AddDays(-30)

    # Set Deletion Date for System32 Log Folder
    $System32LogDate = (Get-Date).AddMonths(-2)

    # Set Deletion Date for Azure Logs Folder
    $DelAZLogDate = (Get-Date).AddDays(-7)

   # Ask for Confirmation to Empty Recycle Bin for All Users
    $CleanBin = Read-Host "Would you like to empty the Recycle Bin for All Users? (Y/N)"

      # Get Disk Size
    $Before = Get-WmiObject Win32_LogicalDisk | Where-Object { $_.DriveType -eq "3" } | Select-Object SystemName,
    @{ Name = "Drive" ; Expression = { ( $_.DeviceID ) } },
    @{ Name = "Size (GB)" ; Expression = { "{0:N1}" -f ( $_.Size / 1gb) } },
    @{ Name = "FreeSpace (GB)" ; Expression = { "{0:N1}" -f ( $_.Freespace / 1gb ) } },
    @{ Name = "PercentFree" ; Expression = { "{0:P1}" -f ( $_.FreeSpace / $_.Size ) } } |
    Format-Table -AutoSize | Out-String

    # Define log file location
    $Cleanuplog = "$env:USERPROFILE\Cleanup$LogDate.log"

    # Start Logging
    Start-Transcript -Path "$CleanupLog"

    # Create list of users
    Write-Host -ForegroundColor Green "Getting the list of Users`n"
    $Users = Get-ChildItem "C:\Users" | Select-Object Name
    $users = $Users.Name 
    
    
    # Begin!
    Write-Host -ForegroundColor Green "Beginning Script...`n"

    # Clear Firefox Cache
    Write-Host -ForegroundColor Green "Clearing Firefox Cache`n"
    Foreach ($user in $Users) {
        if (Test-Path "C:\Users\$user\AppData\Local\Mozilla\Firefox\Profiles") {
            Remove-Item -Path "C:\Users\$user\AppData\Local\Mozilla\Firefox\Profiles\*\cache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Mozilla\Firefox\Profiles\*\cache2\entries\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Mozilla\Firefox\Profiles\*\thumbnails\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Mozilla\Firefox\Profiles\*\cookies.sqlite" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Mozilla\Firefox\Profiles\*\webappsstore.sqlite" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Mozilla\Firefox\Profiles\*\chromeappsstore.sqlite" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Mozilla\Firefox\Profiles\*\OfflineCache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        }
        Write-Host -ForegroundColor Yellow "Done...`n"
    }
    # Clear Google Chrome
    Write-Host -ForegroundColor Green "Clearing Google Chrome Cache`n"
    Foreach ($user in $Users) {
        if (Test-Path "C:\Users\$user\AppData\Local\Google\Chrome\User Data") {
            Remove-Item -Path "C:\Users\$user\AppData\Local\Google\Chrome\User Data\Default\Cache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Google\Chrome\User Data\Default\Cache2\entries\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Google\Chrome\User Data\Default\Cookies" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Google\Chrome\User Data\Default\Media Cache" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Google\Chrome\User Data\Default\Cookies-Journal" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Google\Chrome\User Data\Default\JumpListIconsOld" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            # Comment out the following line to remove the Chrome Write Font Cache too.
            # Remove-Item -Path "C:\Users\$user\AppData\Local\Google\Chrome\User Data\Default\ChromeDWriteFontCache" -Recurse -Force -ErrorAction SilentlyContinue -Verbose

            # Check Chrome Profiles. It looks as though when creating profiles, it just numbers them Profile 1, Profile 2 etc.
            $Profiles = Get-ChildItem -Path "C:\Users\$user\AppData\Local\Google\Chrome\User Data" | Select-Object Name | Where-Object Name -Like "Profile*"
            foreach ($Account in $Profiles) {
                $Account = $Account.Name 
                Remove-Item -Path "C:\Users\$user\AppData\Local\Google\Chrome\User Data\$Account\Cache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
                Remove-Item -Path "C:\Users\$user\AppData\Local\Google\Chrome\User Data\$Account\Cache2\entries\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose 
                Remove-Item -Path "C:\Users\$user\AppData\Local\Google\Chrome\User Data\$Account\Cookies" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
                Remove-Item -Path "C:\Users\$user\AppData\Local\Google\Chrome\User Data\$Account\Media Cache" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
                Remove-Item -Path "C:\Users\$user\AppData\Local\Google\Chrome\User Data\$Account\Cookies-Journal" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
                Remove-Item -Path "C:\Users\$user\AppData\Local\Google\Chrome\User Data\$Account\JumpListIconsOld" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            }
        }
        Write-Host -ForegroundColor Yellow "Done...`n"
    }

    # Clear Internet Explorer & Edge
    Write-Host -ForegroundColor Yellow "Clearing Internet Explorer & Old Edge Cache`n"
    Foreach ($user in $Users) {
        Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Windows\Temporary Internet Files\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Windows\INetCache\* " -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Windows\WebCache\* " -Recurse -Force -ErrorAction SilentlyContinue -Verbose

        $path = [Environment]::ExpandEnvironmentVariables("%LOCALAPPDATA%\Packages\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\AC\") + '\#!*'
Remove-Item $path -Force
    }
    Write-Host -ForegroundColor Yellow "Done...`n"

    # Clear Edge Chromium
    Write-Host -ForegroundColor Yellow "Clearing Edge Chromium Cache`n"
    taskkill /F /IM msedge.exe
    Foreach ($user in $Users) {
        if (Test-Path "C:\Users\$user\AppData\Local\Microsoft\Edge\User Data") {
            Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Edge\User Data\Default\Cache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            #Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Edge\User Data\Default\Cache2\entries\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Edge\User Data\Default\Cookies" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            #Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Edge\User Data\Default\Media Cache" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Edge\User Data\Default\Cookies-Journal" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            #Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Edge\User Data\Default\JumpListIconsOld" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            # Comment out the following line to remove the Edge Write Font Cache too.
            # Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Edge\User Data\Default\EdgeDWriteFontCache" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        
            # Check Edge Profiles. It looks as though when creating profiles, it just numbers them Profile 1, Profile 2 etc.
            $Profiles = Get-ChildItem -Path "C:\Users\$user\AppData\Local\Microsoft\Edge\User Data" | Select-Object Name | Where-Object Name -Like "Profile*"
            foreach ($Account in $Profiles) {
                $Account = $Account.Name 
                Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Edge\User Data\$Account\Cache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
                #Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Edge\User Data\$Account\Cache2\entries\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose 
                Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Edge\User Data\$Account\Cookies" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
                #Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Edge\User Data\$Account\Media Cache" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
                Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Edge\User Data\$Account\Cookies-Journal" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
                #Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Edge\User Data\$Account\JumpListIconsOld" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            }
        }
        Write-Host -ForegroundColor Yellow "Done...`n" 

    # Clear Chromium
    Write-Host -ForegroundColor Yellow "Clearing Chromium Cache`n"
    Foreach ($user in $Users) {
        if (Test-Path "C:\Users\$user\AppData\Local\Chromium") {
            Remove-Item -Path "C:\Users\$user\AppData\Local\Chromium\User Data\Default\Cache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Chromium\User Data\Default\GPUCache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Chromium\User Data\Default\Media Cache" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Chromium\User Data\Default\Pepper Data" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Chromium\User Data\Default\Application Cache" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        }
        Write-Host -ForegroundColor Yellow "Done...`n" 
    }
    
    # Clear Opera
    Write-Host -ForegroundColor Yellow "Clearing Opera Cache`n"
    Foreach ($user in $Users) {
        if (Test-Path "C:\Users\$user\AppData\Local\Opera Software") {
            Remove-Item -Path "C:\Users\$user\AppData\Local\Opera Software\Opera Stable\Cache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        } 
        Write-Host -ForegroundColor Yellow "Done...`n"
    }

    # Clear Yandex
    Write-Host -ForegroundColor Yellow "Clearing Yandex Cache`n"
    Foreach ($user in $Users) {
        if (Test-Path "C:\Users\$user\AppData\Local\Yandex") {
            Remove-Item -Path "C:\Users\$user\AppData\Local\Yandex\YandexBrowser\User Data\Default\Cache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Yandex\YandexBrowser\User Data\Default\GPUCache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Yandex\YandexBrowser\User Data\Default\Media Cache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Yandex\YandexBrowser\User Data\Default\Pepper Data\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Yandex\YandexBrowser\User Data\Default\Application Cache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Yandex\YandexBrowser\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        } 
        Write-Host -ForegroundColor Yellow "Done...`n"
    }
   # }

    # Clear User Temp Folders
    Write-Host -ForegroundColor Yellow "Clearing User Temp Folders`n"
    Foreach ($user in $Users) {
        Remove-Item -Path "C:\Users\$user\AppData\Local\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Windows\WER\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Windows\AppCache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        Remove-Item -Path "C:\Users\$user\AppData\Local\CrashDumps\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
    }
    Write-Host -ForegroundColor Yellow "Done...`n"
    # Clear Windows Temp Folder
    Write-Host -ForegroundColor Yellow "Clearing Windows Temp Folder`n"
    Foreach ($user in $Users) {
        Remove-Item -Path "C:\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        Remove-Item -Path "$env:windir\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        Remove-Item -Path "$env:windir\Logs\CBS\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        Remove-Item -Path "$env:ProgramData\Microsoft\Windows\WER\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        # Only grab log files sitting in the root of the Logfiles directory
        $Sys32Files = Get-ChildItem -Path "$env:windir\System32\LogFiles" | Where-Object { ($_.name -like "*.log") -and ($_.lastwritetime -lt $System32LogDate) }
        foreach ($File in $Sys32Files) {
            Remove-Item -Path "$env:windir\System32\LogFiles\$($file.name)" -Force -ErrorAction SilentlyContinue -Verbose
        }
    }
    Write-Host -ForegroundColor Yellow "Done...`n"          

    # Clear Inetpub Logs Folder
    if (Test-Path "C:\inetpub\logs\LogFiles\") {
        Write-Host -ForegroundColor Yellow "Clearing Inetpub Logs Folder`n"
        $Folders = Get-ChildItem -Path "C:\inetpub\logs\LogFiles\" | Select-Object Name
        foreach ($Folder in $Folders) {
            $folder = $Folder.Name
            Remove-Item -Path "C:\inetpub\logs\LogFiles\$Folder\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose | Where-Object LastWriteTime -LT $DelInetLogDate
        }
        Write-Host -ForegroundColor Yellow "Done...`n" 
    }

    # Delete Microsoft Teams Previous Version files
    Write-Host -ForegroundColor Yellow "Clearing Teams Previous version`n"
    Foreach ($user in $Users) {
        if (Test-Path "C:\Users\$user\AppData\Local\Microsoft\Teams\") {
            Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Teams\previous\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\AppData\Local\Microsoft\Teams\stage\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        } 
    }
    Write-Host -ForegroundColor Yellow "Done...`n"

    # Delete SnagIt Crash Dump files
    Write-Host -ForegroundColor Yellow "Clearing SnagIt Crash Dumps`n"
    Foreach ($user in $Users) {
        if (Test-Path "C:\Users\$user\AppData\Local\TechSmith\SnagIt") {
            Remove-Item -Path "C:\Users\$user\AppData\Local\TechSmith\SnagIt\CrashDumps\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        } 
    }
    Write-Host -ForegroundColor Yellow "Done...`n"

    # Clear Dropbox
    Write-Host -ForegroundColor Yellow "Clearing Dropbox Cache`n"
    Foreach ($user in $Users) {
        if (Test-Path "C:\Users\$user\Dropbox\") {
            Remove-Item -Path "C:\Users\$user\Dropbox\.dropbox.cache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
            Remove-Item -Path "C:\Users\$user\Dropbox*\.dropbox.cache\*" -Recurse -Force -ErrorAction SilentlyContinue -Verbose
        }
    }
    Write-Host -ForegroundColor Yellow "Done...`n"
  

    # Delete files older than 90 days from Downloads folder
    if ($DeleteOldDownloads -eq 'Y') { 
        Write-Host -ForegroundColor Yellow "Deleting files older than 90 days from User Downloads folder`n"
        Foreach ($user in $Users) {
            $UserDownloads = "C:\Users\$user\Downloads"
            $OldFiles = Get-ChildItem -Path "$UserDownloads\" -Recurse -File -ErrorAction SilentlyContinue | Where-Object LastWriteTime -LT $DelDownloadsDate
            foreach ($file in $OldFiles) {
                Remove-Item -Path "$UserDownloads\$file" -Force -ErrorAction SilentlyContinue -Verbose
            }
        }
        Write-Host -ForegroundColor Yellow "Done...`n"
    }

    # Delete files older than 7 days from Azure Log folder
    if (Test-Path "C:\WindowsAzure\Logs") {
        Write-Host -ForegroundColor Yellow "Deleting files older than 7 days from Azure Log folder`n"
        $AzureLogs = "C:\WindowsAzure\Logs"
        $OldFiles = Get-ChildItem -Path "$AzureLogs\" -Recurse -File -ErrorAction SilentlyContinue | Where-Object LastWriteTime -LT $DelAZLogDate
        foreach ($file in $OldFiles) {
            Remove-Item -Path "$AzureLogs\$file" -Force -ErrorAction SilentlyContinue -Verbose
        }
        Write-Host -ForegroundColor Yellow "Done...`n"
    } 

     
    }
    Write-Host -ForegroundColor Yellow "Done...`n"

   
    # Empty Recycle Bin
    if ($Cleanbin -eq 'Y') {
        Write-Host -ForegroundColor Green "Cleaning Recycle Bin`n"
        $ErrorActionPreference = 'SilentlyContinue'
        $RecycleBin = "C:\`$Recycle.Bin"
        $BinFolders = Get-ChildItem $RecycleBin -Directory -Force

        Foreach ($Folder in $BinFolders) {
            # Translate the SID to a User Account
            $objSID = New-Object System.Security.Principal.SecurityIdentifier ($folder)
            try {
                $objUser = $objSID.Translate( [System.Security.Principal.NTAccount])
                Write-Host -Foreground Yellow -Background Black "Cleaning $objUser Recycle Bin"
            }
            # If SID cannot be Translated, Throw out the SID instead of error
            catch {
                $objUser = $objSID.Value
                Write-Host -Foreground Yellow -Background Black "$objUser"
            }
            $Files = @()

            if ($PSVersionTable.PSVersion -Like "*2*") {
                $Files = Get-ChildItem $Folder.FullName -Recurse -Force
            }
            else {
                $Files = Get-ChildItem $Folder.FullName -File -Recurse -Force
                $Files += Get-ChildItem $Folder.FullName -Directory -Recurse -Force
            }

            $FileTotal = $Files.Count

            for ($i = 1; $i -le $Files.Count; $i++) {
                $FileName = Select-Object -InputObject $Files[($i - 1)]
                Write-Progress -Activity "Recycle Bin Clean-up" -Status "Attempting to Delete File [$i / $FileTotal]: $FileName" -PercentComplete (($i / $Files.count) * 100) -Id 1
                Remove-Item -Path $Files[($i - 1)].FullName -Recurse -Force
            }
            Write-Progress -Activity "Recycle Bin Clean-up" -Status "Complete" -Completed -Id 1
        }
        Write-Host -ForegroundColor Green "Done`n `n"
    }

    Write-Host -ForegroundColor Green "All Tasks Done!`n`n"


    # Get Drive size after clean
    $After = Get-WmiObject Win32_LogicalDisk | Where-Object { $_.DriveType -eq "3" } | Select-Object SystemName,
    @{ Name = "Drive" ; Expression = { ( $_.DeviceID ) } },
    @{ Name = "Size (GB)" ; Expression = { "{0:N1}" -f ( $_.Size / 1gb) } },
    @{ Name = "FreeSpace (GB)" ; Expression = { "{0:N1}" -f ( $_.Freespace / 1gb ) } },
    @{ Name = "PercentFree" ; Expression = { "{0:P1}" -f ( $_.FreeSpace / $_.Size ) } } |
    Format-Table -AutoSize | Out-String

    # Sends some before and after info for ticketing purposes
    Write-Host -ForegroundColor Green "Before: $Before"
    Write-Host -ForegroundColor Green "After: $After"

    # Another reminder about running Windows update if needed as it would get lost in all the scrolling text.
    if ($CleanWU -eq 'Y') { 
        Write-Host -ForegroundColor Yellow "`nPlease rerun Windows Update to pull down the latest updates. `n"
    }

    # Read some of the output before going away
    Start-Sleep -s 15

    # Completed Successfully!
    # Open Text File
    Invoke-Item $Cleanuplog

    # Stop Script
    Stop-Transcript
}


# Listing all files in C:\Temp\* recursively, using Force parameter displays hidden files.
$TempItems = Get-ChildItem -Path "C:\Temp\*" -Recurse -Force
if ($TempItems.count -gt 1) {
    Write-Warning "There are files within C:\Temp, please verify that important files are out of this location"
    $Cont = Read-Host "Continue with the cleanup script [Y/N]"
    if ($cont -eq "Y") { 
        Cleanup
    }
    else {
        Write-Host "Please check the files within C:\Temp before running the script again"
        Start-Sleep -Seconds 5
    }
}
else {
    cleanup
}


}


 
Function Cleanup-one {


$global:creds = Get-Credential -UserName $mydom\$mycurUser -Message " Enter your S2d Admin Creds"
$global:ans1= read-host " we are backing up old logs. do you want to keep the old second copy? (Y) deletes (N) leaves you with 2 sets of logs."
$WhereShare = read-host "Please enter a Share UNC path where all cluster nodes can write too."
 
 
set-location -Path $whereshare
cd $whereshare
Push-Location -Path $whereshare

#$WhereShare = "\\gsejumpbox\repositoryDSU\backup"
#$credential = Get-Credential
#$workstations = $myscluster.name
if ($env:COMPUTERNAME -in $myscluster)
{
Invoke-Command -ComputerName (get-clusternode).Name -ScriptBlock {
    $psdrive = @{
        Name = "PSDrive"
        PSProvider = "FileSystem"
        Root = $Using:WhereShare
        Credential = $using:creds
       
    }
    $ans2= $global:myFQ
   $mypsdrive = New-PSDrive @psdrive 
    $mycomp = $env:computername
    cd PSDrive
# Set the PSDrive and create the FOlder Name to write to on a per Node basis 
# all logs for one server go un one log locaiton   
 
    new-item -path PSDrive:\$mycomp -ItemType directory -Force
   $pathmy = set-location -Path PSDrive:\$mycomp 
   # Copy-Item -Path "Microsoft.PowerShell.Core\FileSystem::\\path\to\source\filename.ext" -Destination "Microsoft.PowerShell.Core\FileSystem::\\path\to\target\"

# Define the folders that need to be tranfered 
$myinvokuser= $Env:USERNAME
       $MainLogs = "C:\Windows\ServiceProfiles\NetworkService\Appdata\Local\Temp\generated\"
 
        $pushfiles = "C:\Windows\Temp\OMIMSWAC\*"
        $Failedupdate= "C:\ProgramData\Server Management Experience\*"
        $Duplog = "C:\temp\sme\*"
        $updatelog = "C:\Users\$myinvokuser\appdata\roaming\update\log\*"
        $applogs1= "C:\Users\$myinvokuser\AppData\Roaming\Update\*"
        $applogs2 = "C:\Users\$myinvokuser\AppData\Roaming\compliance\*"


    copy-item "c:\Windows\Temp\OMIMSWAC\*" -Recurse -Destination $pathmy -Force

        copy-item $MainLogs -Recurse -Destination $pathmy -verbose
        copy-item $pushfiles -Recurse -Destination $pathmy  -verbose
        copy-item $Failedupdate -Recurse -Destination $pathmy  -verbose
        copy-item $Duplog -Recurse -Destination $pathmy -verbose
        copy-item $updatelog -Recurse -Destination $pathmy  -verbose
        copy-item $applogs1 -Recurse -Destination $pathmy  -verbose
        copy-item $applogs2  -Recurse -Destination $pathmy  -verbose

        Cls
        $ans2 = Read-host " Do you want to delete old logs? Y to proceed or N to abort."
         if ( $ans2 -notlike '*n*')
         {
       set-location -Path $mainlogs | Remove-Item -Path "$mainlogs\*" -Recurse -force
       set-location -Path $share1|  Remove-Item -Path "$share1\*" -Recurse -force
       set-location -Path $pushfiles| Remove-Item -Path "$pushfiles\*" -Recurse -force
        set-location -Path $updatelog |   Remove-Item -Path "$updatelog\*" -Recurse -force
        set-location -Path $applogs1|  Remove-Item -Path "$applogs1\*" -Recurse -force
        set-location -Path $applogs2|  Remove-Item -Path "$applogs2\*" -Recurse -force
        #Remove-Item -Path "$applogs3\*" -Recurse -force
       set-location -Path |   Remove-Item -Path "$Failedupdate\*" -Recurse -force

} 

# Now Getting the WAC removed from all cluster nodes

$App = "Windows Admin Center"
$uninstall = (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | where {$_. Uninstallstring -eq 'MsiExec.exe /I{3521D637-18A7-4FA7-B1BB-6F55027F17B2}'})
$uninstall = (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | where {$_.displayname -like "*$App*"} | Select-Object -Property UninstallString)
$cal = @()
$all = @()
Try {
$cal,$all = ($uninstall.UninstallString).split(' ')
$all.Trim()
$Fix = $all -replace "/I", "/X"

cls
Write-host "Moving to cleaning log files. you may see one message per server. respond to each question. Ignore errors." -ForegroundColor Green 
Write-host " This may take a while depending on how many installs were made to the cluster".
Start-Process $cal -ArgumentList "$fix /qn" -Wait
}Catch {Write-host "not installed.. Or already Removed" -ErrorAction Continue}

Get-PSDrive PSDrive | Remove-PSDrive -scope global
 
 
}  



### CHeck for CLuster or not = not is assumed to be wac server 

}

if ($env:computername -ine $myscluster) {
$destination = $WhereShare
$rev= "WAC"
If($destination.EndsWith('\')){
$destination = $destination -replace '\\$',""}

if (!(Test-Path $destination$rev)) {mkdir $rev}
$finalDest = "$destination\$rev"
$clearWAClog= "C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Temp\generated\"
$dellDupLog = "C:\ProgramData\Dell\DELL EMC System Update"
$dsuInstaller = "C:\ProgramData\Dell\UpdatePackage\log"

copy-item $clearWAClog -Recurse $finalDest  -verbose
copy-item $dellDupLog -Recurse $finalDest  -verbose
copy-item $dsuInstaller -Recurse $finalDest  -verbose

Remove-Item -Path "$clearWAClog\*" -Recurse -Force
Remove-Item -Path "$dellDupLog\*" -Recurse -Force
Remove-Item -Path "$dsuInstaller\*" -Recurse -Force


$App = "Windows Admin Center"
$uninstall = (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | where {$_. Uninstallstring -eq 'MsiExec.exe /I{3521D637-18A7-4FA7-B1BB-6F55027F17B2}'})
$uninstall = (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | where {$_.displayname -like "*$App*"} | Select-Object -Property UninstallString)
$cal = @()
$all = @()
Try {
$cal,$all = ($uninstall.UninstallString).split(' ')
$all.Trim()
$Fix = $all -replace "/I", "/X"

cls
Write-host "Moving to cleaning log files. you may see one message per server. respond to each question. Ignore errors." -ForegroundColor Green 
Write-host " This may take a while depending on how many installs were made to the cluster".
Start-Process $cal -ArgumentList "$fix /qn" -Wait

Cls
Write-host "Moving to Superclean WAC Browser Caches. Hit a key and enter to begin" -ForegroundColor Green; read-host '$myans12'
Super-cleanWAC


}Catch {Write-host "No bad installs or logs found .. Or already Removed" -ErrorAction Continue}



}
}






Function Option-five
{
cls
# Device is used with Inventory collector SECUPD along with some drive letter
$unDevs = @(Get-PnpDevice -class USB | ? Status -eq Unknown)
$devs = @(Get-PnpDevice -Class wpd)

ForEach ($Dev in $Devs) {
    Write-Host "Removing $($Dev.FriendlyName)" -ForegroundColor Cyan
    $RemoveKey = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($Dev.InstanceId)"
    Get-Item $RemoveKey | Select-Object -ExpandProperty Property | %{ Remove-ItemProperty -Path $RemoveKey -Name $_ -Verbose }

    # now removing USB nic as well
try {
$deviceName="Remote NDIS Compatible Device"
$DeviceById= Get-PnpDevice -InstanceId "USB\VID_413C&PID_A102\5678" -ErrorAction SilentlyContinue -ErrorVariable SilentlyContinue
$DeviceByDeviceName = Get-PnpDevice | Where-Object {$_.Name -eq $deviceName} -ErrorAction SilentlyContinue -ErrorVariable SilentlyContinue
} Catch {Write-host "device not found"}

If ($DeviceById)
{
try{
pnputil /remove-device -instanceid "USB\VID_413C&PID_A102\5678"
} Catch {Write-host "USB not present"}

}
Write-Host "Done removing Secupd, Dell Drive Letter and USBNIC"

Try{
 
ForEach ($unDev in $UnKDevs) {
    Write-Host "Removing $($unDev.FriendlyName)" -ForegroundColor Cyan
    $RemoveKey = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($unDev.InstanceId)"
    $myre1 = (Get-Item $RemoveKey | Select-Object -ExpandProperty Property | %{ Remove-ItemProperty -Path $RemoveKey -Name $_ -Verbose })
}

Write-Host "Done removing unknown Devices from the server"
}Catch {Write-host "Device is not present"}
}

### If the IPMI device is not able to be added back - you may try this command Rundll32 ipmisetp.dll, AddTheDevice

Get-service -name IPMIDRV

$myIPMIdevice = Get-PnpDevice -Class system -FriendlyName "microsoft Generic IPMI compliant device"

Write-host " IPMI driver is something you should check manually. Here is the checklist while troubleshooting."
Write-host " It should be running if you look above, unless WAC/OMIMSWAC has never worked. If this is the case, just move forward. Install Will correct this"
Write-host " Look for event id 1004 and concider a timeout change if needed - https://urldefense.com/v3/__https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2008-R2-and-2008/dd363714(v=ws.10)?redirectedfrom=MSDN__;!!LpKI!jhvo9QLBDPeYtUkFnQyFwnc0Wm1XpvyHmoZsoHlhzfX4-VGhPYNyRDkZB7OGK-EOfw0mC1RhXxnozPfyGEGThq9w2x-y$ [docs[.]microsoft[.]com]"
Write-host " If the device is present (system) and the Service is running , Monitor for errors"

Write-Host "Devices been cleared by this script. The goals is for the devices to be recreated, and the communication between IPMI, USBNIC, SECUPD, WINRM/WMI and Powershell will be restored"

}


Function Option-two
{

 
cls
  Invoke-Command -ComputerName (Get-ClusterNode).name -ScriptBlock {   
  
  #Racadm WIll have allready been installed by step 1. These checks are going against known good drac installs
  #We then move to installing ISM   
  $myhost= $env:COMPUTERNAME
    # RACAdmin Checks
        Try{cd 'C:\Program Files\Dell\SysMgt\iDRACTools\racadm'
            $RACAdminChecks=[PSCustomObject]@{
                osinfo = ((.\racadm.exe get idrac.servicemodule | Where-Object{$_ -imatch 'osinfo'}) -split '=')[-1]
                ServiceModuleEnable = ((.\racadm.exe get idrac.servicemodule | Where-Object{$_ -imatch 'ServiceModuleEnable'}) -split '=')[-1]
                ServiceModuleState = ((.\racadm.exe get idrac.servicemodule | Where-Object{$_ -imatch 'ServiceModuleState'}) -split '=')[-1]
                adminstate = ((.\racadm.exe get idrac.os-bmc.adminstate | Where-Object{$_ -imatch 'adminstate'}) -split '=')[-1]
                HostHeaderCheck = ((.\racadm.exe get iDRAC.WebServer.HostHeaderCheck | Where-Object{$_ -imatch 'HostHeaderCheck'}) -split '=')[-1]
                LifecycleControllerState = (.\racadm.exe get LifeCycleController.LCAttributes.LifecycleControllerState)[0]
}
}

            catch{} 


$RACAdminChecks
            If($RACAdminChecks.osinfo -ne 'Enabled'){.\racadm.exe set idrac.servicemodule.osinfo 1}
            IF($RACAdminChecks.ServiceModuleEnable -ne 'Enabled'){.\racadm.exe set idrac.servicemodule.ServiceModuleEnable 1}
            IF($RACAdminChecks.adminstate -ne 'Enabled'){.\racadm.exe set idrac.os-bmc.adminstate 1}
            IF($RACAdminChecks.HostHeaderCheck -ne 'Disabled'){.\racadm.exe set iDRAC.WebServer.HostHeaderCheck 0}
            IF($RACAdminChecks.LifecycleControllerState -ne 'Enabled'){.\racadm.exe set LifeCycleController.LCAttributes.LifecycleControllerState 1}
            IF($RACAdminChecks.ServiceModuleState -ne 'Running'){
             $ansbl= read-host "One node is not working. Reinstall (y)? "
            If ($ansbl -ilike "*y*")
            
            {
            
            
            # install ism
           
                            (Get-WmiObject -Class Win32_Product -Filter "Name = 'Dell EMC iDRAC Service Module'").uninstall()
                        # download new ism
                            Try {
                                Write-Host "Downloading ISM..." 
                                Invoke-WebRequest -UseBasicParsing -Uri 'https://dl.dell.com/FOLDER07508105M/1/OM-iSM-Dell-Web-X64-4.1.0.0-2410_A00.exe' -OutFile "$Env:Temp\isminstall.exe" -ErrorAction SilentlyContinue -ErrorVariable ISMDownloadFailed }
                            Catch{
                                Write-Host "ERROR: ISM download failed. $ISMDownloadFailed" -ForegroundColor Red
                               
                                }
                        # extract the downloaded ism
                            Try{
                                Write-Host "Expanding ISM..."
                                Start-Process -FilePath "$Env:Temp\isminstall.exe" -ArgumentList "-auto" -Wait -ErrorAction SilentlyContinue -ErrorVariable ISMExtractFail}
                            Catch {
                                Write-Host "ERROR: Failed to isntall RADAdmin Tools. $ISMExtractFail" -ForegroundColor Red
                               
                                }

                        # install ism
                            Try{
                                Write-Host "Installing ISM..."
                                Start-Process -FilePath "C:\OpenManage\iSM\windows\iDRACSvcMod.msi" -ArgumentList '/quiet /norestart' -Wait -ErrorAction SilentlyContinue -ErrorVariable ISMInstallFail}
                            
                            Catch {
                                Write-Host "ERROR: Failed to isntall RADAdmin Tools. $ISMInstallFail" -ForegroundColor Red
                               
                                }
                    }
            } else {
            
          $reader=   Read-host "You are all setup with ISM and cleanup. Press a key (working on $myhost) and enter to continue."
            }
            
            
            
            
            
            
            
            }
 
 
 cls
 Write-host " This final step in this section will attempt to disable the USB nic from the cluster communication." -ForegroundColor Green

 Write-host "Please open cluster manager and confirm the USBNIC network is showing under networks." -ForegroundColor Green
 Write-host " come back to step 2 after discovery if needed to diable cluster communicaiton for the USBNIC network" -ForegroundColor Green
 
 
 Get-ClusterNetwork | ft Name, Metric
$my169net = Get-ClusterNetwork | sort metric
$my169max = ($my169net| select -last 1)

write-host "$my169max we are removing this network from cluster communications" -ForegroundColor Yellow
Write-host "$my169max is the network we identified to remove from cluster communications. Please verify in the network section of cluster manager. this should be the NDIS compatible device nics" -ForegroundColor Green
$myread69 = Read-host "please hit Y and enter to confirm this network is ok to disable for cluster communicaiton"

if ($myread69 -ilike '*y*') {$my169max.role = 0 } 

$myusbnic1 = Get-NetAdapter -InterfaceDescription "Remote NDIS Compatible Device" 

$myusbnic1| Disable-NetAdapter
$myusbnic1 | Enable-NetAdapter

Cls
Write-host "USB Network now removed from cluster network communications"  -ForegroundColor Green
$finished= read-host "hit a key and enter to continue"   
                             
}

Function Copy-File
{
  [Cmdletbinding()]
  Param(
   [Parameter(ValueFromPipeline=$true,Mandatory=$true)]
    [String[]]$ComputerName,
   [Parameter(ValueFromPipeline=$true,Mandatory=$true)]
    [String]$Path,
   [Parameter(ValueFromPipeline=$true,Mandatory=$true)]
    [String]$Destination
   
)
  Process {
   #Extract FileName from Path
   $File = $Path.Split('\')
   $File = $File[$File.Length-1]



  ForEach ($Computer in $ComputerName)
  {
   
  
  
    Write-Verbose "Starting copy to $Computer"
    IF(Test-Path "\\$Computer\$Destination")
    {
     Write-Verbose "Folder $Destination exists on $Computer"
    }
    ELSE
    {
     Write-Verbose "Creating folder $Destination on $Computer"
    IF (New-Item "\\$Computer\$Destination" -Type Directory) {$global:shareyes++}
    }
 
   Write-Verbose "Copying $File to $Computer"
   TRY
   {
    If (Copy-Item -Path $Path -Destination "\\$Computer\$Destination" -Force) {$global:shareyes++}
    Write-Host "Copied to \\$Computer\$Destination\$File`n" -ForegroundColor GREEN

   

  #  New-SMBShare –Name "mytest" `
   ##         –FullAccess Everyone `
     #        -ChangeAccess 'Server Operators' `
      #       -ReadAccess Everyone`
             
#If (New-PSDrive -Name "mytest" -PSProvider "FileSystem" -Root \\$computer\$destination) {$global:shareyes++}

   }
   CATCH
   {
    Write-Warning "Copy failed to $Computer`n"
    
   } 
     

  }#EndForEach
 }#EndProcess
}#EndFunction


Function Option-three
{



 [int]$blunder= 0
 [int]$counter= 0
  [string] $apips

 $a= [System.Net.Dns]::GetHostName()
# [System.NET.DNS]::GetHostByName($null)
 
 [string []]$tasstat=@()

 New-Object -TypeName System.Collections.ArrayList
$tasstat = [System.Collections.Arraylist]@()

 
 
 $ActualLocalH4= $env:computername

 if ($ActualLocalH4 -iin $myscluster ) {

cls
 

 $global:where2 
$where2 = $PSScriptRoot
set-location -Path $where2
cd $where2
Push-Location -Path $where2 
set-location $PSScriptRoot
$mylocation = set-location $PSScriptRoot
$myloc= $PWD.Path 
#CLs 
 $pwd
$Path = $myloc + "\"+ "myfile.txt" #Include the FileName and Extension
$Destination = "C$\Users\$Env:Username\mytest" #Be Sure to use a : instead of a $ for the username variable
$mymachine= $env:COMPUTERNAME
$my=@()
$mycluster= Get-Cluster -Name $myspanser
$mynodes = Get-ClusterNode -Cluster $mycluster | Select-Object name
$counter = (@($mynodes).name).Count
$my= (@($mynodes).name)|Where-Object {$_.Name -inotmatch $mymachine}
$computername = $my -split " "
$var= "true"

#Quick Variables
Copy-File -Verbose $computername $Path $Destination

#disable UAC
REG ADD "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 0 /f
#alternate
#REG ADD "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v LocalAccountTokenFilterPolicy /t REG_DWORD /d 1 /f
#net stop browser && net stop server && net start server && net start browser
 
 
 #Tell Cusotmer what we are doing - doing a prerequcheck



Write-host " This test will show failures and may show odd results from time to time. Its just a tool to help narrow down any issues. " -ForegroundColor Green 
Write-host " Ignore any failures and just review the resulting True or False for each test. Troubleshoot where you see fail test results" -Forground green 
$whatsmyclus = Read-host "hit enter to begin..."

#test 169 addresses # Get local FQDN
$myFQDN=(Get-WmiObject win32_computersystem).DNSHostName+"."+(Get-WmiObject win32_computersystem).Domain ; Write-Host $myFQDN
$cresolve = Resolve-DnsName $myFQDN | Where-Object {$_.Type -ne "AAAA"}
$temp1APIP= ($cresolve | Where-Object IPAddress -imatch "169.254")
if ($temp1APIP.Count -gt 1) {$apips = "false"} # counter says there it soo many APipa address - please check
if ($temp1apip.Count -le 1) {$apips = "true" } # counter checking for no apipa
if ($temp1APIP.count -eq 1) {$apips = "exact"}
 
  $finalClusIP = @()

# finding out how many and what the Apipa addresses are 
If ($apips -in "true,exact")
 
 {
 #if apipa address is not there or one value- search wmi and see if there is an IP and find its ip address 

# pulling the usbnic apipa address to compare to the others. 
#$myusbnic = Get-NetAdapter Where {$_InterfaceDescription -eq  "Remote NDIS Compatible Device"}
$myusbnic = @(Get-NetAdapter -InterfaceDescription "Remote NDIS Compatible Device" | Get-NetIPAddress -AddressFamily "ipv4")

$myusbip = $myusbnic.IPAddress
$mytempfih = (get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=true and DHCPEnabled=true" -ComputerName . | Where-Object -FilterScript {$_.Description -contains "Remote NDIS Compatible Device"} | Select-Object -Property DHCPSERVER)
get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=true and DHCPEnabled=true" -ComputerName .
# if there is another apipa - it will be here 
  
 # the $myredishIP is the Drac Redfish IP in the drac we will compare this to the Host Apipa- do they ping? 
 $myRedishIP= ($mytempfih.DHCPSERVER)

# $myredfishIP and $mytempfih are the same value - the Drac IP redfish
# $myusbnic is the Usb host nic
#$myRedishIP is the redfish
 #$alpipper = $temp1APIP.ipaddress # Both IP of hostnic and cluster apipa - no hostnames
 #$finalclusIP cluster IP if there is one (apipa)
 
}


 

$a= $env:computername

 

if ($apips -eq "false")
{
#if there is more then 1 apipa address grab them both and do check to see which is the omimswac ip
  # returns both or all apipa addresses
  
 


 


}



# IPV4 APipa Nic that is remote usb nic NDIS 169.254.1.96"}
$myusbnic = @(Get-NetAdapter -InterfaceDescription "Remote NDIS Compatible Device" | Get-NetIPAddress -AddressFamily "ipv4")

# 169.254.1.96
$myusbip = $myusbnic.IPAddress

# This is the Drac Apipa redfish address 169.254.1.95
$mytempfih = (get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=true and DHCPEnabled=true" -ComputerName . | Where-Object -FilterScript {$_.Description -contains "Remote NDIS Compatible Device"} | Select-Object -Property DHCPSERVER)


# $finalclusIP= ($temp1APIP.ipaddress | Where-Object -FilterScript {$_.Description -contains "Microsoft Failover Cluster Virtual Adapter"} )
# myfinal is supposed to be only cluster apipa (not Drac apipa) but not allways working 
  $myfinalClusIP =  @(Get-NetAdapter -InterfaceDescription "*Microsoft Failover Cluster Virtual Adapter*" | Get-NetIPAddress -AddressFamily "ipv4")
 $myRedishIP= ($mytempfih.DHCPSERVER )
 #$finalClusIP= Compare-Object -ReferenceObject $alpipper -DifferenceObject $myusbip 
$myfineinput = $myfinalClusIP




 

  $finalclusIP= ($temp1APIP.IPAddress| Where-Object -FilterScript {$_.Description -ne "Remote NDIS Compatible Device"}) 
 # the $myredishIP is the Drac Redfish IP in the drac we will compare this to the Host Apipa- do they ping? 
 $myRedishIP= ($mytempfih.DHCPSERVER)
 # now I have the ip for Drac. I need to ping the IPMI IP in the pass-through myusbip and myredfiship

 #defining pings and execution
$Task1 = (New-Object System.Net.NetworkInformation.Ping).Send($myFQDN)
#SendPingAsync($myredfiship)
# Task1.status is the term success or fail of ping 
if ($task1.status -eq "success") {$Pingdns= "True"} else {$Pingdns= "false"}
########################
$Task = (New-Object System.Net.NetworkInformation.Ping).Send($myrediship)
#SendPingAsync($myredfiship)
$Task
if ($task.status -eq "success") {$fishstat= "True"} else {$fishstat= "false"}
####################################

 #now checking IP from DNS and non APipa addresses- IE the cluster IPs
 #verify DNS entry host and FQDN

$b = Resolve-DnsName -Name $a | where {$_.type -eq "A"}
$c = $b | where {$_.ipaddress -inotmatch "169.254"} 
$countip = $c.count
 
# C cycles over the found addresses and test connectivity
 $trask = new-object system.collections.arraylist
################################################################################
for ($i = 0; $i -lt ($countip-1) ; $i++)
 {
 $myip =  $c[$i].IPAddress
  # write-host " the IP is $c[$i].IPAddress"
 $Trask = (New-Object System.Net.NetworkInformation.Ping).Send($c[$i].ipaddress)
 #SendPingAsync($myredfiship)
 
if ($trask.status -eq "success") { write-host -NoNewline  $myip; Write-host "  $myip  <--------- IP Non Apipa -----------> Status Pass $tasstat"} 
else { write-host -NoNewline  $myip ; Write-host "  $myip <--------- IP Non Apipa -----------> Status Fail $tasstat"}
 
#this variable array has the results as true for success but i turned out not to need it. i may use anyway.
 
  }

Write-host " Above we have the non APipa addresses. The ping test results above. Yellow is failure. Green is success"
 Write-host "Results are as follows:" -ForegroundColor Green

 $ipmi1 = Get-service -name IPMIDRV

$ipmi2 = Get-PnpDevice -Class system -FriendlyName "microsoft Generic IPMI compliant device"
If ($ipmi1 -and $ipmi2) {$ipmi3= "True"} else {$ipmi3= "false"}


# alternate
#REG DELETE "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v LocalAccountTokenFilterPolicy
#net stop browser && net stop server && net start server && net start browser
#Cls

Write-host "-----------------------" -ForegroundColor Yellow
if ($ipmi3 = "true") { Write-host " $ipmi3 IPMI device present? $ipmi3" -ForegroundColor Green} else { Write-host " $ipmi3 IPMI device present? $ipmi3" -ForegroundColor yellow}
Write-host "-----------------------" -ForegroundColor Yellow
if ($dnscorr = "true") { Write-host " $dnscorr Ping by name worked?  $dnscorr" -ForegroundColor Green} else { Write-host " $dnscorr Ping by name worked??  $dnscorr" -ForegroundColor yellow}
 
Write-host "-----------------------" -ForegroundColor Yellow
if ($Pingdns = "true") { Write-host " $Pingdns Dns Test to hostname results $Pingdns" -ForegroundColor Green} else { Write-host " $Pingdns Dns Test to hostname results" $Pingdns -ForegroundColor yellow}
 
Write-host "-----------------------" -ForegroundColor Yellow
if ($wmidns = "true") {Write-host " $wmidns Resolve by WMI to DNS success $wmidns" -ForegroundColor Green} else  {Write-host " $wmidns Resolve by WMI to DNS success $wmidns" -ForegroundColor yellow}
Write-host "-----------------------" -ForegroundColor Yellow

if ($apips -eq "true") {Write-host "Didnt find Apipa address. Falling back to check WINRM. If target test succeeds, ignore this error " -ForegroundColor red}
if ($apips -eq "false") {Write-host "Found Multiple APipa address. one could be the CLuster Internal IP. " -ForegroundColor Yellow}  
if ($apips -eq "exact") {Write-host "We found only the one Apipa address " -ForegroundColor blue} 
Write-host " $myusbip <--- This is your Host  USB nic"
write-host " $myRedishIP <--- This is your Redfish Drac IP"

for ($bye=1 ; $bye -le  $temp1APIP.Count ; $bye++)
{
$newtruth = "true"
if ( !($myusbip -contains $temp1APIP.IPAddress[$bye])) {$newApipa = $temp1APIP.IPAddress[$bye] 

Write-host "---> $newapipa discovered <----  $newapipa and is non USBNIC apipa address. is this secret  cluster nic? No other APipa Addresses will be allowed!" -ForegroundColor Yellow
write-host "--------------------------" -ForegroundColor Yellow


} else {$newtruth = "false"}

Write-host " This is both values ->>>> $finalClusIP <----- If one of them is VMfleet OMIMSWAC wont run! " -ForegroundColor Yellow
$myfineinput
Write-host "-----------------------" -ForegroundColor Yellow

# $myredfishIP and $mytempfih are the same value - the Drac IP redfish
# $myusbnic is the Usb host nic
#$myRedishIP is the redfish
 #$alpipper = $temp1APIP.ipaddress # Both IP of hostnic and cluster apipa - no hostnames
 #$finalclusIP cluster IP if there is one (apipa)
 Write-host " If i missed anything, this is all apipa addresses. You cant have multiples"
 $alpipper = $temp1APIP.ipaddress # Both IP of hostnic and cluster apipa - no hostnames

 
 # this is the cluster IP or other? 
 Write-host "-----------------------" -ForegroundColor Yellow
 Write-host " This is both apipa ----> $alpipper <------------" -ForegroundColor Green
# $alpipper = $temp1APIP.ipaddress # Both IP of hostnic and cluster apipa
 
Write-host "-----------------------" -ForegroundColor Yellow
 
if ($ipmi3 = "true") {Write-host "The Ipmi Driver and Class are running true " -ForegroundColor Green} else  {Write-host " Please check the non running Ipmi Driver and Class." -ForegroundColor yellow}
Write-host "-----------------------" -ForegroundColor Yellow


#Write-host $c.count "is the number of non Apipa addresses.This includes the Management IP" -ForegroundColor Green
#if ($task -eq "success" ) {Write-host " $c.ipaddress is pinging " -ForegroundColor Green} else  {Write-host "$c.ipaddress is not pinging " -ForegroundColor yellow}
#Write-host "-----------------------" -ForegroundColor Yellow
#for ($i = 0; $i -lt ($countip) ; $i++)
#{

 
#(Write-host -NoNewline " result of ping: " -ForegroundColor Green) ; [string]$c[$i].IPAddress , $tasstat[$i] 
 #Write-host ($c[$i].ipaddress)

#($c.ipaddress)
#}

 
Write-host "-----------------------"
Write-host " $c.count is the number of IP checked (non redfish)" -ForegroundColor green
 
Write-host "-----------------------" -ForegroundColor Yellow
if ($var -eq "true") {Write-host "File Copy to all nodes executed  " -ForegroundColor Green} else  {Write-host "File copy failed  " -ForegroundColor yellow}
 
Write-host "-----------------------" -ForegroundColor Yellow
 
if ($dnscorr -eq "true") {Write-host "Checked local DNS compared to DC dns and result is  $dnscorr" -ForegroundColor Green} else  {Write-host "Checked local DNS compared to DC dns and result is  $dnscorr " -ForegroundColor yellow}
Write-host "-----------------------" -ForegroundColor Yellow
 
#if ($refishcheck -eq  "true") {Write-host "Redfish check is True " -ForegroundColor Green} else  {Write-host "Redfish check is fail " -ForegroundColor yellow}

#Specific share results
Write-host "-----------------------" -ForegroundColor Yellow
Write-host "file creation tested on secret share $blunder files coppied. Zero or 1 blunder is ok. The local host does not count as a share." -ForegroundColor Green
$result= ($counter-$blunder)
Write-host "-----------------------" -ForegroundColor Yellow
Write-host " basic net successes count is $result, which should be N-1 cluster nodes" -ForegroundColor Green
Write-host "-----------------------" -ForegroundColor Yellow
Write-host $counter "Is the number of shares created"  -ForegroundColor Green
Write-host "-----------------------" -ForegroundColor Yellow
 
 
Write-host "-----------------------" -ForegroundColor Yellow
 #{ Write-host " this is a WAC server or non HCI node. Exiting to menu" ; sleep(3)}
 Write-host "-----------------------" -ForegroundColor Yellow
 
 Write-host "Run get-netadapter | get-netipaddress | ft if you need to investigate connectivity" -ForegroundColor Green
 write-host " But fishstat is True here ->($fishstat) then $myrediship connectivity test is passing" -ForegroundColor Green
 Write-host " SCROLL UP TO SEE ALL THE RESULTS!. ONCE YOU HIT ENTER IT ALL GOES AWAY!"
 #enable UAC

} 

}Else { Write-host " this is a WAC server or non HCI node. Exiting to menu" ; sleep(3)}
  {(REG ADD "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 5 /f)}


 
 }

Function Option-four{
cls
$myspanser  
$myscluster
Write-host " This section will Install Windows admin center. Below are some restrictions for OMIMSWAC"

WRITE-HOST " You Do not want WAC installed on: "  -ForegroundColor Green
Write-host " =You Do not want WAC installed on Any VM in the Cluster."  -ForegroundColor Green
write-host " =You Do not want WAC installed on Any host in the cluster."  -ForegroundColor Green
write-host " =You Do not want WAC installed on Any remote site. Exceptions apply for this one"  -ForegroundColor Green
Write-host " Do you still want to Install Wac? ... Hit a key... and then hit enter." 
$typesomethinghitenter = read-host typesomethinghitenter$


if ($myscurentcomputer -ine $myscluster)
{
   Invoke-WebRequest -UseBasicParsing -Uri https://aka.ms/WACDownload -OutFile "$env:USERPROFILE\Downloads\WindowsAdminCenter.msi"
     


 Add-LocalGroupMember -Group "Windows Admin Center CredSSP Administrators" -Member $env:USERDOMAIN\$env:username -ErrorAction SilentlyContinue
 Add-LocalGroupMember -Group  "administrators" -Member $env:USERDOMAIN\$env:username -ErrorAction SilentlyContinue

 Write-host " you have been added to the CredSSP group. and check your browser for the WAC frequently asked questions"
# invoke-webrequest -usebasicparsing -uri 'http://docs.microsoft.com/en-us/windows-server/manage/windows-admin-center/understand/faq*which-web-browsers-are-supported-by-windows-admin-center'
   Start-Process msiexec.exe -Wait -ArgumentList "/i $env:USERPROFILE\Downloads\WindowsAdminCenter.msi /qn /L*v waclog.txt REGISTRY_REDIRECT_PORT_80=1 SME_PORT=443 SSL_CERTIFICATE_OPTION=generate"
}



if ($myscurentcomputer -in  $myscluster) 
{


Write-host "we have detected your trying to install WAC on a cluster node. This is not supported. Please install outside the cluster"
$unsup= Read-host "proceed with an unsupported deployment? "
 
 if ($unsup -ilike '*y*')

 {

 Invoke-WebRequest -UseBasicParsing -Uri https://aka.ms/WACDownload -OutFile "$env:USERPROFILE\Downloads\WindowsAdminCenter.msi"

 Add-LocalGroupMember -Group "Windows Admin Center CredSSP Administrators" -Member $env:USERDOMAIN\$env:username -ErrorAction SilentlyContinue
 Add-LocalGroupMember -Group  "administrators" -Member $env:USERDOMAIN\$env:username -ErrorAction SilentlyContinue

 Write-host " you have been added to the CredSSP group. and check your browser for the WAC frequently asked questions"
# invoke-webrequest -usebasicparsing -uri 'http://docs.microsoft.com/en-us/windows-server/manage/windows-admin-center/understand/faq*which-web-browsers-are-supported-by-windows-admin-center'
  #start-process -filepath 'https://docs.microsoft.com/en-us/windows-server/manage/windows-admin-center/understand/faq*which-web-browsers-are-supported-by-windows-admin-center'
  Start-Process msiexec.exe -Wait -ArgumentList "/i $env:USERPROFILE\Downloads\WindowsAdminCenter.msi /qn /L*v waclog.txt REGISTRY_REDIRECT_PORT_80=1 SME_PORT=443 SSL_CERTIFICATE_OPTION=generate"


}

 }
}


Function Option-six 
{

  $myusbnic =@()

#$myusbnic = Get-NetAdapter Where {$_InterfaceDescription -eq  "Remote NDIS Compatible Device"}
$myusbnic = @(Get-NetAdapter -InterfaceDescription "Remote NDIS Compatible Device" | Get-NetIPAddress -AddressFamily "ipv4")
$myusbip = $myusbnic.IPAddress
$mytempfih = (get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=true and DHCPEnabled=true" -ComputerName . | Where-Object -FilterScript {$_.Description -contains "Remote NDIS Compatible Device"} | Select-Object -Property DHCPSERVER)
 
 $myRedishIP= ($mytempfih.DHCPSERVER )

 cls 
 Write-host " this section is all about the USB NIC. this should be the ip of the Redfish -->  $myRedishIP <---- If you nothing between the 2 arrows, check your drac."
 write-host " this section will test only the local drac. the drac has 2 IP. regular ip and one is in the redfish tab. a third, is in the windows OS. they both begin with 169.154.x.x"
write-host "this tool tests that connectivity. You need the drac user and password to begin."
$savy= read-host " Savvy? (Y/N) -> Y to continue"


function fish-Menu
{
    param (
        [string]$Title = 'My Menu'
    )

    Clear-Host
    Write-Host "================ $Title ================"
    
    Write-Host "1: Press '1' To Download and Install the required files for the Redfish Commands to work using Powershell commands." -ForegroundColor Green
    Write-Host "2: Press '2' Run Example Get-IdracRemoteServiceApiStatusREDFISH." -ForegroundColor Green
    Write-Host "3: Press '3' Run Example Invoke-ExportHwInventoryLocalREDFISH" -ForegroundColor Green
    Write-Host "4: Press '4' Run Example Get-IdracServerSlotInformationREDFISH" -ForegroundColor Green
    Write-Host "5: Press '5' Run Example Get-ImportServerConfigurationProfilePreviewREDFISH" -ForegroundColor Green
    Write-Host "6: Press '6' Choose this option To Get a list of other Commands you can run by using your own switchs" -ForegroundColor Green
    Write-Host "7: Press '7' Press 7 to complete troubleshooting and remove the powershell modules from the target system" -ForegroundColor Green
    Write-Host "Q: Press 'Q' to quit."
}


Function Install-Fedfish{
$where2=$PSScriptRoot
$RunIdrac = "create_dir_structure_download_iDRAC_Redfish_cmdlets.ps1"
cd $where2

write-host " the files you need include below (all in the powershell script running folder): "   -ForegroundColor Red
Write-host " Listof possiblecmds.html"   -ForegroundColor Red
write-host " and create_dir_structure_download_iDRAC_Redfish_cmdlets.ps1"   -ForegroundColor Red

# Create the folder structure syntax for setup of refish powershell comands
$targetnode = $($env:COMPUTERNAME)
#$cred = Get-Credential
$Pwrshell = $PSVersionTable
 
$finalFishpath= "C:\users\"+$($env:USERDOMAIN)+ "\" +$($env:USERNAME)+ "\"+ "Documents\WindowsPowerShell\Modules\*"
$createdirpath= "C:\users\"+$($env:USERDOMAIN)+ "\" +$($env:USERNAME)+ "\"+ "Documents\WindowsPowerShell\Modules\"
$userdomain1 = $($env:USERDOMAIN)+ "\" +$($env:USERNAME)

 
#$sourcefile = Get-ChildItem $createdirpath -File |Where {$_.Name -imatch $RunIdrac}
#IF (!$sourcefile){
#cd $PSScriptRoot
#Copy $RunIdrac $createdirpath
#}

#Create Registration Path for Powershell Module  

$checkif = test-path -Path $createdirpath -pathtype any

# review path creation if needed https://urldefense.com/v3/__https://www.powershelladmin.com/wiki/Powershell_check_if_folder_exists.php__;!!LpKI!jhvo9QLBDPeYtUkFnQyFwnc0Wm1XpvyHmoZsoHlhzfX4-VGhPYNyRDkZB7OGK-EOfw0mC1RhXxnozPfyGEGThhJHz9V6$ [powershelladmin[.]com]
If (!$checkif) { MKDIR $createdirpath} else {Write-host "Path to Redfish Powershell commands Exists and is Valid!"}

  
#################################################################### 
$Int1 = [system.version]"6.0" # threshold for New value to the Redfish install
$NewOrOld= ($PSVersionTable | Where-Object {$_.PSVersion -lt $int1})

$NewOrOld = $PSVersionTable 
$where2 = $PSScriptRoot

if ($NewOrOld | Where-Object {$_.PSVersion -lt $int1}) {.\create_dir_structure_download_iDRAC_Redfish_cmdlets.ps1 -powershell_version "old" -os_username $userdomain1}`
 else {.\create_dir_structure_download_iDRAC_Redfish_cmdlets.ps1 -powershell_version "new" -os_username $userdomain1}

 $finalFishpath | gci -Include '*.psm1','*.ps1' -Recurse | Import-Module


# Example use case

#  Get-IdracRemoteServiceApiStatusREDFISH -idrac_ip 100.72.4.25 -idrac_username root -idrac_password calvin

#Get-IdracServerSlotInformationREDFISH
#Get-ImportServerConfigurationProfilePreviewREDFISH
#Get-StorageInventoryREDFISH
#IdracRedfishSupport

 
}

Function redfish-two {


write-host " this section will test Invoke-ExportHwInventoryLocalREDFISH for target IP ---> $myRedishIP  <---" -ForegroundColor Green
$DracIP = $myRedishIP 
$dracuser = Read-host " enter the user name of the drac admin"
$dracpass = read-host "Enter the Password for the Drac Admin"
Invoke-ExportHwInventoryLocalREDFISH -idrac_ip $DracIP -idrac_username $dracuser -idrac_password $dracpass

}

Function redfish-three {


write-host " this section will test Invoke-ExportHwInventoryLocalREDFISH target IP ---> $myRedishIP  <---" -ForegroundColor Green
$DracIP = $myRedishIP 
$dracuser = Read-host " enter the user name of the drac admin"
$dracpass = read-host "Enter the Password for the Drac Admin"
Get-IdracRemoteServiceApiStatusREDFISH -idrac_ip $DracIP -idrac_username $dracuser -idrac_password $dracpass

}

Function redfish-four {

write-host " this section will test Get-IdracServerSlotInformationREDFISH target IP ---> $myRedishIP  <---" -ForegroundColor Green
$DracIP = $myRedishIP 
$dracuser = Read-host " enter the user name of the drac admin"
$dracpass = read-host "Enter the Password for the Drac Admin"
Get-IdracServerSlotInformationREDFISH -idrac_ip $DracIP -idrac_username $dracuser -idrac_password $dracpass
 
 

}
Function redfish-five {
 
write-host " this section will test Invoke-CreateXauthTokenSessionREDFISH target IP ---> $myRedishIP  <---" -ForegroundColor Green
$DracIP = Read-host $myRedishIP 
$dracuser = Read-host " enter the user name of the drac admin"
$dracpass = read-host "Enter the Password for the Drac Admin"
Invoke-CreateXauthTokenSessionREDFISH -idrac_ip $DracIP -idrac_username $dracuser -Idrac_password $dracpass -create_x_auth_token_session y
 #Invoke-CreateXauthTokenSessionREDFISH -idrac_ip 192.168.0.120 -username root -password calvin -create_x_auth_token_session y
 #  This example will create a new X-auth token session for the iDRAC.
 Write-host " token is now created"
 Write-host " you may now want to use the command below to delete the token you just created."
 Write-host "    Invoke-CreateXauthTokenSessionREDFISH -idrac_ip 192.168.0.120 -username root -password calvin -delete_idrac_session /redfish/v1/SessionService/Sessions/22
 #  This example will delete iDRAC session /redfish/v1/SessionService/Sessions/22."
}
Function redfish-six {
write-host " Opening up HTML file located in the root of Script Directory" -ForegroundColor Green
$where2=$PSScriptRoot
invoke-expression '.\ListofRedfish.html'| Out-GridView
 

}
Function redfish-seven {

$where2=$PSScriptRoot
$RunIdrac = "create_dir_structure_download_iDRAC_Redfish_cmdlets.ps1"
cd $where2
Set-Location -Path $where2
write-host " Removing PS Shell Modules... : "   -ForegroundColor Red

# Create the folder structure syntax for setup of refish powershell comands
$targetnode = $($env:COMPUTERNAME)
$Pwrshell = $PSVersionTable
 
$finalFishpath= "C:\users\"+$($env:USERDOMAIN)+ "\" +$($env:USERNAME)+ "\"+ "Documents\WindowsPowerShell\Modules\*"
$createdirpath= "C:\users\"+$($env:USERDOMAIN)+ "\" +$($env:USERNAME)+ "\"+ "Documents\WindowsPowerShell\Modules\"
$userdomain1 = $($env:USERDOMAIN)+ "\" +$($env:USERNAME)

 
 

#Create Registration Path for Powershell Module  

$checkif = test-path -Path $createdirpath -pathtype any

# review path creation if needed https://urldefense.com/v3/__https://www.powershelladmin.com/wiki/Powershell_check_if_folder_exists.php__;!!LpKI!jhvo9QLBDPeYtUkFnQyFwnc0Wm1XpvyHmoZsoHlhzfX4-VGhPYNyRDkZB7OGK-EOfw0mC1RhXxnozPfyGEGThhJHz9V6$ [powershelladmin[.]com]
If (!$checkif) { Write-host "nothing to Delete!" } else {Write-host "Path to Redfish Powershell commands Exists and is Valid!"}

  
#################################################################### 
 
$where2 = $PSScriptRoot
cd $createdirpath

#$myPSlist = gci -Include '*.psm1','*.ps1' -Recurse
(Get-Module | Where-Object {$_.Name -like "*redfish*"}) | Remove-Module
$myDelList = Get-ChildItem -Recurse –Path $createdirpath | ?{$_.Name -like "*redfish*"}
foreach ($my in $myDellist)
{
$my.FullName
Remove-item -Force $my.Name -Recurse


#get-childitem -Path $createdirpath -Filter {$_.Name -imatch "*redfish*"}

}

#gci -Include '*.psm1','*.ps1' -Recurse | Remove-Module -Force

#Get-ChildItem -Path $createdirpath -Include *.* -File -Recurse | foreach { $_.Delete()}

}


Cls

$wherefilesare = $pwd 

Write-host " This script will allow you to perform Redfish Queries without knowing redish." -ForegroundColor Green
Write-host " You should check to make sure the correct installer files are in place before choosing any other item." -ForegroundColor Green
Write-host " If you dont choose #1 First, then you may get failures. check the script about redfish 1 to check the file path for the proper Powershell modules" -ForegroundColor Green

Write-host "This Script Requires INternet connection to get the files from Github. Hit Q now if you dont have internet or the files needed." -ForegroundColor Red
Write-host " This Script Requires PS remoting and will fail if this is not already enabled." -ForegroundColor Red

Write-host " Choose to install Redfish Powershell Modules for Redfish to run on a specific Host" -ForegroundColor Green

write-host "Option 6 has a list of commands that you can use. edit the script if your interested in making a script of different Redfish commands. "
do

 {
    fish-Menu
     $selection = Read-Host "Please make a selection"
     switch ($selection)
     {
         '1' {
             'You chose redfish #1- Download and Install Required Powershell Modules'
             Install-Fedfish
         } '2' {
             'You chose redfish #2- Get-IdracRemoteServiceApiStatusREDFISH -idrac_ip 100.72.4.25 -idrac_username root -idrac_password calvin '
             redfish-two
         } '3' {
             'You chose redfish #3 Invoke-ExportHwInventoryLocalREDFISH'
            redfish-three
         } '4' {
             'You chose redfish #4 Get-IdracServerSlotInformationREDFISH'
             redfish-four
     }   '5' {
             'You chose redfish #5- Invoke-CreateXauthTokenSessionREDFISH'
             redfish-five
        } '6' {
             'You chose redfish #6 - Get a list of other Commands you can run by using your own switchs'
              redfish-six
       }  '7' {
             'You chose redfish #7 - Press here to unregister the powershell commands and Delete the directory'
              redfish-seven
        }

         }
     pause
 }

 until ($selection -eq 'q')
 Write-Output "Time taken: $((Get-Date).Subtract($start_time).Seconds) second(s)"


# 
#  

#
#
#Get-StorageInventoryREDFISH
#IdracRedfishSupport

}




Function option-seven 
{



<###################################################

CAU may look like the issue. there is basic troubleshooting

here and the steps to setup the CAU VCO and ROLE. 





####################################################>

cls
write-host "Warning This will remove an exisitng CAU role and reinstall with the existing VCO." -ForegroundColor Green
Write-host " This uses the exisitng CVO. If you dont have one or it does not work, see the documentation and redeploy CAU with CLuster Manager."
$cont= read-host "continue?(Y/N)" 
write-host "Are you Sure?" -ForegroundColor Red
$fians = read-host "answer is Y/N then enter "


if ($finans -like "*y*")
{ 
$b=@()
$a = read-host "enter cluster name"
$b= Test-CauSetup -ClusterName $a 

Get-ClusterResource  "Distributed Network Name"
 
$myclustername = Read-host "what is your clustername" 
$CAUName= (Get-Cluster $myclustername | Get-ClusterParameter -Name CauCredentialResourceName).Value
$CVOName = (Get-Cluster $myclustername | Get-ClusterParameter -name CauResourceName).Value

Remove-CauClusterRole -ClusterName $myclustername -Force

Get-Cluster $myclustername  | get-ClusterParameter "CauResourceName" 
Get-Cluster $myclustername  | Set-ClusterParameter "CauResourceName" -Delete

Get-ClusterResource -Name $CAUName | Remove-ClusterResource
Get-ClusterResource -Name $CVOName | Remove-ClusterResource


write-host "Wait 10 seconds-Then RUN GET-CLUSTERRESOURCE and see that the CAU objects are gone.those names are printed below" -ForegroundColor Green
$CVOName
$CAUName
$check= Read-host "Once you verified the objects are gone, hit a key and enter to add the role back properly."

Add-CauClusterRole -ClusterName $myclustername -MaxFailedNodes 0 -RequireAllNodesOnline -EnableFirewallRules -VirtualComputerObjectName $CVOName -Force -CauPluginName Microsoft.WindowsUpdatePlugin -MaxRetriesPerNode 3 -CauPluginArguments @{ 'IncludeRecommendedUpdates' = 'False' } -StartDate "3/2/2020 3:00:00 AM" -DaysOfWeek 4 -WeeksOfMonth @(3) -verbose

Write-host " This last step Will just delete the cluster history from this node. Its a good idea to Move the owner of this arround. Just Make sure this feature is working on all nodes." -ForegroundColor Green
Write-host " You can hit a key or enter to continue, or close this option by choosing N . Choosing N will return you to the main Menu."-ForegroundColor Green
Write-host " Really I am making you read all this to buy time for the CAU role to complete. Wait about a minute before making your choice." 

$myCAUA = Read-host " Are you ready? " 

# last step
If ($mycaua -inotlike "n"){
Stop-clusterperformancehistory -deletehistory
start-clusterperformancehistory
Get-ClusterResource -Name "Cluster Virtual Disk (ClusterPerformanceHistory)"
} else {write-host "Skipped Cluster History Delete" -ForegroundColor Green }



}

}

Function Option-eight {

#Enter-PSSession -ComputerName $Chlost
$datet= (Get-Date).AddDays(-1)
 $mycluster8= get-cluster 
#$mynode8= Get-ClusterNode -Name $mycluster8
$revs = @(Get-ClusterNode -Cluster $mycluster8)
$Chostname= $env:computername
 
$Uusername= $env:USERNAME
cls
$destination = Read-host "please put a unc path to a share for backup \\host\folder. If your not backing up, stop the script and comment out the copy-item lines"
#$destination = "\\gsejumpbox\repositoryDSU\backup"
$ans11= read-host "do you want to delete the WAC logs from the servers on cluster?. This is the cleanup portion. if not stop the script and comment out the remove-item lines"

If($destination.EndsWith('\')){
$destination = $destination -replace '\\$',""
}
foreach ($myrev in $revs)
{
 

    
 $MainLogs = "\\$myrev\c$\Windows\ServiceProfiles\NetworkService\Appdata\Local\Temp\generated\"
 $pushfiles = "\\$myrev\c$Windows\Temp\OMIMSWAC\"
$Failedupdate= "\\$myrev\c$\ProgramData\Server Management Experience\Extensions\dell-emc.openmanage-integration.2.2.1\"
$Duplog = "\\$myrev\c$\temp\sme\dell-emc.openmanage-integration.2.2.1\"
$updatelog = "\\$myrev\c$\Users\*\appdata\roaming\update\log\"
$applogs1= "\\$myrev\c$\Users\$Uusername\AppData\Roaming\Update\"
$applogs2 = "\\$myrev\c$\Users\$Uusername\AppData\Roaming\compliance\"
    $Share1= "\\$myrev\c$\Users\$Uusername\AppData\Local\Temp\CAU\"

 $finalDest = join-path $destination $myrev
   if (!(Test-Path $finaldest)) { mkdir $finalDest }
   

 #Set-Location $share1 -PassThru
    Set-Location -Path $share1
    $debug=@()
    $bugstore=@()
    $share1
   

#if (!(Test-Path $destination)) { mkdir $rev.Id }
#$finalDest = "$destination$rev"

$debug = Get-ChildItem -Path $Share1 -Recurse | Where-Object {$_.CreationTime -gt ($datet)}
    #$debug = Get-childItem -Path $Share1 -Filter *.etl


    #$debug = (Get-Item -Path $Share1).LastWriteTime
    Foreach ($bug in $debug)
    {
    Try {

    invoke-expression " Netsh Trace Convert $bug" 

    } Catch {Write-host "THis file wont convert" -ForegroundColor Green  }


    $bugstore = Get-ChildItem -Path $Share1 -Recurse *.txt
    }

copy-item $MainLogs -Recurse $finalDest  -verbose
copy-item $pushfiles -Recurse $finalDest  -verbose
copy-item $Failedupdate -Recurse $finalDest  -verbose
copy-item $Duplog -Recurse $finalDest -verbose
copy-item $updatelog -Recurse $finalDest  -verbose
copy-item $applogs1 -Recurse $finalDest  -verbose
copy-item $applogs2  -Recurse $finalDest  -verbose
#copy-item $Share1 -recurse $finaldest -Verbose
copy-item $bugstore -Recurse $finalDest -Verbose
if ( $ans11 -like '*Y*')
 {

Remove-Item -Path "$mainlogs\*" -Recurse -force
Remove-Item -Path "$share1\*" -Recurse -force
Remove-Item -Path "$pushfiles\*" -Recurse -force
Remove-Item -Path "$updatelog\*" -Recurse -force
Remove-Item -Path "$applogs1\*" -Recurse -force
Remove-Item -Path "$applogs1\*" -Recurse -force
Remove-Item -Path "$applogs2\*" -Recurse -force
#Remove-Item -Path "$applogs3\*" -Recurse -force
Remove-Item -Path "$Failedupdate\*" -Recurse -force
}
   





}

Write-host " Is this the WAC server? " -ForegroundColor Green
$iswac= read-host "hit N otherwise we will try to collect wac logs" 

If ($iswac -ne "n")
{
#### WAC sererlogs

#$destination = Read-host "please put a unc path to a share for backup \\host\folder. If your not backing up, stop the script and comment out lines 518-520"
$rev= "WAC"
 

if (!(Test-Path $destination)) { mkdir $rev }
$finalDest = "$destination$rev"
$clearWAClog= "C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Temp\generated\"
$dellDupLog = "C:\ProgramData\Dell\DELL EMC System Update"
$dsuInstaller = "C:\ProgramData\Dell\UpdatePackage\log"

copy-item $clearWAClog -Recurse $finalDest  -verbose
copy-item $dellDupLog -Recurse $finalDest  -verbose
copy-item $dsuInstaller -Recurse $finalDest  -verbose

Remove-Item -Path "$clearWAClog\*" -Recurse -Force
Remove-Item -Path "$dellDupLog\*" -Recurse -Force
Remove-Item -Path "$dsuInstaller\*" -Recurse -Force


Write-host "Files are copying to the share you specified. hit a key to continue" -ForegroundColor Green; read-host '$myans12'
} else {Write-host "no Wac logs collected"}


# try tommys 
# $bugstore.fullname | %{Start-Process -FilePath "Netsh.exe" -ArgumentList @("Trace","Convert","$_")}



}

function option-nine
{
 

If (Get-WindowsFeature RSAT-AD-PowerShell) {Add-WindowsFeature RSAT-AD-PowerShell}
else {Enable-WindowsOptionalFeature -Online -FeatureName RSATClient-Roles-AD-Powershell}
# {Add-WindowsCapability –online –Name “Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0”}

# Variables
$HVHost01 = $var[0]
$HVHost02 = $var[1]
$HVHost03 = $var[3]
$HVHost04 = $var[4]
$HVHost05= $management

$global:creds = Get-Credential -UserName $mydom\$mycurUser -Message "Creds for OMIMSWAC Repair"


#Run this Script from within your Management VM or THE DC VM
cls
Write-host "THis script will try to add the nodes automatically. If its not possible, Edit the script on line "

write-host "Get-WindowsCapability -name rsat* -Online will be run and installed"

If (Get-WindowsFeature RSAT-AD-PowerShell) {Add-WindowsFeature RSAT-AD-PowerShell}
else {Enable-WindowsOptionalFeature -Online -FeatureName RSATClient-Roles-AD-Powershell}
# {Add-WindowsCapability –online –Name “Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0”}



$HVHost = @{}
$myspanser 
$mynames = $myscluster.name
$mycount= $mynames.count
 
$var= $mynames.Split("")
$management= read-host " what is the hosthame for the Windows admin center machine?"

Import-Module ActiveDirectory

# Delegate Microsoft Virtual System Migration Service and CIFS for every other possible Live Migration host
$S2d1Spns = @("Microsoft Virtual System Migration Service/$HVHost01", "cifs/$HVHost01")
$S2d2Spns = @("Microsoft Virtual System Migration Service/$HVHost02", "cifs/$HVHost02")
$S2d3Spns = @("Microsoft Virtual System Migration Service/$HVHost03", "cifs/$HVHost03")
$s2d4Spns = @("Microsoft Virtual System Migration Service/$HVHost04", "cifs/$HVHost04")
$s2d5Spns = @("Microsoft Virtual System Migration Service/$HVHost04", "cifs/$HVHost05")

$delegationProperty = "msDS-AllowedToDelegateTo"
$delegateToSpns = $S2d1Spns + $S2d2Spns + $S2d3Spns + $s2d4Spns + $s2d5Spns

# Configure Kerberos to (Use any authentication protocol)
$S2d1Account = Get-ADComputer $HVHost01
$S2d1Account | Set-ADObject -Add @{$delegationProperty=$delegateToSpns}
Set-ADAccountControl $S2d1Account -TrustedToAuthForDelegation $true -Credential $global:creds

$S2d2Account = Get-ADComputer $HVHost02
$S2d2Account| Set-ADObject -Add @{$delegationProperty=$delegateToSpns}
Set-ADAccountControl $S2d2Account -TrustedToAuthForDelegation $true -Credential $global:creds

$S2d3Account = Get-ADComputer $HVHost03
$S2d3Account | Set-ADObject -Add @{$delegationProperty=$delegateToSpns}
Set-ADAccountControl $S2d3Account -TrustedToAuthForDelegation $true -Credential $global:creds

$s2d4Account = Get-ADComputer $HVHost04
$s2d4Account | Set-ADObject -Add @{$delegationProperty=$delegateToSpns}
Set-ADAccountControl $s2d4Account -TrustedToAuthForDelegation $true -Credential $global:creds

$s2d5Account = Get-ADComputer $HVHost05
$s2d5Account | Set-ADObject -Add @{$delegationProperty=$delegateToSpns}
Set-ADAccountControl $s2d5Account -TrustedToAuthForDelegation $true -Credential $global:creds


#Courtesy of Ricky Bobby Inc. AKA Louis_Reeves@Dell.com
#>

cls
Write-host "The constrained Delegation settings are now complete. GO in Peace and may your updates work well!"

}


do
 {
    Show-Menu
     $selection = Read-Host "Please make a selection"
     switch ($selection)
     {    
           '0' {
             'Prerequisites - Run on all Nodes Including WAC. Patch and update does not work without this step!(C)'
             prereque
       }   '1' {
             'Prerequisites - Cleanup All Nodes Run from one cluster node and again on WAC.(C)'
             Cleanup-one
         } '2' {
             'PreRquisites (Installs or Repairs) ISM module And Sets the Proper Racadm Settings for the Host to talk to Drac (N)'
             Option-two
         } '3' {
             'PreRequisites - Test the Nodes for OMIMSWAC SUITABILITY and Connectivity. Making improvements Over time (N)'
            Option-Three
         } '4' {
             'Option 4 only for WAC server. Install WAC in Gateway Mode (WAC SERVER)'
             option-four
     }     '5' {
             'Repair Step. Only run this to clear our a Node to prep for Rediscovery by WAC. This step Cleans Up USBNIC and Devices (N)'
             Option-five
        }  '6' {
             'Repair Step. Will test Redfish And Tell you if you need to check this setting in the Drac.(N)'
              option-six
       }   '7' {
             'Repair Step. Will remove CAU objects and try to manually recreate. Try CLuster Manager CAU install first. Its likely to work(C)'
              option-seven
        }  '8' {
             'Repair Step. Repair Step. Option 1 and 8 collect logs. - but this option TAKES ETL AND converts to TXT for the Days runs. (C).'
              option-eight
        }  '9' {
             'Optional. This is constrained delegation. Only works for cluster nodes and the WAC machine (C).' 
              option-nine
        }

         }
     pause
 }

 until ($selection -eq 'q')
 
 $RunTime = New-TimeSpan -Start $StartTime -End (get-date) 
 "Execution time was {0} hours, {1} minutes, {2} seconds and {3} milliseconds." -f $RunTime.Hours,  $RunTime.Minutes,  $RunTime.Seconds,  $RunTime.Milliseconds  